﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPA = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPB = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPC = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPD = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsuba = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubb = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubc = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubd = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.IMPA, Me.IMPB, Me.IMPC, Me.IMPD, Me.RM1A, Me.RM1B, Me.RM1C, Me.RM1D, Me.RM2A, Me.RM2B, Me.RM2C, Me.RM2D, Me.RXIMM1A, Me.RXIMM1b, Me.RXIMM1C, Me.RXIMM1d, Me.RXIMM2A, Me.RXIMM2B, Me.RXIMM2C, Me.RXIMM2D, Me.sumwiriM1A, Me.sumwiriM1B, Me.sumwiriM1C, Me.sumwiriM1D, Me.sumwiriM2A, Me.sumwiriM2B, Me.sumwiriM2C, Me.sumwiriM2D, Me.Sumwsuba, Me.Sumwsubb, Me.Sumwsubc, Me.Sumwsubd, Me.sumwiridivsumwM1a, Me.sumwiridivsumwM1b, Me.sumwiridivsumwM1c, Me.sumwiridivsumwM1d, Me.sumwiridivsumwM2a, Me.sumwiridivsumwM2b, Me.sumwiridivsumwM2c, Me.sumwiridivsumwM2d, Me.EQ1, Me.EQ2})
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.Margin = New System.Windows.Forms.Padding(1)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(1516, 336)
        Me.ListView1.TabIndex = 4
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'IMPA
        '
        Me.IMPA.Tag = ""
        Me.IMPA.Text = "IMPA"
        '
        'IMPB
        '
        Me.IMPB.Tag = ""
        Me.IMPB.Text = "IMPB"
        '
        'IMPC
        '
        Me.IMPC.Tag = ""
        Me.IMPC.Text = "IMPC"
        '
        'IMPD
        '
        Me.IMPD.Tag = ""
        Me.IMPD.Text = "IMPD"
        '
        'RM1A
        '
        Me.RM1A.Text = "RM1A"
        '
        'RM1B
        '
        Me.RM1B.Text = "RM1B"
        '
        'RM1C
        '
        Me.RM1C.Text = "RM1C"
        '
        'RM1D
        '
        Me.RM1D.Text = "RM1D"
        '
        'RM2A
        '
        Me.RM2A.Text = "RM2A"
        '
        'RM2B
        '
        Me.RM2B.Text = "RM2B"
        '
        'RM2C
        '
        Me.RM2C.Text = "RM2C"
        '
        'RM2D
        '
        Me.RM2D.Text = "RM2D"
        '
        'RXIMM1A
        '
        Me.RXIMM1A.Text = "RXIMM1A"
        '
        'RXIMM1b
        '
        Me.RXIMM1b.Text = "RXIMM1b"
        '
        'RXIMM1C
        '
        Me.RXIMM1C.Text = "RXIMM1C"
        '
        'RXIMM1d
        '
        Me.RXIMM1d.Text = "RXIMM1d"
        '
        'RXIMM2A
        '
        Me.RXIMM2A.Text = "RXIMM2A"
        '
        'RXIMM2B
        '
        Me.RXIMM2B.Text = "RXIMM2B"
        '
        'RXIMM2C
        '
        Me.RXIMM2C.Text = "RXIMM2C"
        '
        'RXIMM2D
        '
        Me.RXIMM2D.Text = "RXIMM2D"
        '
        'sumwiriM1A
        '
        Me.sumwiriM1A.Text = "sumwiriM1A"
        '
        'sumwiriM1B
        '
        Me.sumwiriM1B.Text = "sumwirM1B"
        '
        'sumwiriM1C
        '
        Me.sumwiriM1C.Text = "sumwiriM1C"
        '
        'sumwiriM1D
        '
        Me.sumwiriM1D.Text = "sumwiriM1D"
        '
        'sumwiriM2A
        '
        Me.sumwiriM2A.Text = "sumwiriM2A"
        '
        'sumwiriM2B
        '
        Me.sumwiriM2B.Text = "sumwiriM2B"
        '
        'sumwiriM2C
        '
        Me.sumwiriM2C.Text = "sumwiriM2C"
        '
        'sumwiriM2D
        '
        Me.sumwiriM2D.Text = "sumwiriM2D"
        '
        'Sumwsuba
        '
        Me.Sumwsuba.Text = "Sumwsuba"
        '
        'Sumwsubb
        '
        Me.Sumwsubb.Text = "Sumwsubb"
        '
        'Sumwsubc
        '
        Me.Sumwsubc.Text = "Sumwsubc"
        '
        'Sumwsubd
        '
        Me.Sumwsubd.Text = "Sumwsubd"
        '
        'sumwiridivsumwM1a
        '
        Me.sumwiridivsumwM1a.Text = "sumwiridivsumwM1a"
        '
        'sumwiridivsumwM1b
        '
        Me.sumwiridivsumwM1b.Text = "sumwiridivsumwM1b"
        '
        'sumwiridivsumwM1c
        '
        Me.sumwiridivsumwM1c.Text = "sumwiridivsumwM1c"
        '
        'sumwiridivsumwM1d
        '
        Me.sumwiridivsumwM1d.Text = "sumwiridivsumwM1d"
        '
        'sumwiridivsumwM2a
        '
        Me.sumwiridivsumwM2a.Text = "sumwiridivsumwM2a"
        '
        'sumwiridivsumwM2b
        '
        Me.sumwiridivsumwM2b.Text = "sumwiridivsumwM2b"
        '
        'sumwiridivsumwM2c
        '
        Me.sumwiridivsumwM2c.Text = "sumwiridivsumwM2c"
        '
        'sumwiridivsumwM2d
        '
        Me.sumwiridivsumwM2d.Text = "sumwiridivsumwM2d"
        '
        'EQ1
        '
        Me.EQ1.Text = "EQ1"
        '
        'EQ2
        '
        Me.EQ2.Text = "EQ2"
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1516, 336)
        Me.Controls.Add(Me.ListView1)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "Form6"
        Me.Text = "Two Equipments Results"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents IMPA As ColumnHeader
    Friend WithEvents IMPB As ColumnHeader
    Friend WithEvents IMPC As ColumnHeader
    Friend WithEvents IMPD As ColumnHeader
    Friend WithEvents RM1A As ColumnHeader
    Friend WithEvents RM1B As ColumnHeader
    Friend WithEvents RM1C As ColumnHeader
    Friend WithEvents RM1D As ColumnHeader
    Friend WithEvents RM2A As ColumnHeader
    Friend WithEvents RM2B As ColumnHeader
    Friend WithEvents RM2C As ColumnHeader
    Friend WithEvents RM2D As ColumnHeader
    Friend WithEvents RXIMM1A As ColumnHeader
    Friend WithEvents RXIMM1b As ColumnHeader
    Friend WithEvents RXIMM1C As ColumnHeader
    Friend WithEvents RXIMM1d As ColumnHeader
    Friend WithEvents RXIMM2A As ColumnHeader
    Friend WithEvents RXIMM2B As ColumnHeader
    Friend WithEvents RXIMM2C As ColumnHeader
    Friend WithEvents RXIMM2D As ColumnHeader
    Friend WithEvents sumwiriM1A As ColumnHeader
    Friend WithEvents sumwiriM1B As ColumnHeader
    Friend WithEvents sumwiriM1C As ColumnHeader
    Friend WithEvents sumwiriM1D As ColumnHeader
    Friend WithEvents sumwiriM2A As ColumnHeader
    Friend WithEvents sumwiriM2B As ColumnHeader
    Friend WithEvents sumwiriM2C As ColumnHeader
    Friend WithEvents sumwiriM2D As ColumnHeader
    Friend WithEvents Sumwsuba As ColumnHeader
    Friend WithEvents Sumwsubb As ColumnHeader
    Friend WithEvents Sumwsubc As ColumnHeader
    Friend WithEvents Sumwsubd As ColumnHeader
    Friend WithEvents sumwiridivsumwM1a As ColumnHeader
    Friend WithEvents sumwiridivsumwM1b As ColumnHeader
    Friend WithEvents sumwiridivsumwM1c As ColumnHeader
    Friend WithEvents sumwiridivsumwM1d As ColumnHeader
    Friend WithEvents sumwiridivsumwM2a As ColumnHeader
    Friend WithEvents sumwiridivsumwM2b As ColumnHeader
    Friend WithEvents sumwiridivsumwM2c As ColumnHeader
    Friend WithEvents sumwiridivsumwM2d As ColumnHeader
    Friend WithEvents EQ1 As ColumnHeader
    Friend WithEvents EQ2 As ColumnHeader
End Class
