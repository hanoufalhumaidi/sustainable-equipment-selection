﻿Public Class Importance
    Private Sub TrackBar2_Scroll(sender As Object, e As EventArgs)
        If TrackBar2.Value = 0 Then
            Label2.Text = "Not Important"
        ElseIf TrackBar2.Value = 1 Then
            Label2.Text = "Fairly Important"
        ElseIf TrackBar2.Value = 2 Then
            Label2.Text = "Important"
        ElseIf TrackBar2.Value = 3 Then
            Label2.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar2.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If
        If TrackBar2.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If TrackBar2.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If TrackBar2.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(0, 0) = a
        IMP(0, 1) = b
        IMP(0, 2) = c
        IMP(0, 3) = d


    End Sub

    Private Sub TrackBar3_Scroll(sender As Object, e As EventArgs) Handles TrackBar3.Scroll
        If TrackBar3.Value = 0 Then
            Label3.Text = "Not Important"
        ElseIf TrackBar3.Value = 1 Then
            Label3.Text = "Fairly Important"
        ElseIf TrackBar3.Value = 2 Then
            Label3.Text = "Important"
        ElseIf TrackBar3.Value = 3 Then
            Label3.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar3.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If
        If TrackBar3.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If TrackBar3.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If TrackBar3.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(1, 0) = a
        IMP(1, 1) = b
        IMP(1, 2) = c
        IMP(1, 3) = d
    End Sub

    Private Sub TrackBar4_Scroll(sender As Object, e As EventArgs) Handles TrackBar4.Scroll
        If TrackBar4.Value = 0 Then
            Label4.Text = "Not Important"
        ElseIf TrackBar4.Value = 1 Then
            Label4.Text = "Fairly Important"
        ElseIf TrackBar4.Value = 2 Then
            Label4.Text = "Important"
        ElseIf TrackBar4.Value = 3 Then
            Label4.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar4.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If
        If TrackBar4.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If TrackBar4.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If TrackBar4.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(2, 0) = a
        IMP(2, 1) = b
        IMP(2, 2) = c
        IMP(2, 3) = d
    End Sub

    Private Sub TrackBar5_Scroll(sender As Object, e As EventArgs) Handles TrackBar5.Scroll
        If TrackBar5.Value = 0 Then
            Label5.Text = "Not Important"
        ElseIf TrackBar5.Value = 1 Then
            Label5.Text = "Fairly Important"
        ElseIf TrackBar5.Value = 2 Then
            Label5.Text = "Important"
        ElseIf TrackBar5.Value = 3 Then
            Label5.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar5.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If
        If TrackBar5.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If TrackBar5.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If TrackBar5.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(3, 0) = a
        IMP(3, 1) = b
        IMP(3, 2) = c
        IMP(3, 3) = d
    End Sub


    Private Sub TrackBar7_Scroll(sender As Object, e As EventArgs) Handles TrackBar7.Scroll
        If TrackBar7.Value = 0 Then
            Label7.Text = "Not Important"
        ElseIf TrackBar7.Value = 1 Then
            Label7.Text = "Fairly Important"
        ElseIf TrackBar7.Value = 2 Then
            Label7.Text = "Important"
        ElseIf TrackBar7.Value = 3 Then
            Label7.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar7.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If
        If TrackBar7.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If TrackBar7.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If TrackBar7.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(4, 0) = a
        IMP(4, 1) = b
        IMP(4, 2) = c
        IMP(4, 3) = d
    End Sub

    Private Sub TrackBar8_Scroll(sender As Object, e As EventArgs) Handles TrackBar8.Scroll
        If TrackBar8.Value = 0 Then
            Label8.Text = "Not Important"
        ElseIf TrackBar8.Value = 1 Then
            Label8.Text = "Fairly Important"
        ElseIf TrackBar8.Value = 2 Then
            Label8.Text = "Important"
        ElseIf TrackBar8.Value = 3 Then
            Label8.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar8.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If
        If TrackBar8.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If TrackBar8.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If TrackBar8.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(5, 0) = a
        IMP(5, 1) = b
        IMP(5, 2) = c
        IMP(5, 3) = d
    End Sub

    Private Sub TrackBar9_Scroll(sender As Object, e As EventArgs) Handles TrackBar9.Scroll
        If TrackBar9.Value = 0 Then
            Label9.Text = "Not Important"
        ElseIf TrackBar9.Value = 1 Then
            Label9.Text = "Fairly Important"
        ElseIf TrackBar9.Value = 2 Then
            Label9.Text = "Important"
        ElseIf TrackBar9.Value = 3 Then
            Label9.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar9.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar9.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar9.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar9.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(6, 0) = a
        IMP(6, 1) = b
        IMP(6, 2) = c
        IMP(6, 3) = d
    End Sub


    Private Sub TrackBar11_Scroll(sender As Object, e As EventArgs) Handles TrackBar11.Scroll
        If TrackBar11.Value = 0 Then
            Label11.Text = "Not Important"
        ElseIf TrackBar11.Value = 1 Then
            Label11.Text = "Fairly Important"
        ElseIf TrackBar11.Value = 2 Then
            Label11.Text = "Important"
        ElseIf TrackBar11.Value = 3 Then
            Label11.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar11.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar11.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar11.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar11.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(7, 0) = a
        IMP(7, 1) = b
        IMP(7, 2) = c
        IMP(7, 3) = d
    End Sub

    Private Sub TrackBar12_Scroll(sender As Object, e As EventArgs) Handles TrackBar12.Scroll
        If TrackBar12.Value = 0 Then
            Label12.Text = "Not Important"
        ElseIf TrackBar12.Value = 1 Then
            Label12.Text = "Fairly Important"
        ElseIf TrackBar12.Value = 2 Then
            Label12.Text = "Important"
        ElseIf TrackBar12.Value = 3 Then
            Label12.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar12.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar12.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar12.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar12.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(8, 0) = a
        IMP(8, 1) = b
        IMP(8, 2) = c
        IMP(8, 3) = d
    End Sub

    Private Sub TrackBar13_Scroll(sender As Object, e As EventArgs) Handles TrackBar13.Scroll
        If TrackBar13.Value = 0 Then
            Label13.Text = "Not Important"
        ElseIf TrackBar13.Value = 1 Then
            Label13.Text = "Fairly Important"
        ElseIf TrackBar13.Value = 2 Then
            Label13.Text = "Important"
        ElseIf TrackBar13.Value = 3 Then
            Label13.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar13.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar13.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar13.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar13.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(9, 0) = a
        IMP(9, 1) = b
        IMP(9, 2) = c
        IMP(9, 3) = d
    End Sub


    Private Sub TrackBar15_Scroll(sender As Object, e As EventArgs) Handles TrackBar15.Scroll
        If TrackBar15.Value = 0 Then
            Label15.Text = "Not Important"
        ElseIf TrackBar15.Value = 1 Then
            Label15.Text = "Fairly Important"
        ElseIf TrackBar15.Value = 2 Then
            Label15.Text = "Important"
        ElseIf TrackBar15.Value = 3 Then
            Label15.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar15.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar15.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar15.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar15.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(10, 0) = a
        IMP(10, 1) = b
        IMP(10, 2) = c
        IMP(10, 3) = d
    End Sub

    Private Sub TrackBar16_Scroll(sender As Object, e As EventArgs) Handles TrackBar16.Scroll
        If TrackBar16.Value = 0 Then
            Label16.Text = "Not Important"
        ElseIf TrackBar16.Value = 1 Then
            Label16.Text = "Fairly Important"
        ElseIf TrackBar16.Value = 2 Then
            Label16.Text = "Important"
        ElseIf TrackBar16.Value = 3 Then
            Label16.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar16.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar16.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar16.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar16.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(11, 0) = a
        IMP(11, 1) = b
        IMP(11, 2) = c
        IMP(11, 3) = d
    End Sub

    Private Sub TrackBar17_Scroll(sender As Object, e As EventArgs) Handles TrackBar17.Scroll
        If TrackBar17.Value = 0 Then
            Label17.Text = "Not Important"
        ElseIf TrackBar17.Value = 1 Then
            Label17.Text = "Fairly Important"
        ElseIf TrackBar17.Value = 2 Then
            Label17.Text = "Important"
        ElseIf TrackBar17.Value = 3 Then
            Label17.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar17.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar17.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar17.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar17.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(12, 0) = a
        IMP(12, 1) = b
        IMP(12, 2) = c
        IMP(12, 3) = d
    End Sub

    Private Sub TrackBar18_Scroll(sender As Object, e As EventArgs) Handles TrackBar18.Scroll
        If TrackBar18.Value = 0 Then
            Label18.Text = "Not Important"
        ElseIf TrackBar18.Value = 1 Then
            Label18.Text = "Fairly Important"
        ElseIf TrackBar18.Value = 2 Then
            Label18.Text = "Important"
        ElseIf TrackBar18.Value = 3 Then
            Label18.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar18.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar18.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar18.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar18.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(13, 0) = a
        IMP(13, 1) = b
        IMP(13, 2) = c
        IMP(13, 3) = d
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        MaterialSelection.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click



        'sum of weights on sub criteria 
        sumwsub(0) = IMP(0, 0) + IMP(1, 0) + IMP(2, 0) + IMP(3, 0) + IMP(4, 0) + IMP(5, 0) + IMP(6, 0) + IMP(7, 0) + IMP(8, 0) + IMP(9, 0) + IMP(10, 0) + IMP(11, 0) + IMP(12, 0) + IMP(13, 0) + IMP(14, 0) + IMP(15, 0) + IMP(16, 0) + IMP(17, 0) + IMP(18, 0) + IMP(19, 0)
        sumwsub(1) = IMP(0, 1) + IMP(1, 1) + IMP(2, 1) + IMP(3, 1) + IMP(4, 1) + IMP(5, 1) + IMP(6, 1) + IMP(7, 1) + IMP(8, 1) + IMP(9, 1) + IMP(10, 1) + IMP(11, 1) + IMP(12, 1) + IMP(13, 1) + IMP(14, 1) + IMP(15, 1) + IMP(16, 1) + IMP(17, 1) + IMP(18, 1) + IMP(19, 1)
        sumwsub(2) = IMP(0, 2) + IMP(1, 2) + IMP(2, 2) + IMP(3, 2) + IMP(4, 2) + IMP(5, 2) + IMP(6, 2) + IMP(7, 2) + IMP(8, 2) + IMP(9, 2) + IMP(10, 2) + IMP(11, 2) + IMP(12, 2) + IMP(13, 2) + IMP(14, 2) + IMP(15, 2) + IMP(16, 2) + IMP(17, 2) + IMP(18, 2) + IMP(19, 2)
        sumwsub(3) = IMP(0, 3) + IMP(1, 3) + IMP(2, 3) + IMP(3, 3) + IMP(4, 3) + IMP(5, 3) + IMP(6, 3) + IMP(7, 3) + IMP(8, 3) + IMP(9, 3) + IMP(10, 3) + IMP(11, 3) + IMP(12, 3) + IMP(13, 3) + IMP(14, 3) + IMP(15, 3) + IMP(16, 3) + IMP(17, 3) + IMP(18, 3) + IMP(19, 3)

        MaterialSelection.Show()
    End Sub

    Private Sub TrackBar2_Scroll_1(sender As Object, e As EventArgs) Handles TrackBar2.Scroll
        If TrackBar2.Value = 0 Then
            Label2.Text = "Not Important"
        ElseIf TrackBar2.Value = 1 Then
            Label2.Text = "Fairly Important"
        ElseIf TrackBar2.Value = 2 Then
            Label2.Text = "Important"
        ElseIf TrackBar2.Value = 3 Then
            Label2.Text = "Very Important"
        End If
        Dim a, b, c, d As Double


        If TrackBar2.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar2.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar2.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar2.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(0, 0) = a
        IMP(0, 1) = b
        IMP(0, 2) = c
        IMP(0, 3) = d


    End Sub

    Private Sub TrackBar19_Scroll(sender As Object, e As EventArgs) Handles TrackBar19.Scroll
        If TrackBar19.Value = 0 Then
            Label19.Text = "Not Important"
        ElseIf TrackBar19.Value = 1 Then
            Label19.Text = "Fairly Important"
        ElseIf TrackBar19.Value = 2 Then
            Label19.Text = "Important"
        ElseIf TrackBar19.Value = 3 Then
            Label19.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar18.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar18.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar18.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar18.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(14, 0) = a
        IMP(14, 1) = b
        IMP(14, 2) = c
        IMP(14, 3) = d
    End Sub

    Private Sub TrackBar20_Scroll(sender As Object, e As EventArgs) Handles TrackBar20.Scroll
        If TrackBar20.Value = 0 Then
            Label20.Text = "Not Important"
        ElseIf TrackBar20.Value = 1 Then
            Label20.Text = "Fairly Important"
        ElseIf TrackBar20.Value = 2 Then
            Label20.Text = "Important"
        ElseIf TrackBar20.Value = 3 Then
            Label20.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar20.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar20.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar20.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar20.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(15, 0) = a
        IMP(15, 1) = b
        IMP(15, 2) = c
        IMP(15, 3) = d
    End Sub

    Private Sub TrackBar21_Scroll(sender As Object, e As EventArgs) Handles TrackBar21.Scroll
        If TrackBar21.Value = 0 Then
            Label21.Text = "Not Important"
        ElseIf TrackBar21.Value = 1 Then
            Label21.Text = "Fairly Important"
        ElseIf TrackBar21.Value = 2 Then
            Label21.Text = "Important"
        ElseIf TrackBar21.Value = 3 Then
            Label21.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar21.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar21.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar21.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar21.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(16, 0) = a
        IMP(16, 1) = b
        IMP(16, 2) = c
        IMP(16, 3) = d
    End Sub

    Private Sub TrackBar22_Scroll(sender As Object, e As EventArgs) Handles TrackBar22.Scroll
        If TrackBar22.Value = 0 Then
            Label22.Text = "Not Important"
        ElseIf TrackBar22.Value = 1 Then
            Label22.Text = "Fairly Important"
        ElseIf TrackBar22.Value = 2 Then
            Label22.Text = "Important"
        ElseIf TrackBar22.Value = 3 Then
            Label22.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar22.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar22.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar22.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar22.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        IMP(17, 0) = a
        IMP(17, 1) = b
        IMP(17, 2) = c
        IMP(17, 3) = d
    End Sub

    Private Sub TrackBar23_Scroll(sender As Object, e As EventArgs) Handles TrackBar23.Scroll
        If TrackBar23.Value = 0 Then
            Label23.Text = "Not Important"
        ElseIf TrackBar23.Value = 1 Then
            Label23.Text = "Fairly Important"
        ElseIf TrackBar23.Value = 2 Then
            Label23.Text = "Important"
        ElseIf TrackBar23.Value = 3 Then
            Label23.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar23.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar23.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar23.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar23.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(18, 0) = a
        IMP(18, 1) = b
        IMP(18, 2) = c
        IMP(18, 3) = d
    End Sub

    Private Sub TrackBar24_Scroll(sender As Object, e As EventArgs) Handles TrackBar24.Scroll
        If TrackBar24.Value = 0 Then
            Label24.Text = "Not Important"
        ElseIf TrackBar24.Value = 1 Then
            Label24.Text = "Fairly Important"
        ElseIf TrackBar24.Value = 2 Then
            Label24.Text = "Important"
        ElseIf TrackBar24.Value = 3 Then
            Label24.Text = "Very Important"
        End If
        Dim a, b, c, d As Double
        If TrackBar24.Value = 0 Then
            a = 0
            b = 0
            c = 0
            d = 0
        End If

        If TrackBar24.Value = 1 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)

        End If

        If TrackBar24.Value = 2 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If

        If TrackBar24.Value = 3 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        IMP(19, 0) = a
        IMP(19, 1) = b
        IMP(19, 2) = c
        IMP(19, 3) = d
    End Sub
End Class
