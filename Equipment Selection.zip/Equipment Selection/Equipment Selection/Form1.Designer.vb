﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Importance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TrackBar3 = New System.Windows.Forms.TrackBar()
        Me.TrackBar4 = New System.Windows.Forms.TrackBar()
        Me.TrackBar5 = New System.Windows.Forms.TrackBar()
        Me.TrackBar7 = New System.Windows.Forms.TrackBar()
        Me.TrackBar8 = New System.Windows.Forms.TrackBar()
        Me.TrackBar9 = New System.Windows.Forms.TrackBar()
        Me.TrackBar11 = New System.Windows.Forms.TrackBar()
        Me.TrackBar12 = New System.Windows.Forms.TrackBar()
        Me.TrackBar13 = New System.Windows.Forms.TrackBar()
        Me.TrackBar15 = New System.Windows.Forms.TrackBar()
        Me.TrackBar16 = New System.Windows.Forms.TrackBar()
        Me.TrackBar17 = New System.Windows.Forms.TrackBar()
        Me.TrackBar18 = New System.Windows.Forms.TrackBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TrackBar2 = New System.Windows.Forms.TrackBar()
        Me.TrackBar22 = New System.Windows.Forms.TrackBar()
        Me.TrackBar21 = New System.Windows.Forms.TrackBar()
        Me.TrackBar20 = New System.Windows.Forms.TrackBar()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.TrackBar19 = New System.Windows.Forms.TrackBar()
        Me.TrackBar23 = New System.Windows.Forms.TrackBar()
        Me.TrackBar24 = New System.Windows.Forms.TrackBar()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar24, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TrackBar3
        '
        Me.TrackBar3.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar3.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar3.Location = New System.Drawing.Point(688, 42)
        Me.TrackBar3.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar3.Maximum = 3
        Me.TrackBar3.Name = "TrackBar3"
        Me.TrackBar3.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar3.TabIndex = 69
        '
        'TrackBar4
        '
        Me.TrackBar4.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar4.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar4.Location = New System.Drawing.Point(688, 61)
        Me.TrackBar4.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar4.Maximum = 3
        Me.TrackBar4.Name = "TrackBar4"
        Me.TrackBar4.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar4.TabIndex = 70
        '
        'TrackBar5
        '
        Me.TrackBar5.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar5.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar5.Location = New System.Drawing.Point(688, 99)
        Me.TrackBar5.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar5.Maximum = 3
        Me.TrackBar5.Name = "TrackBar5"
        Me.TrackBar5.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar5.TabIndex = 71
        '
        'TrackBar7
        '
        Me.TrackBar7.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar7.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar7.Location = New System.Drawing.Point(688, 118)
        Me.TrackBar7.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar7.Maximum = 3
        Me.TrackBar7.Name = "TrackBar7"
        Me.TrackBar7.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar7.TabIndex = 72
        '
        'TrackBar8
        '
        Me.TrackBar8.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar8.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar8.Location = New System.Drawing.Point(688, 156)
        Me.TrackBar8.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar8.Maximum = 3
        Me.TrackBar8.Name = "TrackBar8"
        Me.TrackBar8.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar8.TabIndex = 73
        '
        'TrackBar9
        '
        Me.TrackBar9.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar9.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar9.Location = New System.Drawing.Point(688, 175)
        Me.TrackBar9.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar9.Maximum = 3
        Me.TrackBar9.Name = "TrackBar9"
        Me.TrackBar9.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar9.TabIndex = 74
        '
        'TrackBar11
        '
        Me.TrackBar11.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar11.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar11.Location = New System.Drawing.Point(688, 194)
        Me.TrackBar11.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar11.Maximum = 3
        Me.TrackBar11.Name = "TrackBar11"
        Me.TrackBar11.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar11.TabIndex = 75
        '
        'TrackBar12
        '
        Me.TrackBar12.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar12.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar12.Location = New System.Drawing.Point(688, 213)
        Me.TrackBar12.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar12.Maximum = 3
        Me.TrackBar12.Name = "TrackBar12"
        Me.TrackBar12.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar12.TabIndex = 76
        '
        'TrackBar13
        '
        Me.TrackBar13.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar13.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar13.Location = New System.Drawing.Point(688, 232)
        Me.TrackBar13.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar13.Maximum = 3
        Me.TrackBar13.Name = "TrackBar13"
        Me.TrackBar13.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar13.TabIndex = 77
        '
        'TrackBar15
        '
        Me.TrackBar15.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar15.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar15.Location = New System.Drawing.Point(688, 251)
        Me.TrackBar15.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar15.Maximum = 3
        Me.TrackBar15.Name = "TrackBar15"
        Me.TrackBar15.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar15.TabIndex = 78
        '
        'TrackBar16
        '
        Me.TrackBar16.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar16.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar16.Location = New System.Drawing.Point(688, 270)
        Me.TrackBar16.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar16.Maximum = 3
        Me.TrackBar16.Name = "TrackBar16"
        Me.TrackBar16.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar16.TabIndex = 79
        '
        'TrackBar17
        '
        Me.TrackBar17.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar17.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar17.Location = New System.Drawing.Point(688, 289)
        Me.TrackBar17.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar17.Maximum = 3
        Me.TrackBar17.Name = "TrackBar17"
        Me.TrackBar17.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar17.TabIndex = 80
        '
        'TrackBar18
        '
        Me.TrackBar18.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar18.Location = New System.Drawing.Point(688, 308)
        Me.TrackBar18.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar18.Maximum = 3
        Me.TrackBar18.Name = "TrackBar18"
        Me.TrackBar18.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar18.TabIndex = 81
        Me.TrackBar18.Tag = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(908, 22)
        Me.Label2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 16)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Not Important"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(908, 41)
        Me.Label3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 16)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Not Important"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(908, 60)
        Me.Label4.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 16)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Not Important"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(908, 98)
        Me.Label5.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(91, 16)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Not Important"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(908, 117)
        Me.Label7.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(91, 16)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Not Important"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(908, 155)
        Me.Label8.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(91, 16)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Not Important"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(908, 174)
        Me.Label9.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(91, 16)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Not Important"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(908, 193)
        Me.Label11.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(91, 16)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Not Important"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(908, 212)
        Me.Label12.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(91, 16)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "Not Important"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(908, 231)
        Me.Label13.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(91, 16)
        Me.Label13.TabIndex = 32
        Me.Label13.Text = "Not Important"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(908, 250)
        Me.Label15.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(91, 16)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "Not Important"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(908, 269)
        Me.Label16.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(91, 16)
        Me.Label16.TabIndex = 35
        Me.Label16.Text = "Not Important"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(908, 288)
        Me.Label17.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(91, 16)
        Me.Label17.TabIndex = 36
        Me.Label17.Text = "Not Important"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(908, 307)
        Me.Label18.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(91, 16)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "Not Important"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(4, 174)
        Me.Label35.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(451, 16)
        Me.Label35.TabIndex = 50
        Me.Label35.Text = "Rate the Importance of Capacity on Your Decision to Select Equipment"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(4, 3)
        Me.Label25.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(105, 16)
        Me.Label25.TabIndex = 51
        Me.Label25.Text = "Social Criteria"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(4, 22)
        Me.Label27.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(541, 16)
        Me.Label27.TabIndex = 53
        Me.Label27.Text = "Rate the Importance of Operator Competence  on Your Decision to Select Equipment"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(4, 41)
        Me.Label28.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(436, 16)
        Me.Label28.TabIndex = 54
        Me.Label28.Text = "Rate the Importance of Safety on Your Decision to Select Equipment"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(4, 60)
        Me.Label29.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(520, 16)
        Me.Label29.TabIndex = 55
        Me.Label29.Text = "Rate the Importance of Managerial Decisionon Your Decision to Select Equipment"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Arial", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(4, 79)
        Me.Label31.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(131, 16)
        Me.Label31.TabIndex = 56
        Me.Label31.Text = "Economic Criteria"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(4, 98)
        Me.Label30.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(536, 16)
        Me.Label30.TabIndex = 57
        Me.Label30.Text = "Rate the Importance of Ownership Cost Effect on Your Decision to Select Equipment" &
    ""
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(4, 117)
        Me.Label32.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(492, 16)
        Me.Label32.TabIndex = 58
        Me.Label32.Text = "Rate the Importance of Operating Cost on Your Decision to Select Equipment"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(4, 155)
        Me.Label33.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(469, 16)
        Me.Label33.TabIndex = 59
        Me.Label33.Text = "Rate the Importance of Productivity on Your Decision to Select Equipment"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Arial", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(4, 136)
        Me.Label34.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(129, 16)
        Me.Label34.TabIndex = 60
        Me.Label34.Text = "Technical Criteria"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(4, 212)
        Me.Label36.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(633, 16)
        Me.Label36.TabIndex = 61
        Me.Label36.Text = "Rate the Importance of Function, Design and Equipment Characteristics on Your Dec" &
    "ision to Select Equipment"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(4, 231)
        Me.Label37.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(461, 16)
        Me.Label37.TabIndex = 62
        Me.Label37.Text = "Rate the Importance of Innovation on Your Decision to Select Equipment"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(4, 250)
        Me.Label38.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(636, 16)
        Me.Label38.TabIndex = 64
        Me.Label38.Text = "Rate the Importance of Maintenance, Down Time and Machine Reliability on Your Dec" &
    "ision to Select Equipment"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(4, 269)
        Me.Label39.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(671, 16)
        Me.Label39.TabIndex = 65
        Me.Label39.Text = "Rate the Importance of Operating Conditions and Job requirements on Your Decision" &
    " to Select Equipment"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(4, 326)
        Me.Label40.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(553, 16)
        Me.Label40.TabIndex = 67
        Me.Label40.Text = "Rate the Importance of Robotics and Automation on Your Decision to Select Equipme" &
    "nt"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(917, 501)
        Me.Button2.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(126, 35)
        Me.Button2.TabIndex = 75
        Me.Button2.Text = "Next"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 681.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 217.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 218.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar3, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar4, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar11, 1, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar12, 1, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar13, 1, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label36, 0, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.Label37, 0, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar15, 1, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar16, 1, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar17, 1, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar22, 1, 21)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar21, 1, 20)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar20, 1, 19)
        Me.TableLayoutPanel1.Controls.Add(Me.Label44, 0, 19)
        Me.TableLayoutPanel1.Controls.Add(Me.Label45, 0, 20)
        Me.TableLayoutPanel1.Controls.Add(Me.Label46, 0, 21)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar7, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar9, 1, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label39, 0, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.Label38, 0, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 22)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 23)
        Me.TableLayoutPanel1.Controls.Add(Me.Label43, 0, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.Label42, 0, 18)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar18, 1, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar19, 1, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar23, 1, 22)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar24, 1, 23)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 2, 21)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 2, 20)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 2, 19)
        Me.TableLayoutPanel1.Controls.Add(Me.Label19, 2, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 2, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 2, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 2, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 2, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 2, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 2, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 2, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 2, 22)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 2, 23)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label29, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label31, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label30, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label32, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label34, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label33, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar5, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar8, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label35, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 0, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Label40, 0, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.Label41, 0, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 8)
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 4)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 25
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1039, 480)
        Me.TableLayoutPanel1.TabIndex = 76
        '
        'TrackBar2
        '
        Me.TrackBar2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar2.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar2.Location = New System.Drawing.Point(688, 23)
        Me.TrackBar2.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar2.Maximum = 3
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar2.TabIndex = 68
        '
        'TrackBar22
        '
        Me.TrackBar22.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar22.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar22.Location = New System.Drawing.Point(688, 403)
        Me.TrackBar22.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar22.Maximum = 3
        Me.TrackBar22.Name = "TrackBar22"
        Me.TrackBar22.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar22.TabIndex = 85
        Me.TrackBar22.Tag = ""
        '
        'TrackBar21
        '
        Me.TrackBar21.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar21.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar21.Location = New System.Drawing.Point(688, 384)
        Me.TrackBar21.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar21.Maximum = 3
        Me.TrackBar21.Name = "TrackBar21"
        Me.TrackBar21.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar21.TabIndex = 84
        Me.TrackBar21.Tag = ""
        '
        'TrackBar20
        '
        Me.TrackBar20.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar20.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar20.Location = New System.Drawing.Point(688, 365)
        Me.TrackBar20.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar20.Maximum = 3
        Me.TrackBar20.Name = "TrackBar20"
        Me.TrackBar20.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar20.TabIndex = 83
        Me.TrackBar20.Tag = ""
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(4, 364)
        Me.Label44.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(482, 16)
        Me.Label44.TabIndex = 76
        Me.Label44.Text = "Rate the Importance of Gas Emission on Your Decision to Select Equipment"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(4, 383)
        Me.Label45.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(646, 16)
        Me.Label45.TabIndex = 74
        Me.Label45.Text = "Rate the Importance of Use of Biodegradable Lubricants and Hydraulic Oil on Your " &
    "Decision to Select Equipment"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(4, 402)
        Me.Label46.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(645, 16)
        Me.Label46.TabIndex = 78
        Me.Label46.Text = "Rate the Importance of Fuel Combustion (Type  and it’s Degree of Sustainability) " &
    "on Your Decision to Select Equipment"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 421)
        Me.Label1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(481, 16)
        Me.Label1.TabIndex = 91
        Me.Label1.Text = "Rate the Importance of Noise Control on Your Decision to Select Equipment"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 440)
        Me.Label6.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(502, 16)
        Me.Label6.TabIndex = 92
        Me.Label6.Text = "Rate the Importance of Vibration Control on Your Decision to Select Equipment"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(4, 307)
        Me.Label43.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(488, 16)
        Me.Label43.TabIndex = 75
        Me.Label43.Text = "Rate the Importance of Fuel Efficiency on Your Decision to Select Equipment"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Arial", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(4, 345)
        Me.Label42.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(165, 16)
        Me.Label42.TabIndex = 77
        Me.Label42.Text = "Environmental Criteria"
        '
        'TrackBar19
        '
        Me.TrackBar19.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar19.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar19.Location = New System.Drawing.Point(688, 327)
        Me.TrackBar19.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar19.Maximum = 3
        Me.TrackBar19.Name = "TrackBar19"
        Me.TrackBar19.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar19.TabIndex = 82
        Me.TrackBar19.Tag = ""
        '
        'TrackBar23
        '
        Me.TrackBar23.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar23.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar23.Location = New System.Drawing.Point(688, 422)
        Me.TrackBar23.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar23.Maximum = 3
        Me.TrackBar23.Name = "TrackBar23"
        Me.TrackBar23.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar23.TabIndex = 93
        Me.TrackBar23.Tag = ""
        '
        'TrackBar24
        '
        Me.TrackBar24.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TrackBar24.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar24.Location = New System.Drawing.Point(688, 441)
        Me.TrackBar24.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.TrackBar24.Maximum = 3
        Me.TrackBar24.Name = "TrackBar24"
        Me.TrackBar24.Size = New System.Drawing.Size(196, 14)
        Me.TrackBar24.TabIndex = 94
        Me.TrackBar24.Tag = ""
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(908, 402)
        Me.Label22.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(91, 16)
        Me.Label22.TabIndex = 90
        Me.Label22.Text = "Not Important"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(908, 383)
        Me.Label21.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(91, 16)
        Me.Label21.TabIndex = 89
        Me.Label21.Text = "Not Important"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(908, 364)
        Me.Label20.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(91, 16)
        Me.Label20.TabIndex = 88
        Me.Label20.Text = "Not Important"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(908, 326)
        Me.Label19.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(91, 16)
        Me.Label19.TabIndex = 87
        Me.Label19.Text = "Not Important"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(908, 421)
        Me.Label23.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(91, 16)
        Me.Label23.TabIndex = 95
        Me.Label23.Text = "Not Important"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(908, 440)
        Me.Label24.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(91, 16)
        Me.Label24.TabIndex = 96
        Me.Label24.Text = "Not Important"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 193)
        Me.Label10.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(550, 16)
        Me.Label10.TabIndex = 97
        Me.Label10.Text = "Rate the Importance of Performance and Speed on Your Decision to Select Equipment" &
    ""
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(4, 288)
        Me.Label41.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(531, 16)
        Me.Label41.TabIndex = 73
        Me.Label41.Text = "Rate the Importance of Operational Flexibility on Your Decision to Select Equipme" &
    "nt"
        '
        'Importance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1079, 558)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.Name = "Importance"
        Me.Text = "Assessment of Criteria Importance"
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar24, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TrackBar3 As TrackBar
    Friend WithEvents TrackBar4 As TrackBar
    Friend WithEvents TrackBar5 As TrackBar
    Friend WithEvents TrackBar7 As TrackBar
    Friend WithEvents TrackBar8 As TrackBar
    Friend WithEvents TrackBar9 As TrackBar
    Friend WithEvents TrackBar11 As TrackBar
    Friend WithEvents TrackBar12 As TrackBar
    Friend WithEvents TrackBar13 As TrackBar
    Friend WithEvents TrackBar15 As TrackBar
    Friend WithEvents TrackBar16 As TrackBar
    Friend WithEvents TrackBar17 As TrackBar
    Friend WithEvents TrackBar18 As TrackBar
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TrackBar2 As TrackBar
    Friend WithEvents TrackBar19 As TrackBar
    Friend WithEvents Label41 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents TrackBar22 As TrackBar
    Friend WithEvents TrackBar21 As TrackBar
    Friend WithEvents TrackBar20 As TrackBar
    Friend WithEvents Label46 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TrackBar23 As TrackBar
    Friend WithEvents TrackBar24 As TrackBar
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label10 As Label
End Class
