﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPA = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPB = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPC = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPD = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM5A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM5B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM5C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM5D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM5A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM5B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM5C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM5D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM5A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM5B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM5C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM5D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsuba = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubb = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubc = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubd = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM5a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM5b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM5c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM5d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.IMPA, Me.IMPB, Me.IMPC, Me.IMPD, Me.RM1A, Me.RM1B, Me.RM1C, Me.RM1D, Me.RM2A, Me.RM2B, Me.RM2C, Me.RM2D, Me.RM3A, Me.RM3B, Me.RM3C, Me.RM3D, Me.RM4A, Me.RM4B, Me.RM4C, Me.RM4D, Me.RM5A, Me.RM5B, Me.RM5C, Me.RM5D, Me.RXIMM1A, Me.RXIMM1b, Me.RXIMM1C, Me.RXIMM1d, Me.RXIMM2A, Me.RXIMM2B, Me.RXIMM2C, Me.RXIMM2D, Me.RXIMM3A, Me.RXIMM3B, Me.RXIMM3C, Me.RXIMM3D, Me.RXIMM4A, Me.RXIMM4B, Me.RXIMM4C, Me.RXIMM4D, Me.RXIMM5A, Me.RXIMM5B, Me.RXIMM5C, Me.RXIMM5D, Me.sumwiriM1A, Me.sumwiriM1B, Me.sumwiriM1C, Me.sumwiriM1D, Me.sumwiriM2A, Me.sumwiriM2B, Me.sumwiriM2C, Me.sumwiriM2D, Me.sumwiriM3A, Me.sumwiriM3B, Me.sumwiriM3C, Me.sumwiriM3D, Me.sumwiriM4A, Me.sumwiriM4B, Me.sumwiriM4C, Me.sumwiriM4D, Me.sumwiriM5A, Me.sumwiriM5B, Me.sumwiriM5C, Me.sumwiriM5D, Me.Sumwsuba, Me.Sumwsubb, Me.Sumwsubc, Me.Sumwsubd, Me.sumwiridivsumwM1a, Me.sumwiridivsumwM1b, Me.sumwiridivsumwM1c, Me.sumwiridivsumwM1d, Me.sumwiridivsumwM2a, Me.sumwiridivsumwM2b, Me.sumwiridivsumwM2c, Me.sumwiridivsumwM2d, Me.sumwiridivsumwM3a, Me.sumwiridivsumwM3b, Me.sumwiridivsumwM3c, Me.sumwiridivsumwM3d, Me.sumwiridivsumwM4a, Me.sumwiridivsumwM4b, Me.sumwiridivsumwM4c, Me.sumwiridivsumwM4d, Me.sumwiridivsumwM5a, Me.sumwiridivsumwM5b, Me.sumwiridivsumwM5c, Me.sumwiridivsumwM5d, Me.EQ1, Me.EQ2, Me.EQ3, Me.EQ4, Me.EQ5})
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.Margin = New System.Windows.Forms.Padding(1)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(1464, 544)
        Me.ListView1.TabIndex = 1
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Width = 65
        '
        'IMPA
        '
        Me.IMPA.Tag = ""
        Me.IMPA.Text = "IMPA"
        Me.IMPA.Width = 65
        '
        'IMPB
        '
        Me.IMPB.Tag = ""
        Me.IMPB.Text = "IMPB"
        Me.IMPB.Width = 65
        '
        'IMPC
        '
        Me.IMPC.Tag = ""
        Me.IMPC.Text = "IMPC"
        Me.IMPC.Width = 65
        '
        'IMPD
        '
        Me.IMPD.Tag = ""
        Me.IMPD.Text = "IMPD"
        Me.IMPD.Width = 65
        '
        'RM1A
        '
        Me.RM1A.Text = "RM1A"
        Me.RM1A.Width = 65
        '
        'RM1B
        '
        Me.RM1B.Text = "RM1B"
        Me.RM1B.Width = 65
        '
        'RM1C
        '
        Me.RM1C.Text = "RM1C"
        Me.RM1C.Width = 65
        '
        'RM1D
        '
        Me.RM1D.Text = "RM1D"
        Me.RM1D.Width = 65
        '
        'RM2A
        '
        Me.RM2A.Text = "RM2A"
        Me.RM2A.Width = 65
        '
        'RM2B
        '
        Me.RM2B.Text = "RM2B"
        Me.RM2B.Width = 65
        '
        'RM2C
        '
        Me.RM2C.Text = "RM2C"
        Me.RM2C.Width = 65
        '
        'RM2D
        '
        Me.RM2D.Text = "RM2D"
        Me.RM2D.Width = 65
        '
        'RM3A
        '
        Me.RM3A.Text = "RM3A"
        Me.RM3A.Width = 65
        '
        'RM3B
        '
        Me.RM3B.Text = "RM3B"
        Me.RM3B.Width = 65
        '
        'RM3C
        '
        Me.RM3C.Text = "RM3C"
        Me.RM3C.Width = 65
        '
        'RM3D
        '
        Me.RM3D.Text = "RM3D"
        Me.RM3D.Width = 65
        '
        'RM4A
        '
        Me.RM4A.Text = "RM4A"
        Me.RM4A.Width = 65
        '
        'RM4B
        '
        Me.RM4B.Text = "RM4B"
        Me.RM4B.Width = 65
        '
        'RM4C
        '
        Me.RM4C.Text = "RM4C"
        Me.RM4C.Width = 65
        '
        'RM4D
        '
        Me.RM4D.Text = "RM4D"
        Me.RM4D.Width = 65
        '
        'RM5A
        '
        Me.RM5A.Text = "RM5A"
        Me.RM5A.Width = 65
        '
        'RM5B
        '
        Me.RM5B.Text = "RM5B"
        Me.RM5B.Width = 65
        '
        'RM5C
        '
        Me.RM5C.Text = "RM5C"
        Me.RM5C.Width = 65
        '
        'RM5D
        '
        Me.RM5D.Text = "RM5D"
        Me.RM5D.Width = 65
        '
        'RXIMM1A
        '
        Me.RXIMM1A.Text = "RXIMM1A"
        Me.RXIMM1A.Width = 65
        '
        'RXIMM1b
        '
        Me.RXIMM1b.Text = "RXIMM1b"
        Me.RXIMM1b.Width = 65
        '
        'RXIMM1C
        '
        Me.RXIMM1C.Text = "RXIMM1C"
        Me.RXIMM1C.Width = 65
        '
        'RXIMM1d
        '
        Me.RXIMM1d.Text = "RXIMM1d"
        Me.RXIMM1d.Width = 65
        '
        'RXIMM2A
        '
        Me.RXIMM2A.Text = "RXIMM2A"
        Me.RXIMM2A.Width = 65
        '
        'RXIMM2B
        '
        Me.RXIMM2B.Text = "RXIMM2B"
        Me.RXIMM2B.Width = 65
        '
        'RXIMM2C
        '
        Me.RXIMM2C.Text = "RXIMM2C"
        Me.RXIMM2C.Width = 65
        '
        'RXIMM2D
        '
        Me.RXIMM2D.Text = "RXIMM2D"
        Me.RXIMM2D.Width = 65
        '
        'RXIMM3A
        '
        Me.RXIMM3A.Text = "RXIMM3A"
        Me.RXIMM3A.Width = 65
        '
        'RXIMM3B
        '
        Me.RXIMM3B.Text = "RXIMM3B"
        Me.RXIMM3B.Width = 65
        '
        'RXIMM3C
        '
        Me.RXIMM3C.Text = "RXIMM3C"
        Me.RXIMM3C.Width = 65
        '
        'RXIMM3D
        '
        Me.RXIMM3D.Text = "RXIMM3D"
        Me.RXIMM3D.Width = 65
        '
        'RXIMM4A
        '
        Me.RXIMM4A.Text = "RXIMM4A"
        Me.RXIMM4A.Width = 65
        '
        'RXIMM4B
        '
        Me.RXIMM4B.Text = "RXIMM4B"
        Me.RXIMM4B.Width = 65
        '
        'RXIMM4C
        '
        Me.RXIMM4C.Text = "RXIMM4C"
        Me.RXIMM4C.Width = 65
        '
        'RXIMM4D
        '
        Me.RXIMM4D.Text = "RXIMM4D"
        Me.RXIMM4D.Width = 65
        '
        'RXIMM5A
        '
        Me.RXIMM5A.Text = "RXIMM5A"
        Me.RXIMM5A.Width = 65
        '
        'RXIMM5B
        '
        Me.RXIMM5B.Text = "RXIMM5B"
        Me.RXIMM5B.Width = 65
        '
        'RXIMM5C
        '
        Me.RXIMM5C.Text = "RXIMM5C"
        Me.RXIMM5C.Width = 65
        '
        'RXIMM5D
        '
        Me.RXIMM5D.Text = "RXIMM5D"
        Me.RXIMM5D.Width = 65
        '
        'sumwiriM1A
        '
        Me.sumwiriM1A.Text = "sumwiriM1A"
        Me.sumwiriM1A.Width = 65
        '
        'sumwiriM1B
        '
        Me.sumwiriM1B.Text = "sumwirM1B"
        Me.sumwiriM1B.Width = 65
        '
        'sumwiriM1C
        '
        Me.sumwiriM1C.Text = "sumwiriM1C"
        Me.sumwiriM1C.Width = 65
        '
        'sumwiriM1D
        '
        Me.sumwiriM1D.Text = "sumwiriM1D"
        Me.sumwiriM1D.Width = 65
        '
        'sumwiriM2A
        '
        Me.sumwiriM2A.Text = "sumwiriM2A"
        Me.sumwiriM2A.Width = 65
        '
        'sumwiriM2B
        '
        Me.sumwiriM2B.Text = "sumwiriM2B"
        Me.sumwiriM2B.Width = 65
        '
        'sumwiriM2C
        '
        Me.sumwiriM2C.Text = "sumwiriM2C"
        Me.sumwiriM2C.Width = 65
        '
        'sumwiriM2D
        '
        Me.sumwiriM2D.Text = "sumwiriM2D"
        Me.sumwiriM2D.Width = 65
        '
        'sumwiriM3A
        '
        Me.sumwiriM3A.Text = "sumwiriM3A"
        Me.sumwiriM3A.Width = 65
        '
        'sumwiriM3B
        '
        Me.sumwiriM3B.Text = "sumwiriM3B"
        Me.sumwiriM3B.Width = 65
        '
        'sumwiriM3C
        '
        Me.sumwiriM3C.Text = "sumwiriM3C"
        Me.sumwiriM3C.Width = 65
        '
        'sumwiriM3D
        '
        Me.sumwiriM3D.Text = "sumwiriM3D"
        Me.sumwiriM3D.Width = 65
        '
        'sumwiriM4A
        '
        Me.sumwiriM4A.Text = "sumwiriM4A"
        Me.sumwiriM4A.Width = 65
        '
        'sumwiriM4B
        '
        Me.sumwiriM4B.Text = "sumwiriM4B"
        Me.sumwiriM4B.Width = 65
        '
        'sumwiriM4C
        '
        Me.sumwiriM4C.Text = "sumwiriM4C"
        Me.sumwiriM4C.Width = 65
        '
        'sumwiriM4D
        '
        Me.sumwiriM4D.Text = "sumwiriM4D"
        Me.sumwiriM4D.Width = 65
        '
        'sumwiriM5A
        '
        Me.sumwiriM5A.Text = "sumwiriM5A"
        Me.sumwiriM5A.Width = 65
        '
        'sumwiriM5B
        '
        Me.sumwiriM5B.Text = "sumwiriM5B"
        Me.sumwiriM5B.Width = 65
        '
        'sumwiriM5C
        '
        Me.sumwiriM5C.Text = "sumwiriM5C"
        Me.sumwiriM5C.Width = 65
        '
        'sumwiriM5D
        '
        Me.sumwiriM5D.Text = "sumwiriM5D"
        Me.sumwiriM5D.Width = 65
        '
        'Sumwsuba
        '
        Me.Sumwsuba.Text = "Sumwsuba"
        Me.Sumwsuba.Width = 65
        '
        'Sumwsubb
        '
        Me.Sumwsubb.Text = "Sumwsuba"
        Me.Sumwsubb.Width = 65
        '
        'Sumwsubc
        '
        Me.Sumwsubc.Text = "Sumwsubc"
        Me.Sumwsubc.Width = 65
        '
        'Sumwsubd
        '
        Me.Sumwsubd.Text = "Sumwsubd"
        Me.Sumwsubd.Width = 65
        '
        'sumwiridivsumwM1a
        '
        Me.sumwiridivsumwM1a.Text = "sumwiridivsumwM1a"
        Me.sumwiridivsumwM1a.Width = 65
        '
        'sumwiridivsumwM1b
        '
        Me.sumwiridivsumwM1b.Text = "sumwiridivsumwM1b"
        Me.sumwiridivsumwM1b.Width = 65
        '
        'sumwiridivsumwM1c
        '
        Me.sumwiridivsumwM1c.Text = "sumwiridivsumwM1c"
        Me.sumwiridivsumwM1c.Width = 65
        '
        'sumwiridivsumwM1d
        '
        Me.sumwiridivsumwM1d.Text = "sumwiridivsumwM1d"
        Me.sumwiridivsumwM1d.Width = 65
        '
        'sumwiridivsumwM2a
        '
        Me.sumwiridivsumwM2a.Text = "sumwiridivsumwM2a"
        Me.sumwiridivsumwM2a.Width = 65
        '
        'sumwiridivsumwM2b
        '
        Me.sumwiridivsumwM2b.Text = "sumwiridivsumwM2b"
        Me.sumwiridivsumwM2b.Width = 65
        '
        'sumwiridivsumwM2c
        '
        Me.sumwiridivsumwM2c.Text = "sumwiridivsumwM2c"
        Me.sumwiridivsumwM2c.Width = 65
        '
        'sumwiridivsumwM2d
        '
        Me.sumwiridivsumwM2d.Text = "sumwiridivsumwM2d"
        Me.sumwiridivsumwM2d.Width = 65
        '
        'sumwiridivsumwM3a
        '
        Me.sumwiridivsumwM3a.Text = "sumwiridivsumwM3a"
        Me.sumwiridivsumwM3a.Width = 65
        '
        'sumwiridivsumwM3b
        '
        Me.sumwiridivsumwM3b.Text = "sumwiridivsumwM3b"
        Me.sumwiridivsumwM3b.Width = 65
        '
        'sumwiridivsumwM3c
        '
        Me.sumwiridivsumwM3c.Text = "sumwiridivsumwM3c"
        Me.sumwiridivsumwM3c.Width = 65
        '
        'sumwiridivsumwM3d
        '
        Me.sumwiridivsumwM3d.Text = "sumwiridivsumwM3d"
        Me.sumwiridivsumwM3d.Width = 65
        '
        'sumwiridivsumwM4a
        '
        Me.sumwiridivsumwM4a.Text = "sumwiridivsumwM4a"
        Me.sumwiridivsumwM4a.Width = 65
        '
        'sumwiridivsumwM4b
        '
        Me.sumwiridivsumwM4b.Text = "sumwiridivsumwM4b"
        Me.sumwiridivsumwM4b.Width = 65
        '
        'sumwiridivsumwM4c
        '
        Me.sumwiridivsumwM4c.Text = "sumwiridivsumwM4c"
        Me.sumwiridivsumwM4c.Width = 65
        '
        'sumwiridivsumwM4d
        '
        Me.sumwiridivsumwM4d.Text = "sumwiridivsumwM4d"
        Me.sumwiridivsumwM4d.Width = 65
        '
        'sumwiridivsumwM5a
        '
        Me.sumwiridivsumwM5a.Text = "sumwiridivsumwM5a"
        Me.sumwiridivsumwM5a.Width = 65
        '
        'sumwiridivsumwM5b
        '
        Me.sumwiridivsumwM5b.Text = "sumwiridivsumwM5b"
        Me.sumwiridivsumwM5b.Width = 65
        '
        'sumwiridivsumwM5c
        '
        Me.sumwiridivsumwM5c.Text = "sumwiridivsumwM5c"
        Me.sumwiridivsumwM5c.Width = 65
        '
        'sumwiridivsumwM5d
        '
        Me.sumwiridivsumwM5d.Text = "sumwiridivsumwM5d"
        Me.sumwiridivsumwM5d.Width = 65
        '
        'EQ1
        '
        Me.EQ1.Text = "EQ1"
        Me.EQ1.Width = 65
        '
        'EQ2
        '
        Me.EQ2.Text = "EQ2"
        Me.EQ2.Width = 65
        '
        'EQ3
        '
        Me.EQ3.Text = "EQ3"
        Me.EQ3.Width = 65
        '
        'EQ4
        '
        Me.EQ4.Text = "EQ4"
        Me.EQ4.Width = 65
        '
        'EQ5
        '
        Me.EQ5.Text = "EQ5"
        Me.EQ5.Width = 65
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1464, 544)
        Me.Controls.Add(Me.ListView1)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "Form3"
        Me.Text = "Five Equipments Results"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents IMPA As ColumnHeader
    Friend WithEvents IMPB As ColumnHeader
    Friend WithEvents IMPC As ColumnHeader
    Friend WithEvents IMPD As ColumnHeader
    Friend WithEvents RM1A As ColumnHeader
    Friend WithEvents RM1B As ColumnHeader
    Friend WithEvents RM1C As ColumnHeader
    Friend WithEvents RM1D As ColumnHeader
    Friend WithEvents RM2A As ColumnHeader
    Friend WithEvents RM2B As ColumnHeader
    Friend WithEvents RM2C As ColumnHeader
    Friend WithEvents RM2D As ColumnHeader
    Friend WithEvents RM3A As ColumnHeader
    Friend WithEvents RM3B As ColumnHeader
    Friend WithEvents RM3C As ColumnHeader
    Friend WithEvents RM3D As ColumnHeader
    Friend WithEvents RM4A As ColumnHeader
    Friend WithEvents RM4B As ColumnHeader
    Friend WithEvents RM4C As ColumnHeader
    Friend WithEvents RM4D As ColumnHeader
    Friend WithEvents RM5A As ColumnHeader
    Friend WithEvents RM5B As ColumnHeader
    Friend WithEvents RM5C As ColumnHeader
    Friend WithEvents RM5D As ColumnHeader
    Friend WithEvents RXIMM1A As ColumnHeader
    Friend WithEvents RXIMM1b As ColumnHeader
    Friend WithEvents RXIMM1C As ColumnHeader
    Friend WithEvents RXIMM1d As ColumnHeader
    Friend WithEvents RXIMM2A As ColumnHeader
    Friend WithEvents RXIMM2B As ColumnHeader
    Friend WithEvents RXIMM2C As ColumnHeader
    Friend WithEvents RXIMM2D As ColumnHeader
    Friend WithEvents RXIMM3A As ColumnHeader
    Friend WithEvents RXIMM3B As ColumnHeader
    Friend WithEvents RXIMM3C As ColumnHeader
    Friend WithEvents RXIMM3D As ColumnHeader
    Friend WithEvents RXIMM4A As ColumnHeader
    Friend WithEvents RXIMM5A As ColumnHeader
    Friend WithEvents RXIMM5B As ColumnHeader
    Friend WithEvents RXIMM5C As ColumnHeader
    Friend WithEvents RXIMM5D As ColumnHeader
    Friend WithEvents RXIMM4B As ColumnHeader
    Friend WithEvents RXIMM4C As ColumnHeader
    Friend WithEvents RXIMM4D As ColumnHeader
    Friend WithEvents sumwiriM1A As ColumnHeader
    Friend WithEvents sumwiriM1B As ColumnHeader
    Friend WithEvents sumwiriM1C As ColumnHeader
    Friend WithEvents sumwiriM1D As ColumnHeader
    Friend WithEvents sumwiriM2A As ColumnHeader
    Friend WithEvents sumwiriM2B As ColumnHeader
    Friend WithEvents sumwiriM2C As ColumnHeader
    Friend WithEvents sumwiriM2D As ColumnHeader
    Friend WithEvents sumwiriM3A As ColumnHeader
    Friend WithEvents sumwiriM3B As ColumnHeader
    Friend WithEvents sumwiriM3C As ColumnHeader
    Friend WithEvents sumwiriM3D As ColumnHeader
    Friend WithEvents sumwiriM4A As ColumnHeader
    Friend WithEvents sumwiriM4B As ColumnHeader
    Friend WithEvents sumwiriM4C As ColumnHeader
    Friend WithEvents sumwiriM4D As ColumnHeader
    Friend WithEvents sumwiriM5A As ColumnHeader
    Friend WithEvents sumwiriM5B As ColumnHeader
    Friend WithEvents sumwiriM5C As ColumnHeader
    Friend WithEvents sumwiriM5D As ColumnHeader
    Friend WithEvents Sumwsuba As ColumnHeader
    Friend WithEvents Sumwsubb As ColumnHeader
    Friend WithEvents Sumwsubc As ColumnHeader
    Friend WithEvents Sumwsubd As ColumnHeader
    Friend WithEvents sumwiridivsumwM1a As ColumnHeader
    Friend WithEvents sumwiridivsumwM1b As ColumnHeader
    Friend WithEvents sumwiridivsumwM1c As ColumnHeader
    Friend WithEvents sumwiridivsumwM1d As ColumnHeader
    Friend WithEvents sumwiridivsumwM2a As ColumnHeader
    Friend WithEvents sumwiridivsumwM2b As ColumnHeader
    Friend WithEvents sumwiridivsumwM2c As ColumnHeader
    Friend WithEvents sumwiridivsumwM2d As ColumnHeader
    Friend WithEvents sumwiridivsumwM3a As ColumnHeader
    Friend WithEvents sumwiridivsumwM3b As ColumnHeader
    Friend WithEvents sumwiridivsumwM3c As ColumnHeader
    Friend WithEvents sumwiridivsumwM3d As ColumnHeader
    Friend WithEvents sumwiridivsumwM4a As ColumnHeader
    Friend WithEvents sumwiridivsumwM4b As ColumnHeader
    Friend WithEvents sumwiridivsumwM4c As ColumnHeader
    Friend WithEvents sumwiridivsumwM4d As ColumnHeader
    Friend WithEvents sumwiridivsumwM5a As ColumnHeader
    Friend WithEvents sumwiridivsumwM5b As ColumnHeader
    Friend WithEvents sumwiridivsumwM5c As ColumnHeader
    Friend WithEvents sumwiridivsumwM5d As ColumnHeader
    Friend WithEvents EQ1 As ColumnHeader
    Friend WithEvents EQ2 As ColumnHeader
    Friend WithEvents EQ3 As ColumnHeader
    Friend WithEvents EQ4 As ColumnHeader
    Friend WithEvents EQ5 As ColumnHeader
End Class
