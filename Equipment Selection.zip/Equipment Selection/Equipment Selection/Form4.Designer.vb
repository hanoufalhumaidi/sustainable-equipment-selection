﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPA = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPB = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPC = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IMPD = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM1D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM3D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RM4D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM1d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM3D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RXIMM4D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM1D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM2D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM3D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4A = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4B = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4C = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiriM4D = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsuba = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubb = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubc = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Sumwsubd = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM1d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM2d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM3d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4a = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4b = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4c = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sumwiridivsumwM4d = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.EQ4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.IMPA, Me.IMPB, Me.IMPC, Me.IMPD, Me.RM1A, Me.RM1B, Me.RM1C, Me.RM1D, Me.RM2A, Me.RM2B, Me.RM2C, Me.RM2D, Me.RM3A, Me.RM3B, Me.RM3C, Me.RM3D, Me.RM4A, Me.RM4B, Me.RM4C, Me.RM4D, Me.RXIMM1A, Me.RXIMM1b, Me.RXIMM1C, Me.RXIMM1d, Me.RXIMM2A, Me.RXIMM2B, Me.RXIMM2C, Me.RXIMM2D, Me.RXIMM3A, Me.RXIMM3B, Me.RXIMM3C, Me.RXIMM3D, Me.RXIMM4A, Me.RXIMM4B, Me.RXIMM4C, Me.RXIMM4D, Me.sumwiriM1A, Me.sumwiriM1B, Me.sumwiriM1C, Me.sumwiriM1D, Me.sumwiriM2A, Me.sumwiriM2B, Me.sumwiriM2C, Me.sumwiriM2D, Me.sumwiriM3A, Me.sumwiriM3B, Me.sumwiriM3C, Me.sumwiriM3D, Me.sumwiriM4A, Me.sumwiriM4B, Me.sumwiriM4C, Me.sumwiriM4D, Me.Sumwsuba, Me.Sumwsubb, Me.Sumwsubc, Me.Sumwsubd, Me.sumwiridivsumwM1a, Me.sumwiridivsumwM1b, Me.sumwiridivsumwM1c, Me.sumwiridivsumwM1d, Me.sumwiridivsumwM2a, Me.sumwiridivsumwM2b, Me.sumwiridivsumwM2c, Me.sumwiridivsumwM2d, Me.sumwiridivsumwM3a, Me.sumwiridivsumwM3b, Me.sumwiridivsumwM3c, Me.sumwiridivsumwM3d, Me.sumwiridivsumwM4a, Me.sumwiridivsumwM4b, Me.sumwiridivsumwM4c, Me.sumwiridivsumwM4d, Me.EQ1, Me.EQ2, Me.EQ3, Me.EQ4})
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.Margin = New System.Windows.Forms.Padding(1)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(1492, 386)
        Me.ListView1.TabIndex = 2
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'IMPA
        '
        Me.IMPA.Tag = ""
        Me.IMPA.Text = "IMPA"
        '
        'IMPB
        '
        Me.IMPB.Tag = ""
        Me.IMPB.Text = "IMPB"
        '
        'IMPC
        '
        Me.IMPC.Tag = ""
        Me.IMPC.Text = "IMPC"
        '
        'IMPD
        '
        Me.IMPD.Tag = ""
        Me.IMPD.Text = "IMPD"
        '
        'RM1A
        '
        Me.RM1A.Text = "RM1A"
        '
        'RM1B
        '
        Me.RM1B.Text = "RM1B"
        '
        'RM1C
        '
        Me.RM1C.Text = "RM1C"
        '
        'RM1D
        '
        Me.RM1D.Text = "RM1D"
        '
        'RM2A
        '
        Me.RM2A.Text = "RM2A"
        '
        'RM2B
        '
        Me.RM2B.Text = "RM2B"
        '
        'RM2C
        '
        Me.RM2C.Text = "RM2C"
        '
        'RM2D
        '
        Me.RM2D.Text = "RM2D"
        '
        'RM3A
        '
        Me.RM3A.Text = "RM3A"
        '
        'RM3B
        '
        Me.RM3B.Text = "RM3B"
        '
        'RM3C
        '
        Me.RM3C.Text = "RM3C"
        '
        'RM3D
        '
        Me.RM3D.Text = "RM3D"
        '
        'RM4A
        '
        Me.RM4A.Text = "RM4A"
        '
        'RM4B
        '
        Me.RM4B.Text = "RM4B"
        '
        'RM4C
        '
        Me.RM4C.Text = "RM4C"
        '
        'RM4D
        '
        Me.RM4D.Text = "RM4D"
        '
        'RXIMM1A
        '
        Me.RXIMM1A.Text = "RXIMM1A"
        '
        'RXIMM1b
        '
        Me.RXIMM1b.Text = "RXIMM1b"
        '
        'RXIMM1C
        '
        Me.RXIMM1C.Text = "RXIMM1C"
        '
        'RXIMM1d
        '
        Me.RXIMM1d.Text = "RXIMM1d"
        '
        'RXIMM2A
        '
        Me.RXIMM2A.Text = "RXIMM2A"
        '
        'RXIMM2B
        '
        Me.RXIMM2B.Text = "RXIMM2B"
        '
        'RXIMM2C
        '
        Me.RXIMM2C.Text = "RXIMM2C"
        '
        'RXIMM2D
        '
        Me.RXIMM2D.Text = "RXIMM2D"
        '
        'RXIMM3A
        '
        Me.RXIMM3A.Text = "RXIMM3A"
        '
        'RXIMM3B
        '
        Me.RXIMM3B.Text = "RXIMM3B"
        '
        'RXIMM3C
        '
        Me.RXIMM3C.Text = "RXIMM3C"
        '
        'RXIMM3D
        '
        Me.RXIMM3D.Text = "RXIMM3D"
        '
        'RXIMM4A
        '
        Me.RXIMM4A.Text = "RXIMM4A"
        '
        'RXIMM4B
        '
        Me.RXIMM4B.Text = "RXIMM4B"
        '
        'RXIMM4C
        '
        Me.RXIMM4C.Text = "RXIMM4C"
        '
        'RXIMM4D
        '
        Me.RXIMM4D.Text = "RXIMM4D"
        '
        'sumwiriM1A
        '
        Me.sumwiriM1A.Text = "sumwiriM1A"
        '
        'sumwiriM1B
        '
        Me.sumwiriM1B.Text = "sumwirM1B"
        '
        'sumwiriM1C
        '
        Me.sumwiriM1C.Text = "sumwiriM1C"
        '
        'sumwiriM1D
        '
        Me.sumwiriM1D.Text = "sumwiriM1D"
        '
        'sumwiriM2A
        '
        Me.sumwiriM2A.Text = "sumwiriM2A"
        '
        'sumwiriM2B
        '
        Me.sumwiriM2B.Text = "sumwiriM2B"
        '
        'sumwiriM2C
        '
        Me.sumwiriM2C.Text = "sumwiriM2C"
        '
        'sumwiriM2D
        '
        Me.sumwiriM2D.Text = "sumwiriM2D"
        '
        'sumwiriM3A
        '
        Me.sumwiriM3A.Text = "sumwiriM3A"
        '
        'sumwiriM3B
        '
        Me.sumwiriM3B.Text = "sumwiriM3B"
        '
        'sumwiriM3C
        '
        Me.sumwiriM3C.Text = "sumwiriM3C"
        '
        'sumwiriM3D
        '
        Me.sumwiriM3D.Text = "sumwiriM3D"
        '
        'sumwiriM4A
        '
        Me.sumwiriM4A.Text = "sumwiriM4A"
        '
        'sumwiriM4B
        '
        Me.sumwiriM4B.Text = "sumwiriM4B"
        '
        'sumwiriM4C
        '
        Me.sumwiriM4C.Text = "sumwiriM4C"
        '
        'sumwiriM4D
        '
        Me.sumwiriM4D.Text = "sumwiriM4D"
        '
        'Sumwsuba
        '
        Me.Sumwsuba.Text = "Sumwsuba"
        '
        'Sumwsubb
        '
        Me.Sumwsubb.Text = "Sumwsubb"
        '
        'Sumwsubc
        '
        Me.Sumwsubc.Text = "Sumwsubc"
        '
        'Sumwsubd
        '
        Me.Sumwsubd.Text = "Sumwsubd"
        '
        'sumwiridivsumwM1a
        '
        Me.sumwiridivsumwM1a.Text = "sumwiridivsumwM1a"
        '
        'sumwiridivsumwM1b
        '
        Me.sumwiridivsumwM1b.Text = "sumwiridivsumwM1b"
        '
        'sumwiridivsumwM1c
        '
        Me.sumwiridivsumwM1c.Text = "sumwiridivsumwM1c"
        '
        'sumwiridivsumwM1d
        '
        Me.sumwiridivsumwM1d.Text = "sumwiridivsumwM1d"
        '
        'sumwiridivsumwM2a
        '
        Me.sumwiridivsumwM2a.Text = "sumwiridivsumwM2a"
        '
        'sumwiridivsumwM2b
        '
        Me.sumwiridivsumwM2b.Text = "sumwiridivsumwM2b"
        '
        'sumwiridivsumwM2c
        '
        Me.sumwiridivsumwM2c.Text = "sumwiridivsumwM2c"
        '
        'sumwiridivsumwM2d
        '
        Me.sumwiridivsumwM2d.Text = "sumwiridivsumwM2d"
        '
        'sumwiridivsumwM3a
        '
        Me.sumwiridivsumwM3a.Text = "sumwiridivsumwM3a"
        '
        'sumwiridivsumwM3b
        '
        Me.sumwiridivsumwM3b.Text = "sumwiridivsumwM3b"
        '
        'sumwiridivsumwM3c
        '
        Me.sumwiridivsumwM3c.Text = "sumwiridivsumwM3c"
        '
        'sumwiridivsumwM3d
        '
        Me.sumwiridivsumwM3d.Text = "sumwiridivsumwM3d"
        '
        'sumwiridivsumwM4a
        '
        Me.sumwiridivsumwM4a.Text = "sumwiridivsumwM4a"
        '
        'sumwiridivsumwM4b
        '
        Me.sumwiridivsumwM4b.Text = "sumwiridivsumwM4b"
        '
        'sumwiridivsumwM4c
        '
        Me.sumwiridivsumwM4c.Text = "sumwiridivsumwM4c"
        '
        'sumwiridivsumwM4d
        '
        Me.sumwiridivsumwM4d.Text = "sumwiridivsumwM4d"
        '
        'EQ1
        '
        Me.EQ1.Text = "Q1"
        '
        'EQ2
        '
        Me.EQ2.Text = "EQ2"
        '
        'EQ3
        '
        Me.EQ3.Text = "EQ3"
        '
        'EQ4
        '
        Me.EQ4.Text = "EQ4"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1492, 386)
        Me.Controls.Add(Me.ListView1)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "Form4"
        Me.Text = "Four Equipments Results"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents IMPA As ColumnHeader
    Friend WithEvents IMPB As ColumnHeader
    Friend WithEvents IMPC As ColumnHeader
    Friend WithEvents IMPD As ColumnHeader
    Friend WithEvents RM1A As ColumnHeader
    Friend WithEvents RM1B As ColumnHeader
    Friend WithEvents RM1C As ColumnHeader
    Friend WithEvents RM1D As ColumnHeader
    Friend WithEvents RM2A As ColumnHeader
    Friend WithEvents RM2B As ColumnHeader
    Friend WithEvents RM2C As ColumnHeader
    Friend WithEvents RM2D As ColumnHeader
    Friend WithEvents RM3A As ColumnHeader
    Friend WithEvents RM3B As ColumnHeader
    Friend WithEvents RM3C As ColumnHeader
    Friend WithEvents RM3D As ColumnHeader
    Friend WithEvents RM4A As ColumnHeader
    Friend WithEvents RM4B As ColumnHeader
    Friend WithEvents RM4C As ColumnHeader
    Friend WithEvents RM4D As ColumnHeader
    Friend WithEvents RXIMM1A As ColumnHeader
    Friend WithEvents RXIMM1b As ColumnHeader
    Friend WithEvents RXIMM1C As ColumnHeader
    Friend WithEvents RXIMM1d As ColumnHeader
    Friend WithEvents RXIMM2A As ColumnHeader
    Friend WithEvents RXIMM2B As ColumnHeader
    Friend WithEvents RXIMM2C As ColumnHeader
    Friend WithEvents RXIMM2D As ColumnHeader
    Friend WithEvents RXIMM3A As ColumnHeader
    Friend WithEvents RXIMM3B As ColumnHeader
    Friend WithEvents RXIMM3C As ColumnHeader
    Friend WithEvents RXIMM3D As ColumnHeader
    Friend WithEvents RXIMM4A As ColumnHeader
    Friend WithEvents RXIMM4B As ColumnHeader
    Friend WithEvents RXIMM4C As ColumnHeader
    Friend WithEvents RXIMM4D As ColumnHeader
    Friend WithEvents sumwiriM1A As ColumnHeader
    Friend WithEvents sumwiriM1B As ColumnHeader
    Friend WithEvents sumwiriM1C As ColumnHeader
    Friend WithEvents sumwiriM1D As ColumnHeader
    Friend WithEvents sumwiriM2A As ColumnHeader
    Friend WithEvents sumwiriM2B As ColumnHeader
    Friend WithEvents sumwiriM2C As ColumnHeader
    Friend WithEvents sumwiriM2D As ColumnHeader
    Friend WithEvents sumwiriM3A As ColumnHeader
    Friend WithEvents sumwiriM3B As ColumnHeader
    Friend WithEvents sumwiriM3C As ColumnHeader
    Friend WithEvents sumwiriM3D As ColumnHeader
    Friend WithEvents sumwiriM4A As ColumnHeader
    Friend WithEvents sumwiriM4B As ColumnHeader
    Friend WithEvents sumwiriM4C As ColumnHeader
    Friend WithEvents sumwiriM4D As ColumnHeader
    Friend WithEvents Sumwsuba As ColumnHeader
    Friend WithEvents Sumwsubb As ColumnHeader
    Friend WithEvents Sumwsubc As ColumnHeader
    Friend WithEvents Sumwsubd As ColumnHeader
    Friend WithEvents sumwiridivsumwM1a As ColumnHeader
    Friend WithEvents sumwiridivsumwM1b As ColumnHeader
    Friend WithEvents sumwiridivsumwM1c As ColumnHeader
    Friend WithEvents sumwiridivsumwM1d As ColumnHeader
    Friend WithEvents sumwiridivsumwM2a As ColumnHeader
    Friend WithEvents sumwiridivsumwM2b As ColumnHeader
    Friend WithEvents sumwiridivsumwM2c As ColumnHeader
    Friend WithEvents sumwiridivsumwM2d As ColumnHeader
    Friend WithEvents sumwiridivsumwM3a As ColumnHeader
    Friend WithEvents sumwiridivsumwM3b As ColumnHeader
    Friend WithEvents sumwiridivsumwM3c As ColumnHeader
    Friend WithEvents sumwiridivsumwM3d As ColumnHeader
    Friend WithEvents sumwiridivsumwM4a As ColumnHeader
    Friend WithEvents sumwiridivsumwM4b As ColumnHeader
    Friend WithEvents sumwiridivsumwM4c As ColumnHeader
    Friend WithEvents sumwiridivsumwM4d As ColumnHeader
    Friend WithEvents EQ1 As ColumnHeader
    Friend WithEvents EQ2 As ColumnHeader
    Friend WithEvents EQ3 As ColumnHeader
    Friend WithEvents EQ4 As ColumnHeader
End Class
