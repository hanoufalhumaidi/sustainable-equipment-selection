﻿Module Module1
    Public IMP(0 To 19, 0 To 3), sumimp(0 To 3), RMAT1(0 To 19, 0 To 3), RMAT2(0 To 19, 0 To 3), RMAT3(0 To 19, 0 To 3), RMAT4(0 To 19, 0 To 3), RMAT5(0 To 19, 0 To 3), sumwsub(0 To 3), RateM1(0 To 19, 0 To 3), RateM2(0 To 19, 0 To 3), RateM3(0 To 19, 0 To 3), RateM4(0 To 19, 0 To 3), RateM5(0 To 19, 0 To 3) As Double
    Public sumwiriM1(0 To 3), sumwiriM2(0 To 3), sumwiriM3(0 To 3), sumwiriM4(0 To 3), sumwiriM5(0 To 3), sumwiridivsumwM1(0 To 3), sumwiridivsumwM2(0 To 3), sumwiridivsumwM3(0 To 3), sumwiridivsumwM4(0 To 3), sumwiridivsumwM5(0 To 3), EQ1, EQ2, EQ3, EQ4, EQ5, O5(0 To 4), O4(0 To 3), O3(0 To 2), O2(0 To 1) As Double
    Public L1, L2, L3, L4, L5 As String
    Public i As Integer

    'Public Property RateM3 As Double(,)
    'Get
    'Return _rateM3
    'End Get
    'Set(value As Double(,))
    '       _rateM3 = value
    'End Set
    'End Property

    ' Public Function Assigna(i As Integer) As Double
    'If i = 0 Then Return 0
    'If i = 1 Then Return ((1 / 15) * 8)
    'If i = 2 Then Return ((1 / 15) * 10)
    'If i = 3 Then Return ((1 / 15) * 12)
    'End Function
    'Public Function Assignb(i As Integer) As Double
    'If i = 0 Then Return 0
    'If i = 1 Then Return ((1 / 15) * 9)
    'If i = 2 Then Return ((1 / 15) * 11)
    'If i = 3 Then Return ((1 / 15) * 13)
    'End Function
    'Public Function Assignc(i As Integer) As Double
    'If i = 0 Then Return 0
    'If i = 1 Then Return ((1 / 15) * 10)
    'If i = 2 Then Return ((1 / 15) * 12)
    'If i = 3 Then Return ((1 / 15) * 14)
    'End Function
    'Public Function Assignd(i As Integer) As Double
    'If i = 0 Then Return 0
    'If i = 1 Then Return ((1 / 15) * 11)
    'If i = 2 Then Return ((1 / 15) * 13)
    'If i = 3 Then Return 1
    'End Function


    ' Public Function Rassigna(i As Integer) As Double
    'If i = 0 Then Return 0
    'If i = 1 Then Return (2 / 15)
    'If i = 2 Then Return (4 / 15)
    'If i = 3 Then Return (6 / 15)
    'If i = 4 Then Return (8 / 15)
    'If i = 5 Then Return (10 / 15)
    'If i = 6 Then Return (12 / 15)

    'End Function
    'Public Function Rassignb(i As Integer) As Double
    'If i = 0 Then Return (1 / 15)
    'If i = 1 Then Return (3 / 15)
    '    If i = 2 Then Return (5 / 15)
    '   If i = 3 Then Return (7 / 15)
    'If i = 4 Then Return (9 / 15)
    'If i = 5 Then Return (11 / 15)
    'If i = 6 Then Return (3 / 15)

    'End Function
    'Public Function Rassignc(i As Integer) As Double
    'If i = 0 Then Return (2 / 15)
    'If i = 1 Then Return (4 / 15)
    'If i = 2 Then Return (6 / 15)
    'If i = 3 Then Return (8 / 15)
    'If i = 4 Then Return (10 / 15)
    'If i = 5 Then Return (12 / 15)
    'If i = 6 Then Return (14 / 15)
    'End Function
    'Public Function Rassignd(i As Integer) As Double
    'If i = 0 Then Return (3 / 15)
    'If i = 1 Then Return (5 / 15)
    'If i = 2 Then Return (7 / 15)
    'If i = 3 Then Return (9 / 15)
    'If i = 4 Then Return (11 / 15)
    'If i = 5 Then Return (13 / 15)
    'If i = 6 Then Return 1
    'End Function



End Module
