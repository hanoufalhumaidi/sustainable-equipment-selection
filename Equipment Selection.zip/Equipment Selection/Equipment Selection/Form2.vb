﻿Public Class Rating
    Private Sub Rating_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label28_Click(sender As Object, e As EventArgs) Handles Label28.Click

    End Sub

    Private Sub TableLayoutPanel1_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub

    Private Sub TrackBar39_Scroll(sender As Object, e As EventArgs) Handles M514.Scroll
        If M514.Value = 0 Then
            Mat514.Text = "Very Bad"
        ElseIf M514.Value = 1 Then
            Mat514.Text = "Bad"
        ElseIf M514.Value = 2 Then
            Mat514.Text = "Fairly Bad"
        ElseIf M514.Value = 3 Then
            Mat514.Text = "Fair"
        ElseIf M514.Value = 4 Then
            Mat514.Text = "Fairly Good"
        ElseIf M514.Value = 5 Then
            Mat514.Text = "Good"
        ElseIf M514.Value = 6 Then
            Mat514.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M514.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M514.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M514.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M514.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M514.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M514.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M514.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT5(13, 0) = a
        RMAT5(13, 1) = b
        RMAT5(13, 2) = c
        RMAT5(13, 3) = d

    End Sub

    Private Sub M11_Scroll(sender As Object, e As EventArgs) Handles M11.Scroll
        If M11.Value = 0 Then
            Mat11.Text = "Very Bad"
        ElseIf M11.Value = 1 Then
            Mat11.Text = "Bad"
        ElseIf M11.Value = 2 Then
            Mat11.Text = "Fairly Bad"
        ElseIf M11.Value = 3 Then
            Mat11.Text = "Fair"
        ElseIf M11.Value = 4 Then
            Mat11.Text = "Fairly Good"
        ElseIf M11.Value = 5 Then
            Mat11.Text = "Good"
        ElseIf M11.Value = 6 Then
            Mat11.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M11.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M11.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M11.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M11.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M11.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M11.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M11.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(0, 0) = a
        RMAT1(0, 1) = b
        RMAT1(0, 2) = c
        RMAT1(0, 3) = d

    End Sub

    Private Sub M12_Scroll(sender As Object, e As EventArgs) Handles M12.Scroll
        If M12.Value = 0 Then
            Mat12.Text = "Very Bad"
        ElseIf M12.Value = 1 Then
            Mat12.Text = "Bad"
        ElseIf M12.Value = 2 Then
            Mat12.Text = "Fairly Bad"
        ElseIf M12.Value = 3 Then
            Mat12.Text = "Fair"
        ElseIf M12.Value = 4 Then
            Mat12.Text = "Fairly Good"
        ElseIf M12.Value = 5 Then
            Mat12.Text = "Good"
        ElseIf M12.Value = 6 Then
            Mat12.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M12.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M12.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M12.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M12.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M12.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M12.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M12.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(1, 0) = a
        RMAT1(1, 1) = b
        RMAT1(1, 2) = c
        RMAT1(1, 3) = d
    End Sub

    Private Sub M13_Scroll(sender As Object, e As EventArgs) Handles M13.Scroll
        If M13.Value = 0 Then
            Mat13.Text = "Very Bad"
        ElseIf M13.Value = 1 Then
            Mat13.Text = "Bad"
        ElseIf M13.Value = 2 Then
            Mat13.Text = "Fairly Bad"
        ElseIf M13.Value = 3 Then
            Mat13.Text = "Fair"
        ElseIf M13.Value = 4 Then
            Mat13.Text = "Fairly Good"
        ElseIf M13.Value = 5 Then
            Mat13.Text = "Good"
        ElseIf M13.Value = 6 Then
            Mat13.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M13.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M13.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M13.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M13.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M13.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M13.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M13.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(2, 0) = a
        RMAT1(2, 1) = b
        RMAT1(2, 2) = c
        RMAT1(2, 3) = d
    End Sub

    Private Sub M14_Scroll(sender As Object, e As EventArgs) Handles M14.Scroll
        If M14.Value = 0 Then
            Mat14.Text = "Very High"
        ElseIf M14.Value = 1 Then
            Mat14.Text = "High"
        ElseIf M14.Value = 2 Then
            Mat14.Text = "Fairly High"
        ElseIf M14.Value = 3 Then
            Mat14.Text = "Fair"
        ElseIf M14.Value = 4 Then
            Mat14.Text = "Fairly Low"
        ElseIf M14.Value = 5 Then
            Mat14.Text = "Low"
        ElseIf M14.Value = 6 Then
            Mat14.Text = "Very Low"
        End If
        Dim a, b, c, d As Double
        If M14.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M14.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M14.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M14.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M14.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M14.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M14.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(3, 0) = a
        RMAT1(3, 1) = b
        RMAT1(3, 2) = c
        RMAT1(3, 3) = d
    End Sub

    Private Sub M15_Scroll(sender As Object, e As EventArgs) Handles M15.Scroll
        If M15.Value = 0 Then
            Mat15.Text = "Very High"
        ElseIf M15.Value = 1 Then
            Mat15.Text = "High"
        ElseIf M15.Value = 2 Then
            Mat15.Text = "Fairly High"
        ElseIf M15.Value = 3 Then
            Mat15.Text = "Fair"
        ElseIf M15.Value = 4 Then
            Mat15.Text = "Fairly Low"
        ElseIf M15.Value = 5 Then
            Mat15.Text = "Low"
        ElseIf M15.Value = 6 Then
            Mat15.Text = "Very Low"
        End If
        Dim a, b, c, d As Double
        If M15.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M15.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M15.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M15.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M15.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M15.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M15.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(4, 0) = a
        RMAT1(4, 1) = b
        RMAT1(4, 2) = c
        RMAT1(4, 3) = d
    End Sub

    Private Sub M16_Scroll(sender As Object, e As EventArgs) Handles M16.Scroll
        If M16.Value = 0 Then
            Mat16.Text = "Very Bad"
        ElseIf M16.Value = 1 Then
            Mat16.Text = "Bad"
        ElseIf M16.Value = 2 Then
            Mat16.Text = "Fairly Bad"
        ElseIf M16.Value = 3 Then
            Mat16.Text = "Fair"
        ElseIf M16.Value = 4 Then
            Mat16.Text = "Fairly Good"
        ElseIf M16.Value = 5 Then
            Mat16.Text = "Good"
        ElseIf M16.Value = 6 Then
            Mat16.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M16.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M16.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M16.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M16.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M16.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M16.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M16.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(5, 0) = a
        RMAT1(5, 1) = b
        RMAT1(5, 2) = c
        RMAT1(5, 3) = d
    End Sub

    Private Sub M17_Scroll(sender As Object, e As EventArgs) Handles M17.Scroll
        If M17.Value = 0 Then
            Mat17.Text = "Very Bad"
        ElseIf M17.Value = 1 Then
            Mat17.Text = "Bad"
        ElseIf M17.Value = 2 Then
            Mat17.Text = "Fairly Bad"
        ElseIf M17.Value = 3 Then
            Mat17.Text = "Fair"
        ElseIf M17.Value = 4 Then
            Mat17.Text = "Fairly Good"
        ElseIf M17.Value = 5 Then
            Mat17.Text = "Good"
        ElseIf M17.Value = 6 Then
            Mat17.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M17.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M17.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M17.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M17.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M17.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M17.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M17.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(6, 0) = a
        RMAT1(6, 1) = b
        RMAT1(6, 2) = c
        RMAT1(6, 3) = d
    End Sub

    Private Sub M18_Scroll(sender As Object, e As EventArgs) Handles M18.Scroll
        If M18.Value = 0 Then
            Mat18.Text = "Very Bad"
        ElseIf M18.Value = 1 Then
            Mat18.Text = "Bad"
        ElseIf M18.Value = 2 Then
            Mat18.Text = "Fairly Bad"
        ElseIf M18.Value = 3 Then
            Mat18.Text = "Fair"
        ElseIf M18.Value = 4 Then
            Mat18.Text = "Fairly Good"
        ElseIf M18.Value = 5 Then
            Mat18.Text = "Good"
        ElseIf M18.Value = 6 Then
            Mat18.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M18.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M18.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M18.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M18.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M18.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M18.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M18.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(7, 0) = a
        RMAT1(7, 1) = b
        RMAT1(7, 2) = c
        RMAT1(7, 3) = d
    End Sub

    Private Sub M110_Scroll(sender As Object, e As EventArgs) Handles M110.Scroll
        If M110.Value = 0 Then
            Mat110.Text = "Very Bad"
        ElseIf M110.Value = 1 Then
            Mat110.Text = "Bad"
        ElseIf M110.Value = 2 Then
            Mat110.Text = "Fairly Bad"
        ElseIf M110.Value = 3 Then
            Mat110.Text = "Fair"
        ElseIf M110.Value = 4 Then
            Mat110.Text = "Fairly Good"
        ElseIf M110.Value = 5 Then
            Mat110.Text = "Good"
        ElseIf M110.Value = 6 Then
            Mat110.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M110.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M110.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M110.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M110.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M110.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M110.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M110.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If

        RMAT1(9, 0) = a
        RMAT1(9, 1) = b
        RMAT1(9, 2) = c
        RMAT1(9, 3) = d
    End Sub

    Private Sub M111_Scroll(sender As Object, e As EventArgs) Handles M111.Scroll
        If M111.Value = 0 Then
            Mat111.Text = "Very Bad"
        ElseIf M111.Value = 1 Then
            Mat111.Text = "Bad"
        ElseIf M111.Value = 2 Then
            Mat111.Text = "Fairly Bad"
        ElseIf M111.Value = 3 Then
            Mat111.Text = "Fair"
        ElseIf M111.Value = 4 Then
            Mat111.Text = "Fairly Good"
        ElseIf M111.Value = 5 Then
            Mat111.Text = "Good"
        ElseIf M111.Value = 6 Then
            Mat111.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M111.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M111.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M111.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M111.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M111.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M111.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M111.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(10, 0) = a
        RMAT1(10, 1) = b
        RMAT1(10, 2) = c
        RMAT1(10, 3) = d
    End Sub

    Private Sub M112_Scroll(sender As Object, e As EventArgs) Handles M112.Scroll
        If M112.Value = 0 Then
            Mat112.Text = "Very Bad"
        ElseIf M112.Value = 1 Then
            Mat112.Text = "Bad"
        ElseIf M112.Value = 2 Then
            Mat112.Text = "Fairly Bad"
        ElseIf M112.Value = 3 Then
            Mat112.Text = "Fair"
        ElseIf M112.Value = 4 Then
            Mat112.Text = "Fairly Good"
        ElseIf M112.Value = 5 Then
            Mat112.Text = "Good"
        ElseIf M112.Value = 6 Then
            Mat112.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M112.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M112.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M112.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M112.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M112.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M112.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M112.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(11, 0) = a
        RMAT1(11, 1) = b
        RMAT1(11, 2) = c
        RMAT1(11, 3) = d
    End Sub

    Private Sub M113_Scroll(sender As Object, e As EventArgs) Handles M113.Scroll
        If M113.Value = 0 Then
            Mat113.Text = "Very Bad"
        ElseIf M113.Value = 1 Then
            Mat113.Text = "Bad"
        ElseIf M113.Value = 2 Then
            Mat113.Text = "Fairly Bad"
        ElseIf M113.Value = 3 Then
            Mat113.Text = "Fair"
        ElseIf M113.Value = 4 Then
            Mat113.Text = "Fairly Good"
        ElseIf M113.Value = 5 Then
            Mat113.Text = "Good"
        ElseIf M113.Value = 6 Then
            Mat113.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M113.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M113.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M113.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M113.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M113.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M113.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M113.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(12, 0) = a
        RMAT1(12, 1) = b
        RMAT1(12, 2) = c
        RMAT1(12, 3) = d
    End Sub

    Private Sub M114_Scroll(sender As Object, e As EventArgs) Handles M114.Scroll
        If M114.Value = 0 Then
            Mat114.Text = "Very Bad"
        ElseIf M114.Value = 1 Then
            Mat114.Text = "Bad"
        ElseIf M114.Value = 2 Then
            Mat114.Text = "Fairly Bad"
        ElseIf M114.Value = 3 Then
            Mat114.Text = "Fair"
        ElseIf M114.Value = 4 Then
            Mat114.Text = "Fairly Good"
        ElseIf M114.Value = 5 Then
            Mat114.Text = "Good"
        ElseIf M114.Value = 6 Then
            Mat114.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M113.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M113.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M113.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M113.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M113.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M113.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M113.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(13, 0) = a
        RMAT1(13, 1) = b
        RMAT1(13, 2) = c
        RMAT1(13, 3) = d

    End Sub

    Private Sub M19_Scroll(sender As Object, e As EventArgs) Handles M19.Scroll
        If M19.Value = 0 Then
            Mat19.Text = "Very Bad"
        ElseIf M19.Value = 1 Then
            Mat19.Text = "Bad"
        ElseIf M19.Value = 2 Then
            Mat19.Text = "Fairly Bad"
        ElseIf M19.Value = 3 Then
            Mat19.Text = "Fair"
        ElseIf M19.Value = 4 Then
            Mat19.Text = "Fairly Good"
        ElseIf M19.Value = 5 Then
            Mat19.Text = "Good"
        ElseIf M19.Value = 6 Then
            Mat19.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M19.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M19.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M19.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M19.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M19.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M19.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M19.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(8, 0) = a
        RMAT1(8, 1) = b
        RMAT1(8, 2) = c
        RMAT1(8, 3) = d
    End Sub

    Private Sub M21_Scroll(sender As Object, e As EventArgs) Handles M21.Scroll
        If M21.Value = 0 Then
            Mat21.Text = "Very Bad"
        ElseIf M21.Value = 1 Then
            Mat21.Text = "Bad"
        ElseIf M21.Value = 2 Then
            Mat21.Text = "Fairly Bad"
        ElseIf M21.Value = 3 Then
            Mat21.Text = "Fair"
        ElseIf M21.Value = 4 Then
            Mat21.Text = "Fairly Good"
        ElseIf M21.Value = 5 Then
            Mat21.Text = "Good"
        ElseIf M21.Value = 6 Then
            Mat21.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M21.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M21.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M21.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M21.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M21.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M21.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M21.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(0, 0) = a
        RMAT2(0, 1) = b
        RMAT2(0, 2) = c
        RMAT2(0, 3) = d
    End Sub

    Private Sub M31_Scroll(sender As Object, e As EventArgs) Handles M31.Scroll
        If M31.Value = 0 Then
            Mat31.Text = "Very Bad"
        ElseIf M31.Value = 1 Then
            Mat31.Text = "Bad"
        ElseIf M31.Value = 2 Then
            Mat31.Text = "Fairly Bad"
        ElseIf M31.Value = 3 Then
            Mat31.Text = "Fair"
        ElseIf M31.Value = 4 Then
            Mat31.Text = "Fairly Good"
        ElseIf M31.Value = 5 Then
            Mat31.Text = "Good"
        ElseIf M31.Value = 6 Then
            Mat31.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M31.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M31.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M31.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M31.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M31.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M31.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M31.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(0, 0) = a
        RMAT3(0, 1) = b
        RMAT3(0, 2) = c
        RMAT3(0, 3) = d
    End Sub

    Private Sub M41_Scroll(sender As Object, e As EventArgs) Handles M41.Scroll
        If M41.Value = 0 Then
            Mat41.Text = "Very Bad"
        ElseIf M41.Value = 1 Then
            Mat41.Text = "Bad"
        ElseIf M41.Value = 2 Then
            Mat41.Text = "Fairly Bad"
        ElseIf M41.Value = 3 Then
            Mat41.Text = "Fair"
        ElseIf M41.Value = 4 Then
            Mat41.Text = "Fairly Good"
        ElseIf M41.Value = 5 Then
            Mat41.Text = "Good"
        ElseIf M41.Value = 6 Then
            Mat41.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M41.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M41.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M41.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M41.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M41.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M41.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M41.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(0, 0) = a
        RMAT4(0, 1) = b
        RMAT4(0, 2) = c
        RMAT4(0, 3) = d
    End Sub

    Private Sub M51_Scroll(sender As Object, e As EventArgs) Handles M51.Scroll
        If M51.Value = 0 Then
            Mat51.Text = "Very Bad"
        ElseIf M51.Value = 1 Then
            Mat51.Text = "Bad"
        ElseIf M51.Value = 2 Then
            Mat51.Text = "Fairly Bad"
        ElseIf M51.Value = 3 Then
            Mat51.Text = "Fair"
        ElseIf M51.Value = 4 Then
            Mat51.Text = "Fairly Good"
        ElseIf M51.Value = 5 Then
            Mat51.Text = "Good"
        ElseIf M51.Value = 6 Then
            Mat51.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M51.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M51.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M51.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M51.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M51.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M51.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M51.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(0, 0) = a
        RMAT5(0, 1) = b
        RMAT5(0, 2) = c
        RMAT5(0, 3) = d

    End Sub

    Private Sub M22_Scroll(sender As Object, e As EventArgs) Handles M22.Scroll
        If M22.Value = 0 Then
            Mat22.Text = "Very Bad"
        ElseIf M22.Value = 1 Then
            Mat22.Text = "Bad"
        ElseIf M22.Value = 2 Then
            Mat22.Text = "Fairly Bad"
        ElseIf M22.Value = 3 Then
            Mat22.Text = "Fair"
        ElseIf M22.Value = 4 Then
            Mat22.Text = "Fairly Good"
        ElseIf M22.Value = 5 Then
            Mat22.Text = "Good"
        ElseIf M22.Value = 6 Then
            Mat22.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M22.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M22.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M22.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M22.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M22.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M22.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M22.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(1, 0) = a
        RMAT2(1, 1) = b
        RMAT2(1, 2) = c
        RMAT2(1, 3) = d

    End Sub

    Private Sub M32_Scroll(sender As Object, e As EventArgs) Handles M32.Scroll
        If M32.Value = 0 Then
            Mat32.Text = "Very Bad"
        ElseIf M32.Value = 1 Then
            Mat32.Text = "Bad"
        ElseIf M32.Value = 2 Then
            Mat32.Text = "Fairly Bad"
        ElseIf M32.Value = 3 Then
            Mat32.Text = "Fair"
        ElseIf M32.Value = 4 Then
            Mat32.Text = "Fairly Good"
        ElseIf M32.Value = 5 Then
            Mat32.Text = "Good"
        ElseIf M32.Value = 6 Then
            Mat32.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M32.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M32.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M32.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M32.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M32.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M32.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M32.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(1, 0) = a
        RMAT3(1, 1) = b
        RMAT3(1, 2) = c
        RMAT3(1, 3) = d
    End Sub

    Private Sub M42_Scroll(sender As Object, e As EventArgs) Handles M42.Scroll
        If M42.Value = 0 Then
            Mat42.Text = "Very Bad"
        ElseIf M42.Value = 1 Then
            Mat42.Text = "Bad"
        ElseIf M42.Value = 2 Then
            Mat42.Text = "Fairly Bad"
        ElseIf M42.Value = 3 Then
            Mat42.Text = "Fair"
        ElseIf M42.Value = 4 Then
            Mat42.Text = "Fairly Good"
        ElseIf M42.Value = 5 Then
            Mat42.Text = "Good"
        ElseIf M42.Value = 6 Then
            Mat42.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M42.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M42.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M42.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M42.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M42.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M42.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M42.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(1, 0) = a
        RMAT4(1, 1) = b
        RMAT4(1, 2) = c
        RMAT4(1, 3) = d

    End Sub

    Private Sub M52_Scroll(sender As Object, e As EventArgs) Handles M52.Scroll
        If M52.Value = 0 Then
            Mat52.Text = "Very Bad"
        ElseIf M52.Value = 1 Then
            Mat52.Text = "Bad"
        ElseIf M52.Value = 2 Then
            Mat52.Text = "Fairly Bad"
        ElseIf M52.Value = 3 Then
            Mat52.Text = "Fair"
        ElseIf M52.Value = 4 Then
            Mat52.Text = "Fairly Good"
        ElseIf M52.Value = 5 Then
            Mat52.Text = "Good"
        ElseIf M52.Value = 6 Then
            Mat52.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M52.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M52.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M52.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M52.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M52.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M52.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M52.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(1, 0) = a
        RMAT5(1, 1) = b
        RMAT5(1, 2) = c
        RMAT5(1, 3) = d

    End Sub

    Private Sub M23_Scroll(sender As Object, e As EventArgs) Handles M23.Scroll
        If M23.Value = 0 Then
            Mat23.Text = "Very Bad"
        ElseIf M23.Value = 1 Then
            Mat23.Text = "Bad"
        ElseIf M23.Value = 2 Then
            Mat23.Text = "Fairly Bad"
        ElseIf M23.Value = 3 Then
            Mat23.Text = "Fair"
        ElseIf M23.Value = 4 Then
            Mat23.Text = "Fairly Good"
        ElseIf M23.Value = 5 Then
            Mat23.Text = "Good"
        ElseIf M23.Value = 6 Then
            Mat23.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M23.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M23.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M23.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M23.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M23.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M23.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M23.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(2, 0) = a
        RMAT2(2, 1) = b
        RMAT2(2, 2) = c
        RMAT2(2, 3) = d
    End Sub

    Private Sub M33_Scroll(sender As Object, e As EventArgs) Handles M33.Scroll
        If M33.Value = 0 Then
            Mat33.Text = "Very Bad"
        ElseIf M33.Value = 1 Then
            Mat33.Text = "Bad"
        ElseIf M33.Value = 2 Then
            Mat33.Text = "Fairly Bad"
        ElseIf M33.Value = 3 Then
            Mat33.Text = "Fair"
        ElseIf M33.Value = 4 Then
            Mat33.Text = "Fairly Good"
        ElseIf M33.Value = 5 Then
            Mat33.Text = "Good"
        ElseIf M33.Value = 6 Then
            Mat33.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M33.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M33.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M33.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M33.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M33.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M33.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M33.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(2, 0) = a
        RMAT3(2, 1) = b
        RMAT3(2, 2) = c
        RMAT3(2, 3) = d

    End Sub

    Private Sub M43_Scroll(sender As Object, e As EventArgs) Handles M43.Scroll
        If M43.Value = 0 Then
            Mat43.Text = "Very Bad"
        ElseIf M43.Value = 1 Then
            Mat43.Text = "Bad"
        ElseIf M43.Value = 2 Then
            Mat43.Text = "Fairly Bad"
        ElseIf M43.Value = 3 Then
            Mat43.Text = "Fair"
        ElseIf M43.Value = 4 Then
            Mat43.Text = "Fairly Good"
        ElseIf M43.Value = 5 Then
            Mat43.Text = "Good"
        ElseIf M43.Value = 6 Then
            Mat43.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M43.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M43.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M43.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M43.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M43.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M43.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M43.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(2, 0) = a
        RMAT4(2, 1) = b
        RMAT4(2, 2) = c
        RMAT4(2, 3) = d

    End Sub

    Private Sub M53_Scroll(sender As Object, e As EventArgs) Handles M53.Scroll
        If M53.Value = 0 Then
            Mat53.Text = "Very Bad"
        ElseIf M53.Value = 1 Then
            Mat53.Text = "Bad"
        ElseIf M53.Value = 2 Then
            Mat53.Text = "Fairly Bad"
        ElseIf M53.Value = 3 Then
            Mat53.Text = "Fair"
        ElseIf M53.Value = 4 Then
            Mat53.Text = "Fairly Good"
        ElseIf M53.Value = 5 Then
            Mat53.Text = "Good"
        ElseIf M53.Value = 6 Then
            Mat53.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M53.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M53.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M53.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M53.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M53.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M53.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M53.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(2, 0) = a
        RMAT5(2, 1) = b
        RMAT5(2, 2) = c
        RMAT5(2, 3) = d

    End Sub

    Private Sub M24_Scroll(sender As Object, e As EventArgs) Handles M24.Scroll
        If M24.Value = 0 Then
            Mat24.Text = "Very High"
        ElseIf M24.Value = 1 Then
            Mat24.Text = "High"
        ElseIf M24.Value = 2 Then
            Mat24.Text = "Fairly High"
        ElseIf M24.Value = 3 Then
            Mat24.Text = "Fair"
        ElseIf M24.Value = 4 Then
            Mat24.Text = "Fairly Low"
        ElseIf M24.Value = 5 Then
            Mat24.Text = "Low"
        ElseIf M24.Value = 6 Then
            Mat24.Text = "Very Low"
        End If
        Dim a, b, c, d As Double
        If M24.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M24.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M24.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M24.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M24.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M24.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M24.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(3, 0) = a
        RMAT2(3, 1) = b
        RMAT2(3, 2) = c
        RMAT2(3, 3) = d

    End Sub

    Private Sub M34_Scroll(sender As Object, e As EventArgs) Handles M34.Scroll
        If M34.Value = 0 Then
            Mat34.Text = "Very High"
        ElseIf M34.Value = 1 Then
            Mat34.Text = "High"
        ElseIf M34.Value = 2 Then
            Mat34.Text = "Fairly High"
        ElseIf M34.Value = 3 Then
            Mat34.Text = "Fair"
        ElseIf M34.Value = 4 Then
            Mat34.Text = "Fairly Low"
        ElseIf M34.Value = 5 Then
            Mat34.Text = "Low"
        ElseIf M34.Value = 6 Then
            Mat34.Text = "Very Low"
        End If

        Dim a, b, c, d As Double
        If M34.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M34.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M34.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M34.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M34.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M34.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M34.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(3, 0) = a
        RMAT3(3, 1) = b
        RMAT3(3, 2) = c
        RMAT3(3, 3) = d

    End Sub

    Private Sub M44_Scroll(sender As Object, e As EventArgs) Handles M44.Scroll
        If M44.Value = 0 Then
            Mat44.Text = "Very High"
        ElseIf M44.Value = 1 Then
            Mat44.Text = "High"
        ElseIf M44.Value = 2 Then
            Mat44.Text = "Fairly High"
        ElseIf M44.Value = 3 Then
            Mat44.Text = "Fair"
        ElseIf M44.Value = 4 Then
            Mat44.Text = "Fairly Low"
        ElseIf M44.Value = 5 Then
            Mat44.Text = "Low"
        ElseIf M44.Value = 6 Then
            Mat44.Text = "Very Low"
        End If

        Dim a, b, c, d As Double
        If M44.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M44.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M44.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M44.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M44.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M44.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M44.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(3, 0) = a
        RMAT4(3, 1) = b
        RMAT4(3, 2) = c
        RMAT4(3, 3) = d
    End Sub

    Private Sub M54_Scroll(sender As Object, e As EventArgs) Handles M54.Scroll
        If M54.Value = 0 Then
            Mat54.Text = "Very High"
        ElseIf M54.Value = 1 Then
            Mat54.Text = "High"
        ElseIf M54.Value = 2 Then
            Mat54.Text = "Fairly High"
        ElseIf M54.Value = 3 Then
            Mat54.Text = "Fair"
        ElseIf M54.Value = 4 Then
            Mat54.Text = "Fairly Low"
        ElseIf M54.Value = 5 Then
            Mat54.Text = "Low"
        ElseIf M54.Value = 6 Then
            Mat54.Text = "Very Low"
        End If
        Dim a, b, c, d As Double
        If M54.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M54.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M54.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M54.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M54.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M54.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M54.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(3, 0) = a
        RMAT5(3, 1) = b
        RMAT5(3, 2) = c
        RMAT5(3, 3) = d

    End Sub

    Private Sub M25_Scroll(sender As Object, e As EventArgs) Handles M25.Scroll
        If M25.Value = 0 Then
            Mat25.Text = "Very High"
        ElseIf M25.Value = 1 Then
            Mat25.Text = "High"
        ElseIf M25.Value = 2 Then
            Mat25.Text = "Fairly High"
        ElseIf M25.Value = 3 Then
            Mat25.Text = "Fair"
        ElseIf M25.Value = 4 Then
            Mat25.Text = "Fairly Low"
        ElseIf M25.Value = 5 Then
            Mat25.Text = "Low"
        ElseIf M25.Value = 6 Then
            Mat25.Text = "Very Low"
        End If

        Dim a, b, c, d As Double
        If M25.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M25.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M25.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M25.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M25.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M25.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M25.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(4, 0) = a
        RMAT2(4, 1) = b
        RMAT2(4, 2) = c
        RMAT2(4, 3) = d

    End Sub

    Private Sub M35_Scroll(sender As Object, e As EventArgs) Handles M35.Scroll
        If M35.Value = 0 Then
            Mat35.Text = "Very High"
        ElseIf M35.Value = 1 Then
            Mat35.Text = "High"
        ElseIf M35.Value = 2 Then
            Mat35.Text = "Fairly High"
        ElseIf M35.Value = 3 Then
            Mat35.Text = "Fair"
        ElseIf M35.Value = 4 Then
            Mat35.Text = "Fairly Low"
        ElseIf M35.Value = 5 Then
            Mat35.Text = "Low"
        ElseIf M35.Value = 6 Then
            Mat35.Text = "Very Low"
        End If

        Dim a, b, c, d As Double
        If M35.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M35.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M35.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M35.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M35.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M35.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M35.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(4, 0) = a
        RMAT3(4, 1) = b
        RMAT3(4, 2) = c
        RMAT3(4, 3) = d

    End Sub

    Private Sub M45_Scroll(sender As Object, e As EventArgs) Handles M45.Scroll
        If M45.Value = 0 Then
            Mat45.Text = "Very High"
        ElseIf M45.Value = 1 Then
            Mat45.Text = "High"
        ElseIf M45.Value = 2 Then
            Mat45.Text = "Fairly High"
        ElseIf M45.Value = 3 Then
            Mat45.Text = "Fair"
        ElseIf M45.Value = 4 Then
            Mat45.Text = "Fairly Low"
        ElseIf M45.Value = 5 Then
            Mat45.Text = "Low"
        ElseIf M45.Value = 6 Then
            Mat45.Text = "Very Low"
        End If
        Dim a, b, c, d As Double
        If M45.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M45.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M45.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M45.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M45.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M45.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M45.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(4, 0) = a
        RMAT4(4, 1) = b
        RMAT4(4, 2) = c
        RMAT4(4, 3) = d

    End Sub

    Private Sub M55_Scroll(sender As Object, e As EventArgs) Handles M55.Scroll
        If M55.Value = 0 Then
            Mat55.Text = "Very High"
        ElseIf M55.Value = 1 Then
            Mat55.Text = "High"
        ElseIf M55.Value = 2 Then
            Mat55.Text = "Fairly High"
        ElseIf M55.Value = 3 Then
            Mat55.Text = "Fair"
        ElseIf M55.Value = 4 Then
            Mat55.Text = "Fairly Low"
        ElseIf M55.Value = 5 Then
            Mat55.Text = "Low"
        ElseIf M55.Value = 6 Then
            Mat55.Text = "Very Low"
        End If
        Dim a, b, c, d As Double
        If M55.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M55.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M55.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M55.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M55.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M55.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M55.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(4, 0) = a
        RMAT5(4, 1) = b
        RMAT5(4, 2) = c
        RMAT5(4, 3) = d

    End Sub

    Private Sub M26_Scroll(sender As Object, e As EventArgs) Handles M26.Scroll
        If M26.Value = 0 Then
            Mat26.Text = "Very Bad"
        ElseIf M26.Value = 1 Then
            Mat26.Text = "Bad"
        ElseIf M26.Value = 2 Then
            Mat26.Text = "Fairly Bad"
        ElseIf M26.Value = 3 Then
            Mat26.Text = "Fair"
        ElseIf M26.Value = 4 Then
            Mat26.Text = "Fairly Good"
        ElseIf M26.Value = 5 Then
            Mat26.Text = "Good"
        ElseIf M26.Value = 6 Then
            Mat26.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M26.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M26.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M26.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M26.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M26.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M26.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M26.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(5, 0) = a
        RMAT2(5, 1) = b
        RMAT2(5, 2) = c
        RMAT2(5, 3) = d
    End Sub

    Private Sub M36_Scroll(sender As Object, e As EventArgs) Handles M36.Scroll
        If M36.Value = 0 Then
            Mat36.Text = "Very Bad"
        ElseIf M36.Value = 1 Then
            Mat36.Text = "Bad"
        ElseIf M36.Value = 2 Then
            Mat36.Text = "Fairly Bad"
        ElseIf M36.Value = 3 Then
            Mat36.Text = "Fair"
        ElseIf M36.Value = 4 Then
            Mat36.Text = "Fairly Good"
        ElseIf M36.Value = 5 Then
            Mat36.Text = "Good"
        ElseIf M36.Value = 6 Then
            Mat36.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M36.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M36.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M36.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M36.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M36.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M36.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M36.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(5, 0) = a
        RMAT3(5, 1) = b
        RMAT3(5, 2) = c
        RMAT3(5, 3) = d

    End Sub

    Private Sub M46_Scroll(sender As Object, e As EventArgs) Handles M46.Scroll
        If M46.Value = 0 Then
            Mat46.Text = "Very Bad"
        ElseIf M46.Value = 1 Then
            Mat46.Text = "Bad"
        ElseIf M46.Value = 2 Then
            Mat46.Text = "Fairly Bad"
        ElseIf M46.Value = 3 Then
            Mat46.Text = "Fair"
        ElseIf M46.Value = 4 Then
            Mat46.Text = "Fairly Good"
        ElseIf M46.Value = 5 Then
            Mat46.Text = "Good"
        ElseIf M46.Value = 6 Then
            Mat46.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M46.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M46.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M46.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M46.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M46.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M46.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M46.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(5, 0) = a
        RMAT4(5, 1) = b
        RMAT4(5, 2) = c
        RMAT4(5, 3) = d

    End Sub

    Private Sub M56_Scroll(sender As Object, e As EventArgs) Handles M56.Scroll
        If M56.Value = 0 Then
            Mat56.Text = "Very Bad"
        ElseIf M56.Value = 1 Then
            Mat56.Text = "Bad"
        ElseIf M56.Value = 2 Then
            Mat56.Text = "Fairly Bad"
        ElseIf M56.Value = 3 Then
            Mat56.Text = "Fair"
        ElseIf M56.Value = 4 Then
            Mat56.Text = "Fairly Good"
        ElseIf M56.Value = 5 Then
            Mat56.Text = "Good"
        ElseIf M56.Value = 6 Then
            Mat56.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M56.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M56.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M56.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M56.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M56.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M56.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M56.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(5, 0) = a
        RMAT5(5, 1) = b
        RMAT5(5, 2) = c
        RMAT5(5, 3) = d

    End Sub

    Private Sub M27_Scroll(sender As Object, e As EventArgs) Handles M27.Scroll
        If M27.Value = 0 Then
            Mat27.Text = "Very Bad"
        ElseIf M27.Value = 1 Then
            Mat27.Text = "Bad"
        ElseIf M27.Value = 2 Then
            Mat27.Text = "Fairly Bad"
        ElseIf M27.Value = 3 Then
            Mat27.Text = "Fair"
        ElseIf M27.Value = 4 Then
            Mat27.Text = "Fairly Good"
        ElseIf M27.Value = 5 Then
            Mat27.Text = "Good"
        ElseIf M27.Value = 6 Then
            Mat27.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M27.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M27.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M27.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M27.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M27.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M27.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M27.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(6, 0) = a
        RMAT2(6, 1) = b
        RMAT2(6, 2) = c
        RMAT2(6, 3) = d

    End Sub

    Private Sub M37_Scroll(sender As Object, e As EventArgs) Handles M37.Scroll
        If M37.Value = 0 Then
            Mat37.Text = "Very Bad"
        ElseIf M37.Value = 1 Then
            Mat37.Text = "Bad"
        ElseIf M37.Value = 2 Then
            Mat37.Text = "Fairly Bad"
        ElseIf M37.Value = 3 Then
            Mat37.Text = "Fair"
        ElseIf M37.Value = 4 Then
            Mat37.Text = "Fairly Good"
        ElseIf M37.Value = 5 Then
            Mat37.Text = "Good"
        ElseIf M37.Value = 6 Then
            Mat37.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M37.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M37.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M37.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M37.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M37.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M37.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M37.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(6, 0) = a
        RMAT3(6, 1) = b
        RMAT3(6, 2) = c
        RMAT3(6, 3) = d

    End Sub

    Private Sub M47_Scroll(sender As Object, e As EventArgs) Handles M47.Scroll
        If M47.Value = 0 Then
            Mat47.Text = "Very Bad"
        ElseIf M47.Value = 1 Then
            Mat47.Text = "Bad"
        ElseIf M47.Value = 2 Then
            Mat47.Text = "Fairly Bad"
        ElseIf M47.Value = 3 Then
            Mat47.Text = "Fair"
        ElseIf M47.Value = 4 Then
            Mat47.Text = "Fairly Good"
        ElseIf M47.Value = 5 Then
            Mat47.Text = "Good"
        ElseIf M47.Value = 6 Then
            Mat47.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M47.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M47.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M47.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M47.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M47.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M47.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M47.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(6, 0) = a
        RMAT4(6, 1) = b
        RMAT4(6, 2) = c
        RMAT4(6, 3) = d

    End Sub

    Private Sub M57_Scroll(sender As Object, e As EventArgs) Handles M57.Scroll
        If M57.Value = 0 Then
            Mat57.Text = "Very Bad"
        ElseIf M57.Value = 1 Then
            Mat57.Text = "Bad"
        ElseIf M57.Value = 2 Then
            Mat57.Text = "Fairly Bad"
        ElseIf M57.Value = 3 Then
            Mat57.Text = "Fair"
        ElseIf M57.Value = 4 Then
            Mat57.Text = "Fairly Good"
        ElseIf M57.Value = 5 Then
            Mat57.Text = "Good"
        ElseIf M57.Value = 6 Then
            Mat57.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M57.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M57.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M57.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M57.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M57.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M57.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M57.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(6, 0) = a
        RMAT5(6, 1) = b
        RMAT5(6, 2) = c
        RMAT5(6, 3) = d
    End Sub

    Private Sub M28_Scroll(sender As Object, e As EventArgs) Handles M28.Scroll
        If M28.Value = 0 Then
            Mat28.Text = "Very Bad"
        ElseIf M28.Value = 1 Then
            Mat28.Text = "Bad"
        ElseIf M28.Value = 2 Then
            Mat28.Text = "Fairly Bad"
        ElseIf M28.Value = 3 Then
            Mat28.Text = "Fair"
        ElseIf M28.Value = 4 Then
            Mat28.Text = "Fairly Good"
        ElseIf M28.Value = 5 Then
            Mat28.Text = "Good"
        ElseIf M28.Value = 6 Then
            Mat28.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M28.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M28.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M28.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M28.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M28.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M28.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M28.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(7, 0) = a
        RMAT2(7, 1) = b
        RMAT2(7, 2) = c
        RMAT2(7, 3) = d
    End Sub

    Private Sub M38_Scroll(sender As Object, e As EventArgs) Handles M38.Scroll
        If M38.Value = 0 Then
            Mat38.Text = "Very Bad"
        ElseIf M38.Value = 1 Then
            Mat38.Text = "Bad"
        ElseIf M38.Value = 2 Then
            Mat38.Text = "Fairly Bad"
        ElseIf M38.Value = 3 Then
            Mat38.Text = "Fair"
        ElseIf M38.Value = 4 Then
            Mat38.Text = "Fairly Good"
        ElseIf M38.Value = 5 Then
            Mat38.Text = "Good"
        ElseIf M38.Value = 6 Then
            Mat38.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M38.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M38.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M38.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M38.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M38.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M38.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M38.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(7, 0) = a
        RMAT3(7, 1) = b
        RMAT3(7, 2) = c
        RMAT3(7, 3) = d

    End Sub

    Private Sub M48_Scroll(sender As Object, e As EventArgs) Handles M48.Scroll
        If M48.Value = 0 Then
            Mat48.Text = "Very Bad"
        ElseIf M48.Value = 1 Then
            Mat48.Text = "Bad"
        ElseIf M48.Value = 2 Then
            Mat48.Text = "Fairly Bad"
        ElseIf M48.Value = 3 Then
            Mat48.Text = "Fair"
        ElseIf M48.Value = 4 Then
            Mat48.Text = "Fairly Good"
        ElseIf M48.Value = 5 Then
            Mat48.Text = "Good"
        ElseIf M48.Value = 6 Then
            Mat48.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M48.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M48.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M48.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M48.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M48.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M48.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M48.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(7, 0) = a
        RMAT4(7, 1) = b
        RMAT4(7, 2) = c
        RMAT4(7, 3) = d

    End Sub

    Private Sub M58_Scroll(sender As Object, e As EventArgs) Handles M58.Scroll
        If M58.Value = 0 Then
            Mat58.Text = "Very Bad"
        ElseIf M58.Value = 1 Then
            Mat58.Text = "Bad"
        ElseIf M58.Value = 2 Then
            Mat58.Text = "Fairly Bad"
        ElseIf M58.Value = 3 Then
            Mat58.Text = "Fair"
        ElseIf M58.Value = 4 Then
            Mat58.Text = "Fairly Good"
        ElseIf M58.Value = 5 Then
            Mat58.Text = "Good"
        ElseIf M58.Value = 6 Then
            Mat58.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M58.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M58.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M58.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M58.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M58.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M58.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M58.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(7, 0) = a
        RMAT5(7, 1) = b
        RMAT5(7, 2) = c
        RMAT5(7, 3) = d

    End Sub

    Private Sub M29_Scroll(sender As Object, e As EventArgs) Handles M29.Scroll
        If M29.Value = 0 Then
            Mat29.Text = "Very Bad"
        ElseIf M29.Value = 1 Then
            Mat29.Text = "Bad"
        ElseIf M29.Value = 2 Then
            Mat29.Text = "Fairly Bad"
        ElseIf M29.Value = 3 Then
            Mat29.Text = "Fair"
        ElseIf M29.Value = 4 Then
            Mat29.Text = "Fairly Good"
        ElseIf M29.Value = 5 Then
            Mat29.Text = "Good"
        ElseIf M29.Value = 6 Then
            Mat29.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M29.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M29.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M29.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M29.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M29.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M29.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M29.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(8, 0) = a
        RMAT2(8, 1) = b
        RMAT2(8, 2) = c
        RMAT2(8, 3) = d
    End Sub

    Private Sub M39_Scroll(sender As Object, e As EventArgs) Handles M39.Scroll
        If M39.Value = 0 Then
            Mat39.Text = "Very Bad"
        ElseIf M39.Value = 1 Then
            Mat39.Text = "Bad"
        ElseIf M39.Value = 2 Then
            Mat39.Text = "Fairly Bad"
        ElseIf M39.Value = 3 Then
            Mat39.Text = "Fair"
        ElseIf M39.Value = 4 Then
            Mat39.Text = "Fairly Good"
        ElseIf M39.Value = 5 Then
            Mat39.Text = "Good"
        ElseIf M39.Value = 6 Then
            Mat39.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M39.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M39.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M39.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M39.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M39.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M39.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M39.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(8, 0) = a
        RMAT3(8, 1) = b
        RMAT3(8, 2) = c
        RMAT3(8, 3) = d

    End Sub

    Private Sub M49_Scroll(sender As Object, e As EventArgs) Handles M49.Scroll
        If M49.Value = 0 Then
            Mat49.Text = "Very Bad"
        ElseIf M49.Value = 1 Then
            Mat49.Text = "Bad"
        ElseIf M49.Value = 2 Then
            Mat49.Text = "Fairly Bad"
        ElseIf M49.Value = 3 Then
            Mat49.Text = "Fair"
        ElseIf M49.Value = 4 Then
            Mat49.Text = "Fairly Good"
        ElseIf M49.Value = 5 Then
            Mat49.Text = "Good"
        ElseIf M49.Value = 6 Then
            Mat49.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M49.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M49.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M49.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M49.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M49.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M49.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M49.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(8, 0) = a
        RMAT4(8, 1) = b
        RMAT4(8, 2) = c
        RMAT4(8, 3) = d

    End Sub

    Private Sub M59_Scroll(sender As Object, e As EventArgs) Handles M59.Scroll
        If M59.Value = 0 Then
            Mat59.Text = "Very Bad"
        ElseIf M59.Value = 1 Then
            Mat59.Text = "Bad"
        ElseIf M59.Value = 2 Then
            Mat59.Text = "Fairly Bad"
        ElseIf M59.Value = 3 Then
            Mat59.Text = "Fair"
        ElseIf M59.Value = 4 Then
            Mat59.Text = "Fairly Good"
        ElseIf M59.Value = 5 Then
            Mat59.Text = "Good"
        ElseIf M59.Value = 6 Then
            Mat59.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M59.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M59.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M59.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M59.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M59.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M59.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M59.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(8, 0) = a
        RMAT5(8, 1) = b
        RMAT5(8, 2) = c
        RMAT4(8, 3) = d


    End Sub

    Private Sub M210_Scroll(sender As Object, e As EventArgs) Handles M210.Scroll
        If M210.Value = 0 Then
            Mat210.Text = "Very Bad"
        ElseIf M210.Value = 1 Then
            Mat210.Text = "Bad"
        ElseIf M210.Value = 2 Then
            Mat210.Text = "Fairly Bad"
        ElseIf M210.Value = 3 Then
            Mat210.Text = "Fair"
        ElseIf M210.Value = 4 Then
            Mat210.Text = "Fairly Good"
        ElseIf M210.Value = 5 Then
            Mat210.Text = "Good"
        ElseIf M210.Value = 6 Then
            Mat210.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M210.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M210.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M210.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M210.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M210.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M210.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M210.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(9, 0) = a
        RMAT2(9, 1) = b
        RMAT2(9, 2) = c
        RMAT2(9, 3) = d

    End Sub

    Private Sub M310_Scroll(sender As Object, e As EventArgs) Handles M310.Scroll
        If M310.Value = 0 Then
            Mat310.Text = "Very Bad"
        ElseIf M310.Value = 1 Then
            Mat310.Text = "Bad"
        ElseIf M310.Value = 2 Then
            Mat310.Text = "Fairly Bad"
        ElseIf M310.Value = 3 Then
            Mat310.Text = "Fair"
        ElseIf M310.Value = 4 Then
            Mat310.Text = "Fairly Good"
        ElseIf M310.Value = 5 Then
            Mat310.Text = "Good"
        ElseIf M310.Value = 6 Then
            Mat310.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M310.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M310.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M310.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M310.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M310.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M310.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M310.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(9, 0) = a
        RMAT3(9, 1) = b
        RMAT3(9, 2) = c
        RMAT3(9, 3) = d

    End Sub

    Private Sub M410_Scroll(sender As Object, e As EventArgs) Handles M410.Scroll
        If M410.Value = 0 Then
            Mat410.Text = "Very Bad"
        ElseIf M410.Value = 1 Then
            Mat410.Text = "Bad"
        ElseIf M410.Value = 2 Then
            Mat410.Text = "Fairly Bad"
        ElseIf M410.Value = 3 Then
            Mat410.Text = "Fair"
        ElseIf M410.Value = 4 Then
            Mat410.Text = "Fairly Good"
        ElseIf M410.Value = 5 Then
            Mat410.Text = "Good"
        ElseIf M410.Value = 6 Then
            Mat410.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M410.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M410.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M410.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M410.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M410.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M410.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M410.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(9, 0) = a
        RMAT4(9, 1) = b
        RMAT4(9, 2) = c
        RMAT4(9, 3) = d

    End Sub

    Private Sub M510_Scroll(sender As Object, e As EventArgs) Handles M510.Scroll
        If M510.Value = 0 Then
            Mat510.Text = "Very Bad"
        ElseIf M510.Value = 1 Then
            Mat510.Text = "Bad"
        ElseIf M510.Value = 2 Then
            Mat510.Text = "Fairly Bad"
        ElseIf M510.Value = 3 Then
            Mat510.Text = "Fair"
        ElseIf M510.Value = 4 Then
            Mat510.Text = "Fairly Good"
        ElseIf M510.Value = 5 Then
            Mat510.Text = "Good"
        ElseIf M510.Value = 6 Then
            Mat510.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M510.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M510.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M510.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M510.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M510.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M510.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M510.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(9, 0) = a
        RMAT5(9, 1) = b
        RMAT5(9, 2) = c
        RMAT5(9, 3) = d

    End Sub

    Private Sub M211_Scroll(sender As Object, e As EventArgs) Handles M211.Scroll
        If M211.Value = 0 Then
            Mat211.Text = "Very Bad"
        ElseIf M211.Value = 1 Then
            Mat211.Text = "Bad"
        ElseIf M211.Value = 2 Then
            Mat211.Text = "Fairly Bad"
        ElseIf M211.Value = 3 Then
            Mat211.Text = "Fair"
        ElseIf M211.Value = 4 Then
            Mat211.Text = "Fairly Good"
        ElseIf M211.Value = 5 Then
            Mat211.Text = "Good"
        ElseIf M211.Value = 6 Then
            Mat211.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M211.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M211.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M211.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M211.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M211.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M211.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M211.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(10, 0) = a
        RMAT2(10, 1) = b
        RMAT2(10, 2) = c
        RMAT2(10, 3) = d

    End Sub

    Private Sub M311_Scroll(sender As Object, e As EventArgs) Handles M311.Scroll
        If M311.Value = 0 Then
            Mat311.Text = "Very Bad"
        ElseIf M311.Value = 1 Then
            Mat311.Text = "Bad"
        ElseIf M311.Value = 2 Then
            Mat311.Text = "Fairly Bad"
        ElseIf M311.Value = 3 Then
            Mat311.Text = "Fair"
        ElseIf M311.Value = 4 Then
            Mat311.Text = "Fairly Good"
        ElseIf M311.Value = 5 Then
            Mat311.Text = "Good"
        ElseIf M311.Value = 6 Then
            Mat311.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M311.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M311.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M311.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M311.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M311.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M311.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M311.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(10, 0) = a
        RMAT3(10, 1) = b
        RMAT3(10, 2) = c
        RMAT3(10, 3) = d

    End Sub

    Private Sub M411_Scroll(sender As Object, e As EventArgs) Handles M411.Scroll
        If M411.Value = 0 Then
            Mat411.Text = "Very Bad"
        ElseIf M411.Value = 1 Then
            Mat411.Text = "Bad"
        ElseIf M411.Value = 2 Then
            Mat411.Text = "Fairly Bad"
        ElseIf M411.Value = 3 Then
            Mat411.Text = "Fair"
        ElseIf M411.Value = 4 Then
            Mat411.Text = "Fairly Good"
        ElseIf M411.Value = 5 Then
            Mat411.Text = "Good"
        ElseIf M411.Value = 6 Then
            Mat411.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M411.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M411.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M411.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M411.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M411.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M411.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M411.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(10, 0) = a
        RMAT4(10, 1) = b
        RMAT4(10, 2) = c
        RMAT4(10, 3) = d

    End Sub

    Private Sub M511_Scroll(sender As Object, e As EventArgs) Handles M511.Scroll
        If M511.Value = 0 Then
            MaT511.Text = "Very Bad"
        ElseIf M511.Value = 1 Then
            MaT511.Text = "Bad"
        ElseIf M511.Value = 2 Then
            MaT511.Text = "Fairly Bad"
        ElseIf M511.Value = 3 Then
            MaT511.Text = "Fair"
        ElseIf M511.Value = 4 Then
            MaT511.Text = "Fairly Good"
        ElseIf M511.Value = 5 Then
            MaT511.Text = "Good"
        ElseIf M511.Value = 6 Then
            MaT511.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M511.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M511.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M511.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M511.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M511.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M511.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M511.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(10, 0) = a
        RMAT5(10, 1) = b
        RMAT5(10, 2) = c
        RMAT5(10, 3) = d

    End Sub

    Private Sub M212_Scroll(sender As Object, e As EventArgs) Handles M212.Scroll
        If M212.Value = 0 Then
            Mat212.Text = "Very Bad"
        ElseIf M212.Value = 1 Then
            Mat212.Text = "Bad"
        ElseIf M212.Value = 2 Then
            Mat212.Text = "Fairly Bad"
        ElseIf M212.Value = 3 Then
            Mat212.Text = "Fair"
        ElseIf M212.Value = 4 Then
            Mat212.Text = "Fairly Good"
        ElseIf M212.Value = 5 Then
            Mat212.Text = "Good"
        ElseIf M212.Value = 6 Then
            Mat212.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M212.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M212.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M212.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M212.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M212.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M212.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M212.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(11, 0) = a
        RMAT2(11, 1) = b
        RMAT2(11, 2) = c
        RMAT2(11, 3) = d
    End Sub

    Private Sub M312_Scroll(sender As Object, e As EventArgs) Handles M312.Scroll
        If M312.Value = 0 Then
            Mat312.Text = "Very Bad"
        ElseIf M312.Value = 1 Then
            Mat312.Text = "Bad"
        ElseIf M312.Value = 2 Then
            Mat312.Text = "Fairly Bad"
        ElseIf M312.Value = 3 Then
            Mat312.Text = "Fair"
        ElseIf M312.Value = 4 Then
            Mat312.Text = "Fairly Good"
        ElseIf M312.Value = 5 Then
            Mat312.Text = "Good"
        ElseIf M312.Value = 6 Then
            Mat312.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M312.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M312.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M312.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M312.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M312.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M312.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M312.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(11, 0) = a
        RMAT3(11, 1) = b
        RMAT3(11, 2) = c
        RMAT3(11, 3) = d
    End Sub

    Private Sub M412_Scroll(sender As Object, e As EventArgs) Handles M412.Scroll
        If M412.Value = 0 Then
            Mat412.Text = "Very Bad"
        ElseIf M412.Value = 1 Then
            Mat412.Text = "Bad"
        ElseIf M412.Value = 2 Then
            Mat412.Text = "Fairly Bad"
        ElseIf M412.Value = 3 Then
            Mat412.Text = "Fair"
        ElseIf M412.Value = 4 Then
            Mat412.Text = "Fairly Good"
        ElseIf M412.Value = 5 Then
            Mat412.Text = "Good"
        ElseIf M412.Value = 6 Then
            Mat412.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M412.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M412.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M412.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M412.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M412.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M412.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M412.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(11, 0) = a
        RMAT4(11, 1) = b
        RMAT4(11, 2) = c
        RMAT4(11, 3) = d

    End Sub

    Private Sub M512_Scroll(sender As Object, e As EventArgs) Handles M512.Scroll
        If M512.Value = 0 Then
            Mat512.Text = "Very Bad"
        ElseIf M512.Value = 1 Then
            Mat512.Text = "Bad"
        ElseIf M512.Value = 2 Then
            Mat512.Text = "Fairly Bad"
        ElseIf M512.Value = 3 Then
            Mat512.Text = "Fair"
        ElseIf M512.Value = 4 Then
            Mat512.Text = "Fairly Good"
        ElseIf M512.Value = 5 Then
            Mat512.Text = "Good"
        ElseIf M512.Value = 6 Then
            Mat512.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M512.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M512.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M512.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M512.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M512.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M512.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M512.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(11, 0) = a
        RMAT5(11, 1) = b
        RMAT5(11, 2) = c
        RMAT5(11, 3) = d
    End Sub

    Private Sub M213_Scroll(sender As Object, e As EventArgs) Handles M213.Scroll
        If M213.Value = 0 Then
            Mat213.Text = "Very Bad"
        ElseIf M213.Value = 1 Then
            Mat213.Text = "Bad"
        ElseIf M213.Value = 2 Then
            Mat213.Text = "Fairly Bad"
        ElseIf M213.Value = 3 Then
            Mat213.Text = "Fair"
        ElseIf M213.Value = 4 Then
            Mat213.Text = "Fairly Good"
        ElseIf M213.Value = 5 Then
            Mat213.Text = "Good"
        ElseIf M213.Value = 6 Then
            Mat213.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M213.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M213.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M213.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M213.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M213.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M213.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M213.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(12, 0) = a
        RMAT2(12, 1) = b
        RMAT2(12, 2) = c
        RMAT2(12, 3) = d
    End Sub

    Private Sub M313_Scroll(sender As Object, e As EventArgs) Handles M313.Scroll
        If M313.Value = 0 Then
            Mat313.Text = "Very Bad"
        ElseIf M313.Value = 1 Then
            Mat313.Text = "Bad"
        ElseIf M313.Value = 2 Then
            Mat313.Text = "Fairly Bad"
        ElseIf M313.Value = 3 Then
            Mat313.Text = "Fair"
        ElseIf M313.Value = 4 Then
            Mat313.Text = "Fairly Good"
        ElseIf M313.Value = 5 Then
            Mat313.Text = "Good"
        ElseIf M313.Value = 6 Then
            Mat313.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M313.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M313.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M313.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M313.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M313.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M313.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M313.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(12, 0) = a
        RMAT3(12, 1) = b
        RMAT3(12, 2) = c
        RMAT3(12, 3) = d

    End Sub

    Private Sub M413_Scroll(sender As Object, e As EventArgs) Handles M413.Scroll
        If M413.Value = 0 Then
            Mat413.Text = "Very Bad"
        ElseIf M413.Value = 1 Then
            Mat413.Text = "Bad"
        ElseIf M413.Value = 2 Then
            Mat413.Text = "Fairly Bad"
        ElseIf M413.Value = 3 Then
            Mat413.Text = "Fair"
        ElseIf M413.Value = 4 Then
            Mat413.Text = "Fairly Good"
        ElseIf M413.Value = 5 Then
            Mat413.Text = "Good"
        ElseIf M413.Value = 6 Then
            Mat413.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M413.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M413.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M413.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M413.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M413.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M413.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M413.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(12, 0) = a
        RMAT4(12, 1) = b
        RMAT4(12, 2) = c
        RMAT4(12, 3) = d

    End Sub

    Private Sub M513_Scroll(sender As Object, e As EventArgs) Handles M513.Scroll
        If M513.Value = 0 Then
            Mat513.Text = "Very Bad"
        ElseIf M513.Value = 1 Then
            Mat513.Text = "Bad"
        ElseIf M513.Value = 2 Then
            Mat513.Text = "Fairly Bad"
        ElseIf M513.Value = 3 Then
            Mat513.Text = "Fair"
        ElseIf M513.Value = 4 Then
            Mat513.Text = "Fairly Good"
        ElseIf M513.Value = 5 Then
            Mat513.Text = "Good"
        ElseIf M513.Value = 6 Then
            Mat513.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M513.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M513.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M513.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M513.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M513.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M513.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M513.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(12, 0) = a
        RMAT5(12, 1) = b
        RMAT5(12, 2) = c
        RMAT5(12, 3) = d
    End Sub

    Private Sub M214_Scroll(sender As Object, e As EventArgs) Handles M214.Scroll
        If M214.Value = 0 Then
            Mat214.Text = "Very Bad"
        ElseIf M214.Value = 1 Then
            Mat214.Text = "Bad"
        ElseIf M214.Value = 2 Then
            Mat214.Text = "Fairly Bad"
        ElseIf M214.Value = 3 Then
            Mat214.Text = "Fair"
        ElseIf M214.Value = 4 Then
            Mat214.Text = "Fairly Good"
        ElseIf M214.Value = 5 Then
            Mat214.Text = "Good"
        ElseIf M214.Value = 6 Then
            Mat214.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M214.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M214.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M214.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M214.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M214.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M214.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M214.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(13, 0) = a
        RMAT2(13, 1) = b
        RMAT2(13, 2) = c
        RMAT2(13, 3) = d
    End Sub

    Private Sub M314_Scroll(sender As Object, e As EventArgs) Handles M314.Scroll
        If M314.Value = 0 Then
            Mat314.Text = "Very Bad"
        ElseIf M314.Value = 1 Then
            Mat314.Text = "Bad"
        ElseIf M314.Value = 2 Then
            Mat314.Text = "Fairly Bad"
        ElseIf M314.Value = 3 Then
            Mat314.Text = "Fair"
        ElseIf M314.Value = 4 Then
            Mat314.Text = "Fairly Good"
        ElseIf M314.Value = 5 Then
            Mat314.Text = "Good"
        ElseIf M314.Value = 6 Then
            Mat314.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M314.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M314.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M314.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M314.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M314.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M314.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M314.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(13, 0) = a
        RMAT3(13, 1) = b
        RMAT3(13, 2) = c
        RMAT3(13, 3) = d

    End Sub

    Private Sub M414_Scroll(sender As Object, e As EventArgs) Handles M414.Scroll
        If M414.Value = 0 Then
            Mat414.Text = "Very Bad"
        ElseIf M414.Value = 1 Then
            Mat414.Text = "Bad"
        ElseIf M414.Value = 2 Then
            Mat414.Text = "Fairly Bad"
        ElseIf M414.Value = 3 Then
            Mat414.Text = "Fair"
        ElseIf M414.Value = 4 Then
            Mat414.Text = "Fairly Good"
        ElseIf M414.Value = 5 Then
            Mat414.Text = "Good"
        ElseIf M414.Value = 6 Then
            Mat414.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M414.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M414.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M414.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M414.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M414.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M414.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M414.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(13, 0) = a
        RMAT4(13, 1) = b
        RMAT4(13, 2) = c
        RMAT4(13, 3) = d
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'rateM1, Rate M2,... RateM5 are IMPXRating of Material
        If MaterialSelection.CheckBox4.Enabled = True Then
            For i = 0 To 3
                sumwiriM1(i) = 0
                sumwiriM2(i) = 0
                sumwiriM3(i) = 0
                sumwiriM4(i) = 0
                sumwiriM5(i) = 0
            Next i
            O5(0) = 0
            O5(1) = 0
            O5(2) = 0
            O5(3) = 0
            O5(4) = 0

            EQ1 = 0
            EQ2 = 0
            EQ3 = 0
            EQ4 = 0
            EQ5 = 0
            For i = 0 To 19
                RateM1(i, 0) = IMP(i, 0) * RMAT1(i, 0)
                RateM1(i, 1) = IMP(i, 1) * RMAT1(i, 1)
                RateM1(i, 2) = IMP(i, 2) * RMAT1(i, 2)
                RateM1(i, 3) = IMP(i, 3) * RMAT1(i, 3)

                RateM2(i, 0) = IMP(i, 0) * RMAT2(i, 0)
                RateM2(i, 1) = IMP(i, 1) * RMAT2(i, 1)
                RateM2(i, 2) = IMP(i, 2) * RMAT2(i, 2)
                RateM2(i, 3) = IMP(i, 3) * RMAT2(i, 3)

                RateM3(i, 0) = IMP(i, 0) * RMAT3(i, 0)
                RateM3(i, 1) = IMP(i, 1) * RMAT3(i, 1)
                RateM3(i, 2) = IMP(i, 2) * RMAT3(i, 2)
                RateM3(i, 3) = IMP(i, 3) * RMAT3(i, 3)

                RateM4(i, 0) = IMP(i, 0) * RMAT4(i, 0)
                RateM4(i, 1) = IMP(i, 1) * RMAT4(i, 1)
                RateM4(i, 2) = IMP(i, 2) * RMAT4(i, 2)
                RateM4(i, 3) = IMP(i, 3) * RMAT4(i, 3)

                RateM5(i, 0) = IMP(i, 0) * RMAT5(i, 0)
                RateM5(i, 1) = IMP(i, 1) * RMAT5(i, 1)
                RateM5(i, 2) = IMP(i, 2) * RMAT5(i, 2)
                RateM5(i, 3) = IMP(i, 3) * RMAT5(i, 3)


                Form3.ListView1.Items.Add(i)
                Form3.ListView1.Items(i).SubItems.Add(IMP(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(IMP(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(IMP(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(IMP(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RMAT1(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RMAT1(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RMAT1(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RMAT1(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RMAT2(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RMAT2(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RMAT2(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RMAT2(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RMAT3(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RMAT3(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RMAT3(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RMAT3(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RMAT4(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RMAT4(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RMAT4(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RMAT4(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RMAT5(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RMAT5(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RMAT5(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RMAT5(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RateM1(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RateM1(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RateM1(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RateM1(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RateM2(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RateM2(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RateM2(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RateM2(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RateM3(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RateM3(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RateM3(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RateM3(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RateM4(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RateM4(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RateM4(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RateM4(i, 3))
                Form3.ListView1.Items(i).SubItems.Add(RateM5(i, 0))
                Form3.ListView1.Items(i).SubItems.Add(RateM5(i, 1))
                Form3.ListView1.Items(i).SubItems.Add(RateM5(i, 2))
                Form3.ListView1.Items(i).SubItems.Add(RateM5(i, 3))
            Next i

            sumwiriM1(0) = RateM1(0, 0) + RateM1(1, 0) + RateM1(2, 0) + RateM1(3, 0) + RateM1(4, 0) + RateM1(5, 0) + RateM1(6, 0) + RateM1(7, 0) + RateM1(8, 0) + RateM1(9, 0) + RateM1(10, 0) + RateM1(11, 0) + RateM1(12, 0) + RateM1(13, 0) + RateM1(14, 0) + RateM1(15, 0) + RateM1(16, 0) + RateM1(17, 0) + RateM1(18, 0) + RateM1(19, 0)
            sumwiriM1(1) = RateM1(0, 1) + RateM1(1, 1) + RateM1(2, 1) + RateM1(3, 1) + RateM1(4, 1) + RateM1(5, 1) + RateM1(6, 1) + RateM1(7, 1) + RateM1(8, 1) + RateM1(9, 1) + RateM1(10, 1) + RateM1(11, 1) + RateM1(12, 1) + RateM1(13, 1) + RateM1(14, 1) + RateM1(15, 1) + RateM1(16, 1) + RateM1(17, 1) + RateM1(18, 1) + RateM1(19, 1)
            sumwiriM1(2) = RateM1(0, 2) + RateM1(1, 2) + RateM1(2, 2) + RateM1(3, 2) + RateM1(4, 2) + RateM1(5, 2) + RateM1(6, 2) + RateM1(7, 2) + RateM1(8, 2) + RateM1(9, 2) + RateM1(10, 2) + RateM1(11, 2) + RateM1(12, 2) + RateM1(13, 2) + RateM1(14, 2) + RateM1(15, 2) + RateM1(16, 2) + RateM1(17, 2) + RateM1(18, 2) + RateM1(19, 2)
            sumwiriM1(3) = RateM1(0, 3) + RateM1(1, 3) + RateM1(2, 3) + RateM1(3, 3) + RateM1(4, 3) + RateM1(5, 3) + RateM1(6, 3) + RateM1(7, 3) + RateM1(8, 3) + RateM1(9, 3) + RateM1(10, 3) + RateM1(11, 3) + RateM1(12, 3) + RateM1(13, 3) + RateM1(14, 3) + RateM1(15, 3) + RateM1(16, 3) + RateM1(17, 3) + RateM1(18, 3) + RateM1(19, 3)

            sumwiriM2(0) = RateM2(0, 0) + RateM2(1, 0) + RateM2(2, 0) + RateM2(3, 0) + RateM2(4, 0) + RateM2(5, 0) + RateM2(6, 0) + RateM2(7, 0) + RateM2(8, 0) + RateM2(9, 0) + RateM2(10, 0) + RateM2(11, 0) + RateM2(12, 0) + RateM2(13, 0) + RateM2(14, 0) + RateM2(15, 0) + RateM2(16, 0) + RateM2(17, 0) + RateM2(18, 0) + RateM2(19, 0)
            sumwiriM2(1) = RateM2(0, 1) + RateM2(1, 1) + RateM2(2, 1) + RateM2(3, 1) + RateM2(4, 1) + RateM2(5, 1) + RateM2(6, 1) + RateM2(7, 1) + RateM2(8, 1) + RateM2(9, 1) + RateM2(10, 1) + RateM2(11, 1) + RateM2(12, 1) + RateM2(13, 1) + RateM2(14, 1) + RateM2(15, 1) + RateM2(16, 1) + RateM2(17, 1) + RateM2(18, 1) + RateM2(19, 1)
            sumwiriM2(2) = RateM2(0, 2) + RateM2(1, 2) + RateM2(2, 2) + RateM2(3, 2) + RateM2(4, 2) + RateM2(5, 2) + RateM2(6, 2) + RateM2(7, 2) + RateM2(8, 2) + RateM2(9, 2) + RateM2(10, 2) + RateM2(11, 2) + RateM2(12, 2) + RateM2(13, 2) + RateM2(14, 2) + RateM2(15, 2) + RateM2(16, 2) + RateM2(17, 2) + RateM2(18, 2) + RateM2(19, 2)
            sumwiriM2(3) = RateM2(0, 3) + RateM2(1, 3) + RateM2(2, 3) + RateM2(3, 3) + RateM2(4, 3) + RateM2(5, 3) + RateM2(6, 3) + RateM2(7, 3) + RateM2(8, 3) + RateM2(9, 3) + RateM2(10, 3) + RateM2(11, 3) + RateM2(12, 3) + RateM2(13, 3) + RateM2(14, 3) + RateM2(15, 3) + RateM2(16, 3) + RateM2(17, 3) + RateM2(18, 3) + RateM2(19, 3)


            sumwiriM3(0) = RateM3(0, 0) + RateM3(1, 0) + RateM3(2, 0) + RateM3(3, 0) + RateM3(4, 0) + RateM3(5, 0) + RateM3(6, 0) + RateM3(7, 0) + RateM3(8, 0) + RateM3(9, 0) + RateM3(10, 0) + RateM3(11, 0) + RateM3(12, 0) + RateM3(13, 0) + RateM3(14, 0) + RateM3(15, 0) + RateM3(16, 0) + RateM3(17, 0) + RateM3(18, 0) + RateM3(19, 0)
            sumwiriM3(1) = RateM3(0, 1) + RateM3(1, 1) + RateM3(2, 1) + RateM3(3, 1) + RateM3(4, 1) + RateM3(5, 1) + RateM3(6, 1) + RateM3(7, 1) + RateM3(8, 1) + RateM3(9, 1) + RateM3(10, 1) + RateM3(11, 1) + RateM3(12, 1) + RateM3(13, 1) + RateM3(14, 1) + RateM3(15, 1) + RateM3(16, 1) + RateM3(17, 1) + RateM3(18, 1) + RateM3(19, 1)
            sumwiriM3(2) = RateM3(0, 2) + RateM3(1, 2) + RateM3(2, 2) + RateM3(3, 2) + RateM3(4, 2) + RateM3(5, 2) + RateM3(6, 2) + RateM3(7, 2) + RateM3(8, 2) + RateM3(9, 2) + RateM3(10, 2) + RateM3(11, 2) + RateM3(12, 2) + RateM3(13, 2) + RateM3(14, 2) + RateM3(15, 2) + RateM3(16, 2) + RateM3(17, 2) + RateM3(18, 2) + RateM3(19, 2)
            sumwiriM3(3) = RateM3(0, 3) + RateM3(1, 3) + RateM3(2, 3) + RateM3(3, 3) + RateM3(4, 3) + RateM3(5, 3) + RateM3(6, 3) + RateM3(7, 3) + RateM3(8, 3) + RateM3(9, 3) + RateM3(10, 3) + RateM3(11, 3) + RateM3(12, 3) + RateM3(13, 3) + RateM3(14, 3) + RateM3(15, 3) + RateM3(16, 3) + RateM3(17, 3) + RateM3(18, 3) + RateM3(19, 3)

            sumwiriM4(0) = RateM4(0, 0) + RateM4(1, 0) + RateM4(2, 0) + RateM4(3, 0) + RateM4(4, 0) + RateM4(5, 0) + RateM4(6, 0) + RateM4(7, 0) + RateM4(8, 0) + RateM4(9, 0) + RateM4(10, 0) + RateM4(11, 0) + RateM4(12, 0) + RateM4(13, 0) + RateM4(14, 0) + RateM4(15, 0) + RateM4(16, 0) + RateM4(17, 0) + RateM4(18, 0) + RateM4(19, 0)
            sumwiriM4(1) = RateM4(0, 1) + RateM4(1, 1) + RateM4(2, 1) + RateM4(3, 1) + RateM4(4, 1) + RateM4(5, 1) + RateM4(6, 1) + RateM4(7, 1) + RateM4(8, 1) + RateM4(9, 1) + RateM4(10, 1) + RateM4(11, 1) + RateM4(12, 1) + RateM4(13, 1) + RateM4(14, 1) + RateM4(15, 1) + RateM4(16, 1) + RateM4(17, 1) + RateM4(18, 1) + RateM4(19, 1)
            sumwiriM4(2) = RateM4(0, 2) + RateM4(1, 2) + RateM4(2, 2) + RateM4(3, 2) + RateM4(4, 2) + RateM4(5, 2) + RateM4(6, 2) + RateM4(7, 2) + RateM4(8, 2) + RateM4(9, 2) + RateM4(10, 2) + RateM4(11, 2) + RateM4(12, 2) + RateM4(13, 2) + RateM4(14, 2) + RateM4(15, 2) + RateM4(16, 2) + RateM4(17, 2) + RateM4(18, 2) + RateM4(19, 2)
            sumwiriM4(3) = RateM4(0, 3) + RateM4(1, 3) + RateM4(2, 3) + RateM4(3, 3) + RateM4(4, 3) + RateM4(5, 3) + RateM4(6, 3) + RateM4(7, 3) + RateM4(8, 3) + RateM4(9, 3) + RateM4(10, 3) + RateM4(11, 3) + RateM4(12, 3) + RateM4(13, 3) + RateM4(14, 3) + RateM4(15, 3) + RateM4(16, 3) + RateM4(17, 3) + RateM4(18, 3) + RateM4(19, 3)

            sumwiriM5(0) = RateM5(0, 0) + RateM5(1, 0) + RateM5(2, 0) + RateM5(3, 0) + RateM5(4, 0) + RateM5(5, 0) + RateM5(6, 0) + RateM5(7, 0) + RateM5(8, 0) + RateM5(9, 0) + RateM5(10, 0) + RateM5(11, 0) + RateM5(12, 0) + RateM5(13, 0) + RateM5(14, 0) + RateM5(15, 0) + RateM5(16, 0) + RateM5(17, 0) + RateM5(18, 0) + RateM5(19, 0)
            sumwiriM5(1) = RateM5(0, 1) + RateM5(1, 1) + RateM5(2, 1) + RateM5(3, 1) + RateM5(4, 1) + RateM5(5, 1) + RateM5(6, 1) + RateM5(7, 1) + RateM5(8, 1) + RateM5(9, 1) + RateM5(10, 1) + RateM5(11, 1) + RateM5(12, 1) + RateM5(13, 1) + RateM5(14, 1) + RateM5(15, 1) + RateM5(16, 1) + RateM5(17, 1) + RateM5(18, 1) + RateM5(19, 1)
            sumwiriM5(2) = RateM5(0, 2) + RateM5(1, 2) + RateM5(2, 2) + RateM5(3, 2) + RateM5(4, 2) + RateM5(5, 2) + RateM5(6, 2) + RateM5(7, 2) + RateM5(8, 2) + RateM5(9, 2) + RateM5(10, 2) + RateM5(11, 2) + RateM5(12, 2) + RateM5(13, 2) + RateM5(14, 2) + RateM5(15, 2) + RateM5(16, 2) + RateM5(17, 2) + RateM5(18, 2) + RateM5(19, 2)
            sumwiriM5(3) = RateM5(0, 3) + RateM5(1, 3) + RateM5(2, 3) + RateM5(3, 3) + RateM5(4, 3) + RateM5(5, 3) + RateM5(6, 3) + RateM5(7, 3) + RateM5(8, 3) + RateM5(9, 3) + RateM5(10, 3) + RateM5(11, 3) + RateM5(12, 3) + RateM5(13, 3) + RateM5(14, 3) + RateM5(15, 3) + RateM5(16, 3) + RateM5(17, 3) + RateM5(18, 3) + RateM5(19, 3)

            sumwiridivsumwM1(0) = sumwiriM1(0) / sumwsub(3)
            sumwiridivsumwM1(1) = sumwiriM1(1) / sumwsub(2)
            sumwiridivsumwM1(2) = sumwiriM1(2) / sumwsub(1)
            sumwiridivsumwM1(3) = sumwiriM1(3) / sumwsub(0)

            sumwiridivsumwM2(0) = sumwiriM2(0) / sumwsub(3)
            sumwiridivsumwM2(1) = sumwiriM2(1) / sumwsub(2)
            sumwiridivsumwM2(2) = sumwiriM2(2) / sumwsub(1)
            sumwiridivsumwM2(3) = sumwiriM2(3) / sumwsub(0)

            sumwiridivsumwM3(0) = sumwiriM3(0) / sumwsub(3)
            sumwiridivsumwM3(1) = sumwiriM3(1) / sumwsub(2)
            sumwiridivsumwM3(2) = sumwiriM3(2) / sumwsub(1)
            sumwiridivsumwM3(3) = sumwiriM3(3) / sumwsub(0)

            sumwiridivsumwM4(0) = sumwiriM4(0) / sumwsub(3)
            sumwiridivsumwM4(1) = sumwiriM4(1) / sumwsub(2)
            sumwiridivsumwM4(2) = sumwiriM4(2) / sumwsub(1)
            sumwiridivsumwM4(3) = sumwiriM4(3) / sumwsub(0)

            sumwiridivsumwM5(0) = sumwiriM5(0) / sumwsub(3)
            sumwiridivsumwM5(1) = sumwiriM5(1) / sumwsub(2)
            sumwiridivsumwM5(2) = sumwiriM5(2) / sumwsub(1)
            sumwiridivsumwM5(3) = sumwiriM5(3) / sumwsub(0)

            'Defuzzification
            EQ1 = 2 - ((sumwiridivsumwM1(0) + sumwiridivsumwM1(1) + sumwiridivsumwM1(2) + sumwiridivsumwM1(3)) / 2)
            EQ2 = 2 - ((sumwiridivsumwM2(0) + sumwiridivsumwM2(1) + sumwiridivsumwM2(2) + sumwiridivsumwM2(3)) / 2)
            EQ3 = 2 - ((sumwiridivsumwM3(0) + sumwiridivsumwM3(1) + sumwiridivsumwM3(2) + sumwiridivsumwM3(3)) / 2)
            EQ4 = 2 - ((sumwiridivsumwM4(0) + sumwiridivsumwM4(1) + sumwiridivsumwM4(2) + sumwiridivsumwM4(3)) / 2)
            EQ5 = 2 - ((sumwiridivsumwM5(0) + sumwiridivsumwM5(1) + sumwiridivsumwM5(2) + sumwiridivsumwM5(3)) / 2)


            Form3.ListView1.Items(0).SubItems.Add(sumwiriM1(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM1(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM1(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM1(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiriM2(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM2(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM2(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM2(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiriM3(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM3(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM3(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM3(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiriM4(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM4(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM4(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM4(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiriM5(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM5(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM5(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiriM5(3))


            Form3.ListView1.Items(0).SubItems.Add(sumwsub(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwsub(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwsub(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwsub(3))


            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(3))


            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(3))

            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM5(0))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM5(1))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM5(2))
            Form3.ListView1.Items(0).SubItems.Add(sumwiridivsumwM5(3))

            Form3.ListView1.Items(0).SubItems.Add(EQ1)
            Form3.ListView1.Items(0).SubItems.Add(EQ2)
            Form3.ListView1.Items(0).SubItems.Add(EQ3)
            Form3.ListView1.Items(0).SubItems.Add(EQ4)
            Form3.ListView1.Items(0).SubItems.Add(EQ5)

            Form3.Show()


            O5(0) = EQ1
            O5(1) = EQ2
            O5(2) = EQ3
            O5(3) = EQ4
            O5(4) = EQ5
            Array.Sort(O5)

            If O5(0) = EQ1 Then L1 = Label1.Text
            If O5(0) = EQ2 Then L1 = Label3.Text
            If O5(0) = EQ3 Then L1 = Label5.Text
            If O5(0) = EQ4 Then L1 = Label7.Text
            If O5(0) = EQ5 Then L1 = Label9.Text

            If O5(1) = EQ1 Then L2 = Label1.Text
            If O5(1) = EQ2 Then L2 = Label3.Text
            If O5(1) = EQ3 Then L2 = Label5.Text
            If O5(1) = EQ4 Then L2 = Label7.Text
            If O5(1) = EQ5 Then L2 = Label9.Text

            If O5(2) = EQ1 Then L3 = Label1.Text
            If O5(2) = EQ2 Then L3 = Label3.Text
            If O5(2) = EQ3 Then L3 = Label5.Text
            If O5(2) = EQ4 Then L3 = Label7.Text
            If O5(2) = EQ5 Then L3 = Label9.Text

            If O5(3) = EQ1 Then L4 = Label1.Text
            If O5(3) = EQ2 Then L4 = Label3.Text
            If O5(3) = EQ3 Then L4 = Label5.Text
            If O5(3) = EQ4 Then L4 = Label7.Text
            If O5(3) = EQ5 Then L4 = Label9.Text

            If O5(4) = EQ1 Then L5 = Label1.Text
            If O5(4) = EQ2 Then L5 = Label3.Text
            If O5(4) = EQ3 Then L5 = Label5.Text
            If O5(4) = EQ4 Then L5 = Label7.Text
            If O5(4) = EQ5 Then L5 = Label9.Text


            O5(0) = Math.Round(O5(0), 4)
            O5(1) = Math.Round(O5(1), 4)
            O5(2) = Math.Round(O5(2), 4)
            O5(3) = Math.Round(O5(3), 4)
            O5(4) = Math.Round(O5(4), 4)




            Form7.Chart1.Series.Add(L1)
            Form7.Chart1.Series(L1).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
            Form7.Chart1.Series(L1).Color = Color.Red
            Form7.Chart1.Series(L1).BorderWidth = 3
            If L1 = Label1.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L1 = Label3.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L1 = Label5.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L1 = Label7.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If
            If L1 = Label9.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM5(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM5(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM5(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM5(3), 0)
            End If

            Form7.Chart1.Series.Add(L2)
            Form7.Chart1.Series(L2).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L2).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDot
            Form7.Chart1.Series(L2).Color = Color.Blue
            Form7.Chart1.Series(L2).BorderWidth = 3
            If L2 = Label1.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L2 = Label3.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L2 = Label5.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L2 = Label7.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If
            If L2 = Label9.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM5(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM5(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM5(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM5(3), 0)
            End If


            Form7.Chart1.Series.Add(L3)
            Form7.Chart1.Series(L3).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L3).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDotDot
            Form7.Chart1.Series(L3).Color = Color.Green
            Form7.Chart1.Series(L3).BorderWidth = 3
            If L3 = Label1.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L3 = Label3.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L3 = Label5.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L3 = Label7.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If
            If L3 = Label9.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM5(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM5(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM5(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM5(3), 0)
            End If
            Form7.Chart1.Series.Add(L4)
            Form7.Chart1.Series(L4).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L4).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dot
            Form7.Chart1.Series(L4).Color = Color.Purple
            Form7.Chart1.Series(L4).BorderWidth = 3
            If L4 = Label1.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L4 = Label3.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L4 = Label5.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If

            If L4 = Label7.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If

            If L4 = Label9.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM5(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM5(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM5(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM5(3), 0)
            End If

            Form7.Chart1.Series.Add(L5)
            Form7.Chart1.Series(L5).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L5).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Solid
            Form7.Chart1.Series(L5).Color = Color.DarkOliveGreen
            Form7.Chart1.Series(L5).BorderWidth = 3
            If L5 = Label1.Text Then
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L5 = Label3.Text Then
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L5 = Label5.Text Then
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L5 = Label7.Text Then
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If
            If L5 = Label9.Text Then
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM5(0), 0)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM5(1), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM5(2), 1)
                Form7.Chart1.Series(L5).Points.AddXY(sumwiridivsumwM5(3), 0)
            End If

            Form7.Show()



                Form8.ListView1.Items.Add("1")
                Form8.ListView1.Items(0).SubItems.Add(L1)
                Form8.ListView1.Items(0).SubItems.Add(O5(0))
                Form8.ListView1.Items.Add("2")
                Form8.ListView1.Items(1).SubItems.Add(L2)
                Form8.ListView1.Items(1).SubItems.Add(O5(1))
                Form8.ListView1.Items.Add("3")
                Form8.ListView1.Items(2).SubItems.Add(L3)
                Form8.ListView1.Items(2).SubItems.Add(O5(2))
                Form8.ListView1.Items.Add("4")
                Form8.ListView1.Items(3).SubItems.Add(L4)
                Form8.ListView1.Items(3).SubItems.Add(O5(3))
                Form8.ListView1.Items.Add("5")
                Form8.ListView1.Items(4).SubItems.Add(L5)
                Form8.ListView1.Items(4).SubItems.Add(O5(4))


                Form8.Chart1.Series.Add(L1)
                Form8.Chart1.BorderlineWidth = 3
                Form8.Chart1.Series(L1).Color = Form7.Chart1.Series(L1).Color
                Form8.Chart1.Series(L1).AxisLabel = L1
                Form8.Chart1.Series(L1).Points.AddXY(1, O5(0))
                Form8.Chart1.Series(L1).Label = O5(0)

                Form8.Chart1.Series.Add(L2)
                Form8.Chart1.Series(L2).Color = Form7.Chart1.Series(L2).Color
                Form8.Chart1.Series(L2).Points.AddXY(2, O5(1))
                Form8.Chart1.Series(L2).AxisLabel = L2
                Form8.Chart1.Series(L2).Label = O5(1)

                Form8.Chart1.Series.Add(L3)
                Form8.Chart1.Series(L3).Color = Form7.Chart1.Series(L3).Color
                Form8.Chart1.Series(L3).Points.AddXY(3, O5(2))
                Form8.Chart1.Series(L3).AxisLabel = L3
                Form8.Chart1.Series(L3).Label = O5(2)

                Form8.Chart1.Series.Add(L4)
                Form8.Chart1.Series(L4).Color = Form7.Chart1.Series(L4).Color
                Form8.Chart1.Series(L4).Points.AddXY(4, O5(3))
                Form8.Chart1.Series(L4).AxisLabel = L4
                Form8.Chart1.Series(L4).Label = O5(3)

                Form8.Chart1.Series.Add(L5)
                Form8.Chart1.Series(L5).Color = Form7.Chart1.Series(L5).Color
                Form8.Chart1.Series(L5).Points.AddXY(5, O5(4))
                Form8.Chart1.Series(L5).AxisLabel = L5
                Form8.Chart1.Series(L5).Label = O5(4)
            End If


            'rateM1, Rate M2,... RateM4 are IMPXRating of Material
            If MaterialSelection.CheckBox3.Enabled = True Then
            For i = 0 To 3
                sumwiriM1(i) = 0
                sumwiriM2(i) = 0
                sumwiriM3(i) = 0
                sumwiriM4(i) = 0

            Next i
            EQ1 = 0
            EQ2 = 0
            EQ3 = 0
            EQ4 = 0

            O4(0) = 0
            O4(1) = 0
            O4(2) = 0
            O4(3) = 0


            For i = 0 To 19
                RateM1(i, 0) = IMP(i, 0) * RMAT1(i, 0)
                RateM1(i, 1) = IMP(i, 1) * RMAT1(i, 1)
                RateM1(i, 2) = IMP(i, 2) * RMAT1(i, 2)
                RateM1(i, 3) = IMP(i, 3) * RMAT1(i, 3)

                RateM2(i, 0) = IMP(i, 0) * RMAT2(i, 0)
                RateM2(i, 1) = IMP(i, 1) * RMAT2(i, 1)
                RateM2(i, 2) = IMP(i, 2) * RMAT2(i, 2)
                RateM2(i, 3) = IMP(i, 3) * RMAT2(i, 3)

                RateM3(i, 0) = IMP(i, 0) * RMAT3(i, 0)
                RateM3(i, 1) = IMP(i, 1) * RMAT3(i, 1)
                RateM3(i, 2) = IMP(i, 2) * RMAT3(i, 2)
                RateM3(i, 3) = IMP(i, 3) * RMAT3(i, 3)

                RateM4(i, 0) = IMP(i, 0) * RMAT4(i, 0)
                RateM4(i, 1) = IMP(i, 1) * RMAT4(i, 1)
                RateM4(i, 2) = IMP(i, 2) * RMAT4(i, 2)
                RateM4(i, 3) = IMP(i, 3) * RMAT4(i, 3)



                Form4.ListView1.Items.Add(i)
                Form4.ListView1.Items(i).SubItems.Add(IMP(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(IMP(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(IMP(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(IMP(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RMAT1(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RMAT1(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RMAT1(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RMAT1(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RMAT2(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RMAT2(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RMAT2(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RMAT2(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RMAT3(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RMAT3(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RMAT3(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RMAT3(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RMAT4(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RMAT4(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RMAT4(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RMAT4(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RateM1(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RateM1(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RateM1(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RateM1(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RateM2(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RateM2(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RateM2(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RateM2(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RateM3(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RateM3(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RateM3(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RateM3(i, 3))
                Form4.ListView1.Items(i).SubItems.Add(RateM4(i, 0))
                Form4.ListView1.Items(i).SubItems.Add(RateM4(i, 1))
                Form4.ListView1.Items(i).SubItems.Add(RateM4(i, 2))
                Form4.ListView1.Items(i).SubItems.Add(RateM4(i, 3))

            Next i
            'For i = 0 To 3
            sumwiriM1(0) = RateM1(0, 0) + RateM1(1, 0) + RateM1(2, 0) + RateM1(3, 0) + RateM1(4, 0) + RateM1(5, 0) + RateM1(6, 0) + RateM1(7, 0) + RateM1(8, 0) + RateM1(9, 0) + RateM1(10, 0) + RateM1(11, 0) + RateM1(12, 0) + RateM1(13, 0) + RateM1(14, 0) + RateM1(15, 0) + RateM1(16, 0) + RateM1(17, 0) + RateM1(18, 0) + RateM1(19, 0)
            sumwiriM1(1) = RateM1(0, 1) + RateM1(1, 1) + RateM1(2, 1) + RateM1(3, 1) + RateM1(4, 1) + RateM1(5, 1) + RateM1(6, 1) + RateM1(7, 1) + RateM1(8, 1) + RateM1(9, 1) + RateM1(10, 1) + RateM1(11, 1) + RateM1(12, 1) + RateM1(13, 1) + RateM1(14, 1) + RateM1(15, 1) + RateM1(16, 1) + RateM1(17, 1) + RateM1(18, 1) + RateM1(19, 1)
            sumwiriM1(2) = RateM1(0, 2) + RateM1(1, 2) + RateM1(2, 2) + RateM1(3, 2) + RateM1(4, 2) + RateM1(5, 2) + RateM1(6, 2) + RateM1(7, 2) + RateM1(8, 2) + RateM1(9, 2) + RateM1(10, 2) + RateM1(11, 2) + RateM1(12, 2) + RateM1(13, 2) + RateM1(14, 2) + RateM1(15, 2) + RateM1(16, 2) + RateM1(17, 2) + RateM1(18, 2) + RateM1(19, 2)
            sumwiriM1(3) = RateM1(0, 3) + RateM1(1, 3) + RateM1(2, 3) + RateM1(3, 3) + RateM1(4, 3) + RateM1(5, 3) + RateM1(6, 3) + RateM1(7, 3) + RateM1(8, 3) + RateM1(9, 3) + RateM1(10, 3) + RateM1(11, 3) + RateM1(12, 3) + RateM1(13, 3) + RateM1(14, 3) + RateM1(15, 3) + RateM1(16, 3) + RateM1(17, 3) + RateM1(18, 3) + RateM1(19, 3)

            sumwiriM2(0) = RateM2(0, 0) + RateM2(1, 0) + RateM2(2, 0) + RateM2(3, 0) + RateM2(4, 0) + RateM2(5, 0) + RateM2(6, 0) + RateM2(7, 0) + RateM2(8, 0) + RateM2(9, 0) + RateM2(10, 0) + RateM2(11, 0) + RateM2(12, 0) + RateM2(13, 0) + RateM2(14, 0) + RateM2(15, 0) + RateM2(16, 0) + RateM2(17, 0) + RateM2(18, 0) + RateM2(19, 0)
            sumwiriM2(1) = RateM2(0, 1) + RateM2(1, 1) + RateM2(2, 1) + RateM2(3, 1) + RateM2(4, 1) + RateM2(5, 1) + RateM2(6, 1) + RateM2(7, 1) + RateM2(8, 1) + RateM2(9, 1) + RateM2(10, 1) + RateM2(11, 1) + RateM2(12, 1) + RateM2(13, 1) + RateM2(14, 1) + RateM2(15, 1) + RateM2(16, 1) + RateM2(17, 1) + RateM2(18, 1) + RateM2(19, 1)
            sumwiriM2(2) = RateM2(0, 2) + RateM2(1, 2) + RateM2(2, 2) + RateM2(3, 2) + RateM2(4, 2) + RateM2(5, 2) + RateM2(6, 2) + RateM2(7, 2) + RateM2(8, 2) + RateM2(9, 2) + RateM2(10, 2) + RateM2(11, 2) + RateM2(12, 2) + RateM2(13, 2) + RateM2(14, 2) + RateM2(15, 2) + RateM2(16, 2) + RateM2(17, 2) + RateM2(18, 2) + RateM2(19, 2)
            sumwiriM2(3) = RateM2(0, 3) + RateM2(1, 3) + RateM2(2, 3) + RateM2(3, 3) + RateM2(4, 3) + RateM2(5, 3) + RateM2(6, 3) + RateM2(7, 3) + RateM2(8, 3) + RateM2(9, 3) + RateM2(10, 3) + RateM2(11, 3) + RateM2(12, 3) + RateM2(13, 3) + RateM2(14, 3) + RateM2(15, 3) + RateM2(16, 3) + RateM2(17, 3) + RateM2(18, 3) + RateM2(19, 3)


            sumwiriM3(0) = RateM3(0, 0) + RateM3(1, 0) + RateM3(2, 0) + RateM3(3, 0) + RateM3(4, 0) + RateM3(5, 0) + RateM3(6, 0) + RateM3(7, 0) + RateM3(8, 0) + RateM3(9, 0) + RateM3(10, 0) + RateM3(11, 0) + RateM3(12, 0) + RateM3(13, 0) + RateM3(14, 0) + RateM3(15, 0) + RateM3(16, 0) + RateM3(17, 0) + RateM3(18, 0) + RateM3(19, 0)
            sumwiriM3(1) = RateM3(0, 1) + RateM3(1, 1) + RateM3(2, 1) + RateM3(3, 1) + RateM3(4, 1) + RateM3(5, 1) + RateM3(6, 1) + RateM3(7, 1) + RateM3(8, 1) + RateM3(9, 1) + RateM3(10, 1) + RateM3(11, 1) + RateM3(12, 1) + RateM3(13, 1) + RateM3(14, 1) + RateM3(15, 1) + RateM3(16, 1) + RateM3(17, 1) + RateM3(18, 1) + RateM3(19, 1)
            sumwiriM3(2) = RateM3(0, 2) + RateM3(1, 2) + RateM3(2, 2) + RateM3(3, 2) + RateM3(4, 2) + RateM3(5, 2) + RateM3(6, 2) + RateM3(7, 2) + RateM3(8, 2) + RateM3(9, 2) + RateM3(10, 2) + RateM3(11, 2) + RateM3(12, 2) + RateM3(13, 2) + RateM3(14, 2) + RateM3(15, 2) + RateM3(16, 2) + RateM3(17, 2) + RateM3(18, 2) + RateM3(19, 2)
            sumwiriM3(3) = RateM3(0, 3) + RateM3(1, 3) + RateM3(2, 3) + RateM3(3, 3) + RateM3(4, 3) + RateM3(5, 3) + RateM3(6, 3) + RateM3(7, 3) + RateM3(8, 3) + RateM3(9, 3) + RateM3(10, 3) + RateM3(11, 3) + RateM3(12, 3) + RateM3(13, 3) + RateM3(14, 3) + RateM3(15, 3) + RateM3(16, 3) + RateM3(17, 3) + RateM3(18, 3) + RateM3(19, 3)

            sumwiriM4(0) = RateM4(0, 0) + RateM4(1, 0) + RateM4(2, 0) + RateM4(3, 0) + RateM4(4, 0) + RateM4(5, 0) + RateM4(6, 0) + RateM4(7, 0) + RateM4(8, 0) + RateM4(9, 0) + RateM4(10, 0) + RateM4(11, 0) + RateM4(12, 0) + RateM4(13, 0) + RateM4(14, 0) + RateM4(15, 0) + RateM4(16, 0) + RateM4(17, 0) + RateM4(18, 0) + RateM4(19, 0)
            sumwiriM4(1) = RateM4(0, 1) + RateM4(1, 1) + RateM4(2, 1) + RateM4(3, 1) + RateM4(4, 1) + RateM4(5, 1) + RateM4(6, 1) + RateM4(7, 1) + RateM4(8, 1) + RateM4(9, 1) + RateM4(10, 1) + RateM4(11, 1) + RateM4(12, 1) + RateM4(13, 1) + RateM4(14, 1) + RateM4(15, 1) + RateM4(16, 1) + RateM4(17, 1) + RateM4(18, 1) + RateM4(19, 1)
            sumwiriM4(2) = RateM4(0, 2) + RateM4(1, 2) + RateM4(2, 2) + RateM4(3, 2) + RateM4(4, 2) + RateM4(5, 2) + RateM4(6, 2) + RateM4(7, 2) + RateM4(8, 2) + RateM4(9, 2) + RateM4(10, 2) + RateM4(11, 2) + RateM4(12, 2) + RateM4(13, 2) + RateM4(14, 2) + RateM4(15, 2) + RateM4(16, 2) + RateM4(17, 2) + RateM4(18, 2) + RateM4(19, 2)
            sumwiriM4(3) = RateM4(0, 3) + RateM4(1, 3) + RateM4(2, 3) + RateM4(3, 3) + RateM4(4, 3) + RateM4(5, 3) + RateM4(6, 3) + RateM4(7, 3) + RateM4(8, 3) + RateM4(9, 3) + RateM4(10, 3) + RateM4(11, 3) + RateM4(12, 3) + RateM4(13, 3) + RateM4(14, 3) + RateM4(15, 3) + RateM4(16, 3) + RateM4(17, 3) + RateM4(18, 3) + RateM4(19, 3)


            sumwiridivsumwM1(0) = sumwiriM1(0) / sumwsub(3)
            sumwiridivsumwM1(1) = sumwiriM1(1) / sumwsub(2)
            sumwiridivsumwM1(2) = sumwiriM1(2) / sumwsub(1)
            sumwiridivsumwM1(3) = sumwiriM1(3) / sumwsub(0)

            sumwiridivsumwM2(0) = sumwiriM2(0) / sumwsub(3)
            sumwiridivsumwM2(1) = sumwiriM2(1) / sumwsub(2)
            sumwiridivsumwM2(2) = sumwiriM2(2) / sumwsub(1)
            sumwiridivsumwM2(3) = sumwiriM2(3) / sumwsub(0)

            sumwiridivsumwM3(0) = sumwiriM3(0) / sumwsub(3)
            sumwiridivsumwM3(1) = sumwiriM3(1) / sumwsub(2)
            sumwiridivsumwM3(2) = sumwiriM3(2) / sumwsub(1)
            sumwiridivsumwM3(3) = sumwiriM3(3) / sumwsub(0)

            sumwiridivsumwM4(0) = sumwiriM4(0) / sumwsub(3)
            sumwiridivsumwM4(1) = sumwiriM4(1) / sumwsub(2)
            sumwiridivsumwM4(2) = sumwiriM4(2) / sumwsub(1)
            sumwiridivsumwM4(3) = sumwiriM4(3) / sumwsub(0)



            'Defuzzification 
            EQ1 = 2 - ((sumwiridivsumwM1(0) + sumwiridivsumwM1(1) + sumwiridivsumwM1(2) + sumwiridivsumwM1(3)) / 2)
            EQ2 = 2 - ((sumwiridivsumwM2(0) + sumwiridivsumwM2(1) + sumwiridivsumwM2(2) + sumwiridivsumwM2(3)) / 2)
            EQ3 = 2 - ((sumwiridivsumwM3(0) + sumwiridivsumwM3(1) + sumwiridivsumwM3(2) + sumwiridivsumwM3(3)) / 2)
            EQ4 = 2 - ((sumwiridivsumwM4(0) + sumwiridivsumwM4(1) + sumwiridivsumwM4(2) + sumwiridivsumwM4(3)) / 2)

            O4(0) = EQ1
            O4(1) = EQ2
            O4(2) = EQ3
            O4(3) = EQ4
            Array.Sort(O4)


            If O4(0) = EQ1 Then L1 = Label1.Text
            If O4(0) = EQ2 Then L1 = Label3.Text
            If O4(0) = EQ3 Then L1 = Label5.Text
            If O4(0) = EQ4 Then L1 = Label7.Text

            If O4(1) = EQ1 Then L2 = Label1.Text
            If O4(1) = EQ2 Then L2 = Label3.Text
            If O4(1) = EQ3 Then L2 = Label5.Text
            If O4(1) = EQ4 Then L2 = Label7.Text

            If O4(2) = EQ1 Then L3 = Label1.Text
            If O4(2) = EQ2 Then L3 = Label3.Text
            If O4(2) = EQ3 Then L3 = Label5.Text
            If O4(2) = EQ4 Then L3 = Label7.Text

            If O4(3) = EQ1 Then L4 = Label1.Text
            If O4(3) = EQ2 Then L4 = Label3.Text
            If O4(3) = EQ3 Then L4 = Label5.Text
            If O4(3) = EQ4 Then L4 = Label7.Text


            O4(0) = Math.Round(O4(0), 4)
            O4(1) = Math.Round(O4(1), 4)
            O4(2) = Math.Round(O4(2), 4)
            O4(3) = Math.Round(O4(3), 4)


            Form4.ListView1.Items(0).SubItems.Add(sumwiriM1(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM1(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM1(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM1(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwiriM2(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM2(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM2(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM2(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwiriM3(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM3(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM3(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM3(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwiriM4(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM4(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM4(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiriM4(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwsub(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwsub(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwsub(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwsub(3))


            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(3))

            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(0))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(1))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(2))
            Form4.ListView1.Items(0).SubItems.Add(sumwiridivsumwM4(3))

            Form4.ListView1.Items(0).SubItems.Add(EQ1)
            Form4.ListView1.Items(0).SubItems.Add(EQ2)
            Form4.ListView1.Items(0).SubItems.Add(EQ3)
            Form4.ListView1.Items(0).SubItems.Add(EQ4)

            Form4.Show()


            Form7.Chart1.Series.Add(L1)
            Form7.Chart1.Series(L1).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
            Form7.Chart1.Series(L1).Color = Color.Red
            Form7.Chart1.Series(L1).BorderWidth = 3
            If L1 = Label1.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L1 = Label3.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L1 = Label5.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L1 = Label7.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If

            Form7.Chart1.Series.Add(L2)
            Form7.Chart1.Series(L2).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L2).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDot
            Form7.Chart1.Series(L2).Color = Color.Blue
            Form7.Chart1.Series(L2).BorderWidth = 3
            If L2 = Label1.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L2 = Label3.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L2 = Label5.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L2 = Label7.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If


            Form7.Chart1.Series.Add(L3)
            Form7.Chart1.Series(L3).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L3).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDotDot
            Form7.Chart1.Series(L3).Color = Color.Green
            Form7.Chart1.Series(L3).BorderWidth = 3
            If L3 = Label1.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L3 = Label3.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L3 = Label5.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If
            If L3 = Label7.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If
            Form7.Chart1.Series.Add(L4)
            Form7.Chart1.Series(L4).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L4).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dot
            Form7.Chart1.Series(L4).Color = Color.Purple
            Form7.Chart1.Series(L4).BorderWidth = 3
            If L4 = Label1.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L4 = Label3.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L4 = Label5.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If

            If L4 = Label7.Text Then
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(0), 0)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(1), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(2), 1)
                Form7.Chart1.Series(L4).Points.AddXY(sumwiridivsumwM4(3), 0)
            End If



            Form7.Show()



            Form8.ListView1.Items.Add("1")
            Form8.ListView1.Items(0).SubItems.Add(L1)
            Form8.ListView1.Items(0).SubItems.Add(O4(0))
            Form8.ListView1.Items.Add("2")
            Form8.ListView1.Items(1).SubItems.Add(L2)
            Form8.ListView1.Items(1).SubItems.Add(O4(1))
            Form8.ListView1.Items.Add("3")
            Form8.ListView1.Items(2).SubItems.Add(L3)
            Form8.ListView1.Items(2).SubItems.Add(O4(2))
            Form8.ListView1.Items.Add("4")
            Form8.ListView1.Items(3).SubItems.Add(L4)
            Form8.ListView1.Items(3).SubItems.Add(O4(3))


            Form8.Chart1.Series.Add(L1)
            Form8.Chart1.BorderlineWidth = 3
            Form8.Chart1.Series(L1).Color = Form7.Chart1.Series(L1).Color
            Form8.Chart1.Series(L1).AxisLabel = L1
            Form8.Chart1.Series(L1).Points.AddXY(1, O4(0))
            Form8.Chart1.Series(L1).Label = O4(0)

            Form8.Chart1.Series.Add(L2)
            Form8.Chart1.Series(L2).Color = Form7.Chart1.Series(L2).Color
            Form8.Chart1.Series(L2).Points.AddXY(2, O4(1))
            Form8.Chart1.Series(L2).AxisLabel = L2
            Form8.Chart1.Series(L2).Label = O4(1)

            Form8.Chart1.Series.Add(L3)
            Form8.Chart1.Series(L3).Color = Form7.Chart1.Series(L3).Color
            Form8.Chart1.Series(L3).Points.AddXY(3, O4(2))
            Form8.Chart1.Series(L3).AxisLabel = L3
            Form8.Chart1.Series(L3).Label = O4(2)

            Form8.Chart1.Series.Add(L4)
            Form8.Chart1.Series(L4).Color = Form7.Chart1.Series(L4).Color
            Form8.Chart1.Series(L4).Points.AddXY(4, O4(3))
            Form8.Chart1.Series(L4).AxisLabel = L4
            Form8.Chart1.Series(L4).Label = O4(3)


        End If

        'rateM1, Rate M2,... RateM3 are IMPXRating of Material
        If MaterialSelection.CheckBox2.Enabled = True Then
            For i = 0 To 3
                sumwiriM1(i) = 0
                sumwiriM2(i) = 0
                sumwiriM3(i) = 0

            Next i
            EQ1 = 0
            EQ2 = 0
            EQ3 = 0

            O3(0) = 0
            O3(1) = 0
            O3(2) = 0

            For i = 0 To 19
                RateM1(i, 0) = IMP(i, 0) * RMAT1(i, 0)
                RateM1(i, 1) = IMP(i, 1) * RMAT1(i, 1)
                RateM1(i, 2) = IMP(i, 2) * RMAT1(i, 2)
                RateM1(i, 3) = IMP(i, 3) * RMAT1(i, 3)

                RateM2(i, 0) = IMP(i, 0) * RMAT2(i, 0)
                RateM2(i, 1) = IMP(i, 1) * RMAT2(i, 1)
                RateM2(i, 2) = IMP(i, 2) * RMAT2(i, 2)
                RateM2(i, 3) = IMP(i, 3) * RMAT2(i, 3)

                RateM3(i, 0) = IMP(i, 0) * RMAT3(i, 0)
                RateM3(i, 1) = IMP(i, 1) * RMAT3(i, 1)
                RateM3(i, 2) = IMP(i, 2) * RMAT3(i, 2)
                RateM3(i, 3) = IMP(i, 3) * RMAT3(i, 3)

                Form5.ListView1.Items.Add(i)
                Form5.ListView1.Items(i).SubItems.Add(IMP(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(IMP(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(IMP(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(IMP(i, 3))
                Form5.ListView1.Items(i).SubItems.Add(RMAT1(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(RMAT1(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(RMAT1(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(RMAT1(i, 3))
                Form5.ListView1.Items(i).SubItems.Add(RMAT2(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(RMAT2(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(RMAT2(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(RMAT2(i, 3))
                Form5.ListView1.Items(i).SubItems.Add(RMAT3(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(RMAT3(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(RMAT3(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(RMAT3(i, 3))
                Form5.ListView1.Items(i).SubItems.Add(RateM1(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(RateM1(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(RateM1(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(RateM1(i, 3))
                Form5.ListView1.Items(i).SubItems.Add(RateM2(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(RateM2(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(RateM2(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(RateM2(i, 3))
                Form5.ListView1.Items(i).SubItems.Add(RateM3(i, 0))
                Form5.ListView1.Items(i).SubItems.Add(RateM3(i, 1))
                Form5.ListView1.Items(i).SubItems.Add(RateM3(i, 2))
                Form5.ListView1.Items(i).SubItems.Add(RateM3(i, 3))

            Next i
            'For i = 0 To 3
            sumwiriM1(0) = RateM1(0, 0) + RateM1(1, 0) + RateM1(2, 0) + RateM1(3, 0) + RateM1(4, 0) + RateM1(5, 0) + RateM1(6, 0) + RateM1(7, 0) + RateM1(8, 0) + RateM1(9, 0) + RateM1(10, 0) + RateM1(11, 0) + RateM1(12, 0) + RateM1(13, 0) + RateM1(14, 0) + RateM1(15, 0) + RateM1(16, 0) + RateM1(17, 0) + RateM1(18, 0) + RateM1(19, 0)
            sumwiriM1(1) = RateM1(0, 1) + RateM1(1, 1) + RateM1(2, 1) + RateM1(3, 1) + RateM1(4, 1) + RateM1(5, 1) + RateM1(6, 1) + RateM1(7, 1) + RateM1(8, 1) + RateM1(9, 1) + RateM1(10, 1) + RateM1(11, 1) + RateM1(12, 1) + RateM1(13, 1) + RateM1(14, 1) + RateM1(15, 1) + RateM1(16, 1) + RateM1(17, 1) + RateM1(18, 1) + RateM1(19, 1)
            sumwiriM1(2) = RateM1(0, 2) + RateM1(1, 2) + RateM1(2, 2) + RateM1(3, 2) + RateM1(4, 2) + RateM1(5, 2) + RateM1(6, 2) + RateM1(7, 2) + RateM1(8, 2) + RateM1(9, 2) + RateM1(10, 2) + RateM1(11, 2) + RateM1(12, 2) + RateM1(13, 2) + RateM1(14, 2) + RateM1(15, 2) + RateM1(16, 2) + RateM1(17, 2) + RateM1(18, 2) + RateM1(19, 2)
            sumwiriM1(3) = RateM1(0, 3) + RateM1(1, 3) + RateM1(2, 3) + RateM1(3, 3) + RateM1(4, 3) + RateM1(5, 3) + RateM1(6, 3) + RateM1(7, 3) + RateM1(8, 3) + RateM1(9, 3) + RateM1(10, 3) + RateM1(11, 3) + RateM1(12, 3) + RateM1(13, 3) + RateM1(14, 3) + RateM1(15, 3) + RateM1(16, 3) + RateM1(17, 3) + RateM1(18, 3) + RateM1(19, 3)

            sumwiriM2(0) = RateM2(0, 0) + RateM2(1, 0) + RateM2(2, 0) + RateM2(3, 0) + RateM2(4, 0) + RateM2(5, 0) + RateM2(6, 0) + RateM2(7, 0) + RateM2(8, 0) + RateM2(9, 0) + RateM2(10, 0) + RateM2(11, 0) + RateM2(12, 0) + RateM2(13, 0) + RateM2(14, 0) + RateM2(15, 0) + RateM2(16, 0) + RateM2(17, 0) + RateM2(18, 0) + RateM2(19, 0)
            sumwiriM2(1) = RateM2(0, 1) + RateM2(1, 1) + RateM2(2, 1) + RateM2(3, 1) + RateM2(4, 1) + RateM2(5, 1) + RateM2(6, 1) + RateM2(7, 1) + RateM2(8, 1) + RateM2(9, 1) + RateM2(10, 1) + RateM2(11, 1) + RateM2(12, 1) + RateM2(13, 1) + RateM2(14, 1) + RateM2(15, 1) + RateM2(16, 1) + RateM2(17, 1) + RateM2(18, 1) + RateM2(19, 1)
            sumwiriM2(2) = RateM2(0, 2) + RateM2(1, 2) + RateM2(2, 2) + RateM2(3, 2) + RateM2(4, 2) + RateM2(5, 2) + RateM2(6, 2) + RateM2(7, 2) + RateM2(8, 2) + RateM2(9, 2) + RateM2(10, 2) + RateM2(11, 2) + RateM2(12, 2) + RateM2(13, 2) + RateM2(14, 2) + RateM2(15, 2) + RateM2(16, 2) + RateM2(17, 2) + RateM2(18, 2) + RateM2(19, 2)
            sumwiriM2(3) = RateM2(0, 3) + RateM2(1, 3) + RateM2(2, 3) + RateM2(3, 3) + RateM2(4, 3) + RateM2(5, 3) + RateM2(6, 3) + RateM2(7, 3) + RateM2(8, 3) + RateM2(9, 3) + RateM2(10, 3) + RateM2(11, 3) + RateM2(12, 3) + RateM2(13, 3) + RateM2(14, 3) + RateM2(15, 3) + RateM2(16, 3) + RateM2(17, 3) + RateM2(18, 3) + RateM2(19, 3)


            sumwiriM3(0) = RateM3(0, 0) + RateM3(1, 0) + RateM3(2, 0) + RateM3(3, 0) + RateM3(4, 0) + RateM3(5, 0) + RateM3(6, 0) + RateM3(7, 0) + RateM3(8, 0) + RateM3(9, 0) + RateM3(10, 0) + RateM3(11, 0) + RateM3(12, 0) + RateM3(13, 0) + RateM3(14, 0) + RateM3(15, 0) + RateM3(16, 0) + RateM3(17, 0) + RateM3(18, 0) + RateM3(19, 0)
            sumwiriM3(1) = RateM3(0, 1) + RateM3(1, 1) + RateM3(2, 1) + RateM3(3, 1) + RateM3(4, 1) + RateM3(5, 1) + RateM3(6, 1) + RateM3(7, 1) + RateM3(8, 1) + RateM3(9, 1) + RateM3(10, 1) + RateM3(11, 1) + RateM3(12, 1) + RateM3(13, 1) + RateM3(14, 1) + RateM3(15, 1) + RateM3(16, 1) + RateM3(17, 1) + RateM3(18, 1) + RateM3(19, 1)
            sumwiriM3(2) = RateM3(0, 2) + RateM3(1, 2) + RateM3(2, 2) + RateM3(3, 2) + RateM3(4, 2) + RateM3(5, 2) + RateM3(6, 2) + RateM3(7, 2) + RateM3(8, 2) + RateM3(9, 2) + RateM3(10, 2) + RateM3(11, 2) + RateM3(12, 2) + RateM3(13, 2) + RateM3(14, 2) + RateM3(15, 2) + RateM3(16, 2) + RateM3(17, 2) + RateM3(18, 2) + RateM3(19, 2)
            sumwiriM3(3) = RateM3(0, 3) + RateM3(1, 3) + RateM3(2, 3) + RateM3(3, 3) + RateM3(4, 3) + RateM3(5, 3) + RateM3(6, 3) + RateM3(7, 3) + RateM3(8, 3) + RateM3(9, 3) + RateM3(10, 3) + RateM3(11, 3) + RateM3(12, 3) + RateM3(13, 3) + RateM3(14, 3) + RateM3(15, 3) + RateM3(16, 3) + RateM3(17, 3) + RateM3(18, 3) + RateM3(19, 3)

            sumwiridivsumwM1(0) = sumwiriM1(0) / sumwsub(3)
            sumwiridivsumwM1(1) = sumwiriM1(1) / sumwsub(2)
            sumwiridivsumwM1(2) = sumwiriM1(2) / sumwsub(1)
            sumwiridivsumwM1(3) = sumwiriM1(3) / sumwsub(0)

            sumwiridivsumwM2(0) = sumwiriM2(0) / sumwsub(3)
            sumwiridivsumwM2(1) = sumwiriM2(1) / sumwsub(2)
            sumwiridivsumwM2(2) = sumwiriM2(2) / sumwsub(1)
            sumwiridivsumwM2(3) = sumwiriM2(3) / sumwsub(0)

            sumwiridivsumwM3(0) = sumwiriM3(0) / sumwsub(3)
            sumwiridivsumwM3(1) = sumwiriM3(1) / sumwsub(2)
            sumwiridivsumwM3(2) = sumwiriM3(2) / sumwsub(1)
            sumwiridivsumwM3(3) = sumwiriM3(3) / sumwsub(0)

            EQ1 = 2 - ((sumwiridivsumwM1(0) + sumwiridivsumwM1(1) + sumwiridivsumwM1(2) + sumwiridivsumwM1(3)) / 2)
            EQ2 = 2 - ((sumwiridivsumwM2(0) + sumwiridivsumwM2(1) + sumwiridivsumwM2(2) + sumwiridivsumwM2(3)) / 2)
            EQ3 = 2 - ((sumwiridivsumwM3(0) + sumwiridivsumwM3(1) + sumwiridivsumwM3(2) + sumwiridivsumwM3(3)) / 2)



            Form5.ListView1.Items(0).SubItems.Add(sumwiriM1(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM1(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM1(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM1(3))

            Form5.ListView1.Items(0).SubItems.Add(sumwiriM2(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM2(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM2(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM2(3))

            Form5.ListView1.Items(0).SubItems.Add(sumwiriM3(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM3(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM3(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwiriM3(3))


            Form5.ListView1.Items(0).SubItems.Add(sumwsub(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwsub(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwsub(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwsub(3))


            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(3))

            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(3))


            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(0))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(1))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(2))
            Form5.ListView1.Items(0).SubItems.Add(sumwiridivsumwM3(3))

            Form5.ListView1.Items(0).SubItems.Add(EQ1)
            Form5.ListView1.Items(0).SubItems.Add(EQ2)
            Form5.ListView1.Items(0).SubItems.Add(EQ3)

            Form5.Show()



            O3(0) = EQ1
            O3(1) = EQ2
            O3(2) = EQ3
            Array.Sort(O3)


            If O3(0) = EQ1 Then L1 = Label1.Text
            If O3(0) = EQ2 Then L1 = Label3.Text
            If O3(0) = EQ3 Then L1 = Label5.Text

            If O3(1) = EQ1 Then L2 = Label1.Text
            If O3(1) = EQ2 Then L2 = Label3.Text
            If O3(1) = EQ3 Then L2 = Label5.Text

            If O3(2) = EQ1 Then L3 = Label1.Text
            If O3(2) = EQ2 Then L3 = Label3.Text
            If O3(2) = EQ3 Then L3 = Label5.Text



            O3(0) = Math.Round(O3(0), 4)
            O3(1) = Math.Round(O3(1), 4)
            O3(2) = Math.Round(O3(2), 4)

            Form7.Chart1.Series.Add(L1)
            Form7.Chart1.Series(L1).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
            Form7.Chart1.Series(L1).Color = Color.Red
            Form7.Chart1.Series(L1).BorderWidth = 3
            If L1 = Label1.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L1 = Label3.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L1 = Label5.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If

            Form7.Chart1.Series.Add(L2)
            Form7.Chart1.Series(L2).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L2).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDot
            Form7.Chart1.Series(L2).Color = Color.Blue
            Form7.Chart1.Series(L2).BorderWidth = 3
            If L2 = Label1.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L2 = Label3.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L2 = Label5.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If


            Form7.Chart1.Series.Add(L3)
            Form7.Chart1.Series(L3).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L3).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDotDot
            Form7.Chart1.Series(L3).Color = Color.Green
            Form7.Chart1.Series(L3).BorderWidth = 3
            If L3 = Label1.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L3 = Label3.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If
            If L3 = Label5.Text Then
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(0), 0)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(1), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(2), 1)
                Form7.Chart1.Series(L3).Points.AddXY(sumwiridivsumwM3(3), 0)
            End If


            Form7.Show()



            Form8.ListView1.Items.Add("1")
            Form8.ListView1.Items(0).SubItems.Add(L1)
            Form8.ListView1.Items(0).SubItems.Add(O3(0))
            Form8.ListView1.Items.Add("2")
            Form8.ListView1.Items(1).SubItems.Add(L2)
            Form8.ListView1.Items(1).SubItems.Add(O3(1))
            Form8.ListView1.Items.Add("3")
            Form8.ListView1.Items(2).SubItems.Add(L3)
            Form8.ListView1.Items(2).SubItems.Add(O3(2))


            Form8.Chart1.Series.Add(L1)
            Form8.Chart1.BorderlineWidth = 3
            Form8.Chart1.Series(L1).Color = Form7.Chart1.Series(L1).Color
            Form8.Chart1.Series(L1).AxisLabel = L1
            Form8.Chart1.Series(L1).Points.AddXY(1, O3(0))
            Form8.Chart1.Series(L1).Label = O3(0)

            Form8.Chart1.Series.Add(L2)
            Form8.Chart1.Series(L2).Color = Form7.Chart1.Series(L2).Color
            Form8.Chart1.Series(L2).Points.AddXY(2, O3(1))
            Form8.Chart1.Series(L2).AxisLabel = L2
            Form8.Chart1.Series(L2).Label = O3(1)

            Form8.Chart1.Series.Add(L3)
            Form8.Chart1.Series(L3).Color = Form7.Chart1.Series(L3).Color
            Form8.Chart1.Series(L3).Points.AddXY(3, O3(2))
            Form8.Chart1.Series(L3).AxisLabel = L3
            Form8.Chart1.Series(L3).Label = O3(2)
        End If


        'rateM1, Rate M2 are IMPXRating of Material
        If MaterialSelection.CheckBox1.Enabled = True Then
            For i = 0 To 3
                sumwiriM1(i) = 0
                sumwiriM2(i) = 0

            Next i
            EQ1 = 0
            EQ2 = 0
            O2(0) = 0
            O2(1) = 0

            For i = 0 To 19
                RateM1(i, 0) = IMP(i, 0) * RMAT1(i, 0)
                RateM1(i, 1) = IMP(i, 1) * RMAT1(i, 1)
                RateM1(i, 2) = IMP(i, 2) * RMAT1(i, 2)
                RateM1(i, 3) = IMP(i, 3) * RMAT1(i, 3)

                RateM2(i, 0) = IMP(i, 0) * RMAT2(i, 0)
                RateM2(i, 1) = IMP(i, 1) * RMAT2(i, 1)
                RateM2(i, 2) = IMP(i, 2) * RMAT2(i, 2)
                RateM2(i, 3) = IMP(i, 3) * RMAT2(i, 3)

                Form6.ListView1.Items.Add(i)
                Form6.ListView1.Items(i).SubItems.Add(IMP(i, 0))
                Form6.ListView1.Items(i).SubItems.Add(IMP(i, 1))
                Form6.ListView1.Items(i).SubItems.Add(IMP(i, 2))
                Form6.ListView1.Items(i).SubItems.Add(IMP(i, 3))
                Form6.ListView1.Items(i).SubItems.Add(RMAT1(i, 0))
                Form6.ListView1.Items(i).SubItems.Add(RMAT1(i, 1))
                Form6.ListView1.Items(i).SubItems.Add(RMAT1(i, 2))
                Form6.ListView1.Items(i).SubItems.Add(RMAT1(i, 3))
                Form6.ListView1.Items(i).SubItems.Add(RMAT2(i, 0))
                Form6.ListView1.Items(i).SubItems.Add(RMAT2(i, 1))
                Form6.ListView1.Items(i).SubItems.Add(RMAT2(i, 2))
                Form6.ListView1.Items(i).SubItems.Add(RMAT2(i, 3))
                Form6.ListView1.Items(i).SubItems.Add(RateM1(i, 0))
                Form6.ListView1.Items(i).SubItems.Add(RateM1(i, 1))
                Form6.ListView1.Items(i).SubItems.Add(RateM1(i, 2))
                Form6.ListView1.Items(i).SubItems.Add(RateM1(i, 3))
                Form6.ListView1.Items(i).SubItems.Add(RateM2(i, 0))
                Form6.ListView1.Items(i).SubItems.Add(RateM2(i, 1))
                Form6.ListView1.Items(i).SubItems.Add(RateM2(i, 2))
                Form6.ListView1.Items(i).SubItems.Add(RateM2(i, 3))

            Next i
            'For i = 0 To 3
            sumwiriM1(0) = RateM1(0, 0) + RateM1(1, 0) + RateM1(2, 0) + RateM1(3, 0) + RateM1(4, 0) + RateM1(5, 0) + RateM1(6, 0) + RateM1(7, 0) + RateM1(8, 0) + RateM1(9, 0) + RateM1(10, 0) + RateM1(11, 0) + RateM1(12, 0) + RateM1(13, 0) + RateM1(14, 0) + RateM1(15, 0) + RateM1(16, 0) + RateM1(17, 0) + RateM1(18, 0) + RateM1(19, 0)
            sumwiriM1(1) = RateM1(0, 1) + RateM1(1, 1) + RateM1(2, 1) + RateM1(3, 1) + RateM1(4, 1) + RateM1(5, 1) + RateM1(6, 1) + RateM1(7, 1) + RateM1(8, 1) + RateM1(9, 1) + RateM1(10, 1) + RateM1(11, 1) + RateM1(12, 1) + RateM1(13, 1) + RateM1(14, 1) + RateM1(15, 1) + RateM1(16, 1) + RateM1(17, 1) + RateM1(18, 1) + RateM1(19, 1)
            sumwiriM1(2) = RateM1(0, 2) + RateM1(1, 2) + RateM1(2, 2) + RateM1(3, 2) + RateM1(4, 2) + RateM1(5, 2) + RateM1(6, 2) + RateM1(7, 2) + RateM1(8, 2) + RateM1(9, 2) + RateM1(10, 2) + RateM1(11, 2) + RateM1(12, 2) + RateM1(13, 2) + RateM1(14, 2) + RateM1(15, 2) + RateM1(16, 2) + RateM1(17, 2) + RateM1(18, 2) + RateM1(19, 2)
            sumwiriM1(3) = RateM1(0, 3) + RateM1(1, 3) + RateM1(2, 3) + RateM1(3, 3) + RateM1(4, 3) + RateM1(5, 3) + RateM1(6, 3) + RateM1(7, 3) + RateM1(8, 3) + RateM1(9, 3) + RateM1(10, 3) + RateM1(11, 3) + RateM1(12, 3) + RateM1(13, 3) + RateM1(14, 3) + RateM1(15, 3) + RateM1(16, 3) + RateM1(17, 3) + RateM1(18, 3) + RateM1(19, 3)

            sumwiriM2(0) = RateM2(0, 0) + RateM2(1, 0) + RateM2(2, 0) + RateM2(3, 0) + RateM2(4, 0) + RateM2(5, 0) + RateM2(6, 0) + RateM2(7, 0) + RateM2(8, 0) + RateM2(9, 0) + RateM2(10, 0) + RateM2(11, 0) + RateM2(12, 0) + RateM2(13, 0) + RateM2(14, 0) + RateM2(15, 0) + RateM2(16, 0) + RateM2(17, 0) + RateM2(18, 0) + RateM2(19, 0)
            sumwiriM2(1) = RateM2(0, 1) + RateM2(1, 1) + RateM2(2, 1) + RateM2(3, 1) + RateM2(4, 1) + RateM2(5, 1) + RateM2(6, 1) + RateM2(7, 1) + RateM2(8, 1) + RateM2(9, 1) + RateM2(10, 1) + RateM2(11, 1) + RateM2(12, 1) + RateM2(13, 1) + RateM2(14, 1) + RateM2(15, 1) + RateM2(16, 1) + RateM2(17, 1) + RateM2(18, 1) + RateM2(19, 1)
            sumwiriM2(2) = RateM2(0, 2) + RateM2(1, 2) + RateM2(2, 2) + RateM2(3, 2) + RateM2(4, 2) + RateM2(5, 2) + RateM2(6, 2) + RateM2(7, 2) + RateM2(8, 2) + RateM2(9, 2) + RateM2(10, 2) + RateM2(11, 2) + RateM2(12, 2) + RateM2(13, 2) + RateM2(14, 2) + RateM2(15, 2) + RateM2(16, 2) + RateM2(17, 2) + RateM2(18, 2) + RateM2(19, 2)
            sumwiriM2(3) = RateM2(0, 3) + RateM2(1, 3) + RateM2(2, 3) + RateM2(3, 3) + RateM2(4, 3) + RateM2(5, 3) + RateM2(6, 3) + RateM2(7, 3) + RateM2(8, 3) + RateM2(9, 3) + RateM2(10, 3) + RateM2(11, 3) + RateM2(12, 3) + RateM2(13, 3) + RateM2(14, 3) + RateM2(15, 3) + RateM2(16, 3) + RateM2(17, 3) + RateM2(18, 3) + RateM2(19, 3)



            sumwiridivsumwM1(0) = sumwiriM1(0) / sumwsub(3)
            sumwiridivsumwM1(1) = sumwiriM1(1) / sumwsub(2)
            sumwiridivsumwM1(2) = sumwiriM1(2) / sumwsub(1)
            sumwiridivsumwM1(3) = sumwiriM1(3) / sumwsub(0)

            sumwiridivsumwM2(0) = sumwiriM2(0) / sumwsub(3)
            sumwiridivsumwM2(1) = sumwiriM2(1) / sumwsub(2)
            sumwiridivsumwM2(2) = sumwiriM2(2) / sumwsub(1)
            sumwiridivsumwM2(3) = sumwiriM2(3) / sumwsub(0)

            EQ1 = 2 - ((sumwiridivsumwM1(0) + sumwiridivsumwM1(1) + sumwiridivsumwM1(2) + sumwiridivsumwM1(3)) / 2)
            EQ2 = 2 - ((sumwiridivsumwM2(0) + sumwiridivsumwM2(1) + sumwiridivsumwM2(2) + sumwiridivsumwM2(3)) / 2)


            Form6.ListView1.Items(0).SubItems.Add(sumwiriM1(0))
            Form6.ListView1.Items(0).SubItems.Add(sumwiriM1(1))
            Form6.ListView1.Items(0).SubItems.Add(sumwiriM1(2))
            Form6.ListView1.Items(0).SubItems.Add(sumwiriM1(3))

            Form6.ListView1.Items(0).SubItems.Add(sumwiriM2(0))
            Form6.ListView1.Items(0).SubItems.Add(sumwiriM2(1))
            Form6.ListView1.Items(0).SubItems.Add(sumwiriM2(2))
            Form6.ListView1.Items(0).SubItems.Add(sumwiriM2(3))


            Form6.ListView1.Items(0).SubItems.Add(sumwsub(0))
            Form6.ListView1.Items(0).SubItems.Add(sumwsub(1))
            Form6.ListView1.Items(0).SubItems.Add(sumwsub(2))
            Form6.ListView1.Items(0).SubItems.Add(sumwsub(3))


            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(0))
            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(1))
            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(2))
            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM1(3))

            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(0))
            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(1))
            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(2))
            Form6.ListView1.Items(0).SubItems.Add(sumwiridivsumwM2(3))

            Form6.ListView1.Items(0).SubItems.Add(EQ1)
            Form6.ListView1.Items(0).SubItems.Add(EQ2)

            Form6.Show()



            O2(0) = EQ1
            O2(1) = EQ2


            Array.Sort(O2)
            If O2(0) = EQ1 Then L1 = Label1.Text
            If O2(0) = EQ2 Then L1 = Label3.Text

            If O2(1) = EQ1 Then L2 = Label1.Text
            If O2(1) = EQ2 Then L2 = Label3.Text



            O2(0) = Math.Round(O2(0), 4)
            O2(1) = Math.Round(O2(1), 4)



            Form7.Chart1.Series.Add(L1)
            Form7.Chart1.Series(L1).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
            Form7.Chart1.Series(L1).Color = Color.Red
            Form7.Chart1.Series(L1).BorderWidth = 3
            If L1 = Label1.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L1 = Label3.Text Then
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L1).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If

            Form7.Chart1.Series.Add(L2)
            Form7.Chart1.Series(L2).ChartType = DataVisualization.Charting.SeriesChartType.Line
            Form7.Chart1.Series(L2).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.DashDot
            Form7.Chart1.Series(L2).Color = Color.Blue
            Form7.Chart1.Series(L2).BorderWidth = 3
            If L2 = Label1.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM1(3), 0)
            End If
            If L2 = Label3.Text Then
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(0), 0)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(1), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(2), 1)
                Form7.Chart1.Series(L2).Points.AddXY(sumwiridivsumwM2(3), 0)
            End If



            Form7.Show()



            Form8.ListView1.Items.Add("1")
            Form8.ListView1.Items(0).SubItems.Add(L1)
            Form8.ListView1.Items(0).SubItems.Add(O2(0))
            Form8.ListView1.Items.Add("2")
            Form8.ListView1.Items(1).SubItems.Add(L2)
            Form8.ListView1.Items(1).SubItems.Add(O2(1))


            Form8.Chart1.Series.Add(L1)
            Form8.Chart1.BorderlineWidth = 3
            Form8.Chart1.Series(L1).Color = Form7.Chart1.Series(L1).Color
            Form8.Chart1.Series(L1).AxisLabel = L1
            Form8.Chart1.Series(L1).Points.AddXY(1, O2(0))
            Form8.Chart1.Series(L1).Label = O2(0)

            Form8.Chart1.Series.Add(L2)
            Form8.Chart1.Series(L2).Color = Form7.Chart1.Series(L2).Color
            Form8.Chart1.Series(L2).Points.AddXY(2, O2(1))
            Form8.Chart1.Series(L2).AxisLabel = L2
            Form8.Chart1.Series(L2).Label = O2(1)


        End If



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label23_Click(sender As Object, e As EventArgs) Handles Label23.Click

    End Sub

    Private Sub M515_Scroll(sender As Object, e As EventArgs) Handles M515.Scroll
        If M515.Value = 0 Then
            Mat515.Text = "Very Bad"
        ElseIf M515.Value = 1 Then
            Mat515.Text = "Bad"
        ElseIf M515.Value = 2 Then
            Mat515.Text = "Fairly Bad"
        ElseIf M515.Value = 3 Then
            Mat515.Text = "Fair"
        ElseIf M515.Value = 4 Then
            Mat515.Text = "Fairly Good"
        ElseIf M515.Value = 5 Then
            Mat515.Text = "Good"
        ElseIf M515.Value = 6 Then
            Mat515.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M515.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M515.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M515.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M515.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M515.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M515.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M515.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(14, 0) = a
        RMAT5(14, 1) = b
        RMAT5(14, 2) = c
        RMAT5(14, 3) = d

    End Sub

    Private Sub M516_Scroll(sender As Object, e As EventArgs) Handles M516.Scroll
        If M516.Value = 0 Then
            Mat516.Text = "Very Bad"
        ElseIf M516.Value = 1 Then
            Mat516.Text = "Bad"
        ElseIf M516.Value = 2 Then
            Mat516.Text = "Fairly Bad"
        ElseIf M516.Value = 3 Then
            Mat516.Text = "Fair"
        ElseIf M516.Value = 4 Then
            Mat516.Text = "Fairly Good"
        ElseIf M516.Value = 5 Then
            Mat516.Text = "Good"
        ElseIf M516.Value = 6 Then
            Mat516.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M516.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M516.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M516.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M516.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M516.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M516.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M516.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(15, 0) = a
        RMAT5(15, 1) = b
        RMAT5(15, 2) = c
        RMAT5(15, 3) = d

    End Sub

    Private Sub M517_Scroll(sender As Object, e As EventArgs) Handles M517.Scroll
        If M517.Value = 0 Then
            Mat517.Text = "Very Bad"
        ElseIf M517.Value = 1 Then
            Mat517.Text = "Bad"
        ElseIf M517.Value = 2 Then
            Mat517.Text = "Fairly Bad"
        ElseIf M517.Value = 3 Then
            Mat517.Text = "Fair"
        ElseIf M517.Value = 4 Then
            Mat517.Text = "Fairly Good"
        ElseIf M517.Value = 5 Then
            Mat517.Text = "Good"
        ElseIf M517.Value = 6 Then
            Mat517.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M517.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M517.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M517.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M517.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M517.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M517.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M517.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(16, 0) = a
        RMAT5(16, 1) = b
        RMAT5(16, 2) = c
        RMAT5(16, 3) = d

    End Sub

    Private Sub M518_Scroll(sender As Object, e As EventArgs) Handles M518.Scroll
        If M518.Value = 0 Then
            Mat518.Text = "Very Bad"
        ElseIf M518.Value = 1 Then
            Mat518.Text = "Bad"
        ElseIf M518.Value = 2 Then
            Mat518.Text = "Fairly Bad"
        ElseIf M518.Value = 3 Then
            Mat518.Text = "Fair"
        ElseIf M518.Value = 4 Then
            Mat518.Text = "Fairly Good"
        ElseIf M518.Value = 5 Then
            Mat518.Text = "Good"
        ElseIf M518.Value = 6 Then
            Mat518.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M518.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M518.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M518.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M518.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M518.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M518.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M518.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(17, 0) = a
        RMAT5(17, 1) = b
        RMAT5(17, 2) = c
        RMAT5(17, 3) = d

    End Sub

    Private Sub M519_Scroll(sender As Object, e As EventArgs) Handles M519.Scroll
        If M519.Value = 0 Then
            Mat519.Text = "Very Bad"
        ElseIf M519.Value = 1 Then
            Mat519.Text = "Bad"
        ElseIf M519.Value = 2 Then
            Mat519.Text = "Fairly Bad"
        ElseIf M519.Value = 3 Then
            Mat519.Text = "Fair"
        ElseIf M519.Value = 4 Then
            Mat519.Text = "Fairly Good"
        ElseIf M519.Value = 5 Then
            Mat519.Text = "Good"
        ElseIf M519.Value = 6 Then
            Mat519.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M519.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M519.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M519.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M519.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M519.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M519.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M519.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(18, 0) = a
        RMAT5(18, 1) = b
        RMAT5(18, 2) = c
        RMAT5(18, 3) = d
    End Sub

    Private Sub M115_Scroll(sender As Object, e As EventArgs) Handles M115.Scroll
        If M115.Value = 0 Then
            Mat115.Text = "Very Bad"
        ElseIf M115.Value = 1 Then
            Mat115.Text = "Bad"
        ElseIf M115.Value = 2 Then
            Mat115.Text = "Fairly Bad"
        ElseIf M115.Value = 3 Then
            Mat115.Text = "Fair"
        ElseIf M115.Value = 4 Then
            Mat115.Text = "Fairly Good"
        ElseIf M115.Value = 5 Then
            Mat115.Text = "Good"
        ElseIf M115.Value = 6 Then
            Mat115.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M115.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M115.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M115.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M115.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M115.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M115.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M115.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(14, 0) = a
        RMAT1(14, 1) = b
        RMAT1(14, 2) = c
        RMAT1(14, 3) = d

    End Sub

    Private Sub M116_Scroll(sender As Object, e As EventArgs) Handles M116.Scroll
        If M116.Value = 0 Then
            Mat116.Text = "Very Bad"
        ElseIf M116.Value = 1 Then
            Mat116.Text = "Bad"
        ElseIf M116.Value = 2 Then
            Mat116.Text = "Fairly Bad"
        ElseIf M116.Value = 3 Then
            Mat116.Text = "Fair"
        ElseIf M116.Value = 4 Then
            Mat116.Text = "Fairly Good"
        ElseIf M116.Value = 5 Then
            Mat116.Text = "Good"
        ElseIf M116.Value = 6 Then
            Mat116.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M116.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M116.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M116.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M116.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M116.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M116.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M116.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(15, 0) = a
        RMAT1(15, 1) = b
        RMAT1(15, 2) = c
        RMAT1(15, 3) = d

    End Sub

    Private Sub M117_Scroll(sender As Object, e As EventArgs) Handles M117.Scroll
        If M117.Value = 0 Then
            Mat117.Text = "Very Bad"
        ElseIf M117.Value = 1 Then
            Mat117.Text = "Bad"
        ElseIf M117.Value = 2 Then
            Mat117.Text = "Fairly Bad"
        ElseIf M117.Value = 3 Then
            Mat117.Text = "Fair"
        ElseIf M117.Value = 4 Then
            Mat117.Text = "Fairly Good"
        ElseIf M117.Value = 5 Then
            Mat117.Text = "Good"
        ElseIf M117.Value = 6 Then
            Mat117.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M117.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M117.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M117.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M117.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M117.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M117.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M117.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(16, 0) = a
        RMAT1(16, 1) = b
        RMAT1(16, 2) = c
        RMAT1(16, 3) = d

    End Sub

    Private Sub M118_Scroll(sender As Object, e As EventArgs) Handles M118.Scroll
        If M118.Value = 0 Then
            Mat118.Text = "Very Bad"
        ElseIf M118.Value = 1 Then
            Mat118.Text = "Bad"
        ElseIf M118.Value = 2 Then
            Mat118.Text = "Fairly Bad"
        ElseIf M118.Value = 3 Then
            Mat118.Text = "Fair"
        ElseIf M118.Value = 4 Then
            Mat118.Text = "Fairly Good"
        ElseIf M118.Value = 5 Then
            Mat118.Text = "Good"
        ElseIf M118.Value = 6 Then
            Mat118.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M118.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M118.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M118.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M118.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M118.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M118.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M118.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(17, 0) = a
        RMAT1(17, 1) = b
        RMAT1(17, 2) = c
        RMAT1(17, 3) = d

    End Sub

    Private Sub M119_Scroll(sender As Object, e As EventArgs) Handles M119.Scroll
        If M119.Value = 0 Then
            Mat119.Text = "Very Bad"
        ElseIf M119.Value = 1 Then
            Mat119.Text = "Bad"
        ElseIf M119.Value = 2 Then
            Mat119.Text = "Fairly Bad"
        ElseIf M119.Value = 3 Then
            Mat119.Text = "Fair"
        ElseIf M119.Value = 4 Then
            Mat119.Text = "Fairly Good"
        ElseIf M119.Value = 5 Then
            Mat119.Text = "Good"
        ElseIf M119.Value = 6 Then
            Mat119.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M119.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M119.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M119.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M119.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M119.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M119.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M119.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(18, 0) = a
        RMAT1(18, 1) = b
        RMAT1(18, 2) = c
        RMAT1(18, 3) = d

    End Sub

    Private Sub M215_Scroll(sender As Object, e As EventArgs) Handles M215.Scroll
        If M215.Value = 0 Then
            Mat215.Text = "Very Bad"
        ElseIf M215.Value = 1 Then
            Mat215.Text = "Bad"
        ElseIf M215.Value = 2 Then
            Mat215.Text = "Fairly Bad"
        ElseIf M215.Value = 3 Then
            Mat215.Text = "Fair"
        ElseIf M215.Value = 4 Then
            Mat215.Text = "Fairly Good"
        ElseIf M215.Value = 5 Then
            Mat215.Text = "Good"
        ElseIf M215.Value = 6 Then
            Mat215.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M215.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M215.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M215.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M215.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M215.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M215.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M215.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(14, 0) = a
        RMAT2(14, 1) = b
        RMAT2(14, 2) = c
        RMAT2(14, 3) = d
    End Sub

    Private Sub M216_Scroll(sender As Object, e As EventArgs) Handles M216.Scroll
        If M216.Value = 0 Then
            Mat216.Text = "Very Bad"
        ElseIf M216.Value = 1 Then
            Mat216.Text = "Bad"
        ElseIf M216.Value = 2 Then
            Mat216.Text = "Fairly Bad"
        ElseIf M216.Value = 3 Then
            Mat216.Text = "Fair"
        ElseIf M216.Value = 4 Then
            Mat216.Text = "Fairly Good"
        ElseIf M216.Value = 5 Then
            Mat216.Text = "Good"
        ElseIf M216.Value = 6 Then
            Mat216.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M216.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M216.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M216.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M216.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M216.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M216.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M216.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(15, 0) = a
        RMAT2(15, 1) = b
        RMAT2(15, 2) = c
        RMAT2(15, 3) = d
    End Sub

    Private Sub M217_Scroll(sender As Object, e As EventArgs) Handles M217.Scroll
        If M217.Value = 0 Then
            Mat217.Text = "Very Bad"
        ElseIf M217.Value = 1 Then
            Mat217.Text = "Bad"
        ElseIf M217.Value = 2 Then
            Mat217.Text = "Fairly Bad"
        ElseIf M217.Value = 3 Then
            Mat217.Text = "Fair"
        ElseIf M217.Value = 4 Then
            Mat217.Text = "Fairly Good"
        ElseIf M217.Value = 5 Then
            Mat217.Text = "Good"
        ElseIf M217.Value = 6 Then
            Mat217.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M217.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M217.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M217.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M217.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M217.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M217.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M217.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(16, 0) = a
        RMAT2(16, 1) = b
        RMAT2(16, 2) = c
        RMAT2(16, 3) = d
    End Sub

    Private Sub M218_Scroll(sender As Object, e As EventArgs) Handles M218.Scroll
        If M218.Value = 0 Then
            Mat218.Text = "Very Bad"
        ElseIf M218.Value = 1 Then
            Mat218.Text = "Bad"
        ElseIf M218.Value = 2 Then
            Mat218.Text = "Fairly Bad"
        ElseIf M218.Value = 3 Then
            Mat218.Text = "Fair"
        ElseIf M218.Value = 4 Then
            Mat218.Text = "Fairly Good"
        ElseIf M218.Value = 5 Then
            Mat218.Text = "Good"
        ElseIf M218.Value = 6 Then
            Mat218.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M218.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M218.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M218.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M218.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M218.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M218.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M218.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(17, 0) = a
        RMAT2(17, 1) = b
        RMAT2(17, 2) = c
        RMAT2(17, 3) = d
    End Sub

    Private Sub M220_Scroll(sender As Object, e As EventArgs) Handles M220.Scroll
        If M220.Value = 0 Then
            Mat220.Text = "Very Bad"
        ElseIf M220.Value = 1 Then
            Mat220.Text = "Bad"
        ElseIf M220.Value = 2 Then
            Mat220.Text = "Fairly Bad"
        ElseIf M220.Value = 3 Then
            Mat220.Text = "Fair"
        ElseIf M220.Value = 4 Then
            Mat220.Text = "Fairly Good"
        ElseIf M220.Value = 5 Then
            Mat220.Text = "Good"
        ElseIf M220.Value = 6 Then
            Mat220.Text = "Very Good"
        End If

        Dim a, b, c, d As Double
        If M220.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M220.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M220.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M220.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M220.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M220.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M220.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(19, 0) = a
        RMAT2(19, 1) = b
        RMAT2(19, 2) = c
        RMAT2(19, 3) = d
    End Sub

    Private Sub M315_Scroll(sender As Object, e As EventArgs) Handles M315.Scroll
        If M315.Value = 0 Then
            Mat315.Text = "Very Bad"
        ElseIf M315.Value = 1 Then
            Mat315.Text = "Bad"
        ElseIf M315.Value = 2 Then
            Mat315.Text = "Fairly Bad"
        ElseIf M315.Value = 3 Then
            Mat315.Text = "Fair"
        ElseIf M315.Value = 4 Then
            Mat315.Text = "Fairly Good"
        ElseIf M315.Value = 5 Then
            Mat315.Text = "Good"
        ElseIf M315.Value = 6 Then
            Mat315.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M315.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M315.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M315.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M315.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M315.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M315.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M315.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(14, 0) = a
        RMAT3(14, 1) = b
        RMAT3(14, 2) = c
        RMAT3(14, 3) = d

    End Sub

    Private Sub M316_Scroll(sender As Object, e As EventArgs) Handles M316.Scroll
        If M316.Value = 0 Then
            Mat316.Text = "Very Bad"
        ElseIf M316.Value = 1 Then
            Mat316.Text = "Bad"
        ElseIf M316.Value = 2 Then
            Mat316.Text = "Fairly Bad"
        ElseIf M316.Value = 3 Then
            Mat316.Text = "Fair"
        ElseIf M316.Value = 4 Then
            Mat316.Text = "Fairly Good"
        ElseIf M316.Value = 5 Then
            Mat316.Text = "Good"
        ElseIf M316.Value = 6 Then
            Mat316.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M316.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M316.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M316.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M316.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M316.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M316.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M316.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(15, 0) = a
        RMAT3(15, 1) = b
        RMAT3(15, 2) = c
        RMAT3(15, 3) = d
    End Sub

    Private Sub M317_Scroll(sender As Object, e As EventArgs) Handles M317.Scroll
        If M317.Value = 0 Then
            Mat317.Text = "Very Bad"
        ElseIf M317.Value = 1 Then
            Mat317.Text = "Bad"
        ElseIf M317.Value = 2 Then
            Mat317.Text = "Fairly Bad"
        ElseIf M317.Value = 3 Then
            Mat317.Text = "Fair"
        ElseIf M317.Value = 4 Then
            Mat317.Text = "Fairly Good"
        ElseIf M317.Value = 5 Then
            Mat317.Text = "Good"
        ElseIf M317.Value = 6 Then
            Mat317.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M317.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M317.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M317.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M317.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M317.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M317.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M317.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(16, 0) = a
        RMAT3(16, 1) = b
        RMAT3(16, 2) = c
        RMAT3(16, 3) = d
    End Sub

    Private Sub M318_Scroll(sender As Object, e As EventArgs) Handles M318.Scroll
        If M318.Value = 0 Then
            Mat318.Text = "Very Bad"
        ElseIf M318.Value = 1 Then
            Mat318.Text = "Bad"
        ElseIf M318.Value = 2 Then
            Mat318.Text = "Fairly Bad"
        ElseIf M318.Value = 3 Then
            Mat318.Text = "Fair"
        ElseIf M318.Value = 4 Then
            Mat318.Text = "Fairly Good"
        ElseIf M318.Value = 5 Then
            Mat318.Text = "Good"
        ElseIf M318.Value = 6 Then
            Mat318.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M318.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M318.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M318.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M318.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M318.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M318.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M318.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(17, 0) = a
        RMAT3(17, 1) = b
        RMAT3(17, 2) = c
        RMAT3(17, 3) = d
    End Sub

    Private Sub M319_Scroll(sender As Object, e As EventArgs) Handles M319.Scroll
        If M319.Value = 0 Then
            Mat319.Text = "Very Bad"
        ElseIf M319.Value = 1 Then
            Mat319.Text = "Bad"
        ElseIf M319.Value = 2 Then
            Mat319.Text = "Fairly Bad"
        ElseIf M319.Value = 3 Then
            Mat319.Text = "Fair"
        ElseIf M319.Value = 4 Then
            Mat319.Text = "Fairly Good"
        ElseIf M319.Value = 5 Then
            Mat319.Text = "Good"
        ElseIf M319.Value = 6 Then
            Mat319.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M319.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M319.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M319.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M319.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M319.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M319.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M319.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(18, 0) = a
        RMAT3(18, 1) = b
        RMAT3(18, 2) = c
        RMAT3(18, 3) = d
    End Sub

    Private Sub M415_Scroll(sender As Object, e As EventArgs) Handles M415.Scroll
        If M415.Value = 0 Then
            Mat415.Text = "Very Bad"
        ElseIf M415.Value = 1 Then
            Mat415.Text = "Bad"
        ElseIf M415.Value = 2 Then
            Mat415.Text = "Fairly Bad"
        ElseIf M415.Value = 3 Then
            Mat415.Text = "Fair"
        ElseIf M415.Value = 4 Then
            Mat415.Text = "Fairly Good"
        ElseIf M415.Value = 5 Then
            Mat415.Text = "Good"
        ElseIf M415.Value = 6 Then
            Mat415.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M415.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M415.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M415.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M415.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M415.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M415.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M415.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(14, 0) = a
        RMAT4(14, 1) = b
        RMAT4(14, 2) = c
        RMAT4(14, 3) = d
    End Sub

    Private Sub M416_Scroll(sender As Object, e As EventArgs) Handles M416.Scroll
        If M416.Value = 0 Then
            Mat416.Text = "Very Bad"
        ElseIf M416.Value = 1 Then
            Mat416.Text = "Bad"
        ElseIf M416.Value = 2 Then
            Mat416.Text = "Fairly Bad"
        ElseIf M416.Value = 3 Then
            Mat416.Text = "Fair"
        ElseIf M416.Value = 4 Then
            Mat416.Text = "Fairly Good"
        ElseIf M416.Value = 5 Then
            Mat416.Text = "Good"
        ElseIf M416.Value = 6 Then
            Mat416.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M416.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M416.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M416.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M416.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M416.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M416.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M416.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(15, 0) = a
        RMAT4(15, 1) = b
        RMAT4(15, 2) = c
        RMAT4(15, 3) = d
    End Sub

    Private Sub M417_Scroll(sender As Object, e As EventArgs) Handles M417.Scroll
        If M417.Value = 0 Then
            Mat417.Text = "Very Bad"
        ElseIf M417.Value = 1 Then
            Mat417.Text = "Bad"
        ElseIf M417.Value = 2 Then
            Mat417.Text = "Fairly Bad"
        ElseIf M417.Value = 3 Then
            Mat417.Text = "Fair"
        ElseIf M417.Value = 4 Then
            Mat417.Text = "Fairly Good"
        ElseIf M417.Value = 5 Then
            Mat417.Text = "Good"
        ElseIf M417.Value = 6 Then
            Mat417.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M417.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M417.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M417.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M417.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M417.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M417.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M417.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(16, 0) = a
        RMAT4(16, 1) = b
        RMAT4(16, 2) = c
        RMAT4(16, 3) = d
    End Sub

    Private Sub M418_Scroll(sender As Object, e As EventArgs) Handles M418.Scroll
        If M418.Value = 0 Then
            Mat418.Text = "Very Bad"
        ElseIf M418.Value = 1 Then
            Mat418.Text = "Bad"
        ElseIf M418.Value = 2 Then
            Mat418.Text = "Fairly Bad"
        ElseIf M418.Value = 3 Then
            Mat418.Text = "Fair"
        ElseIf M418.Value = 4 Then
            Mat418.Text = "Fairly Good"
        ElseIf M418.Value = 5 Then
            Mat418.Text = "Good"
        ElseIf M418.Value = 6 Then
            Mat418.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M418.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M418.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M418.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M418.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M418.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M418.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M418.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(17, 0) = a
        RMAT4(17, 1) = b
        RMAT4(17, 2) = c
        RMAT4(17, 3) = d
    End Sub

    Private Sub M419_Scroll(sender As Object, e As EventArgs) Handles M419.Scroll
        If M419.Value = 0 Then
            Mat419.Text = "Very Bad"
        ElseIf M419.Value = 1 Then
            Mat419.Text = "Bad"
        ElseIf M419.Value = 2 Then
            Mat419.Text = "Fairly Bad"
        ElseIf M419.Value = 3 Then
            Mat419.Text = "Fair"
        ElseIf M419.Value = 4 Then
            Mat419.Text = "Fairly Good"
        ElseIf M419.Value = 5 Then
            Mat419.Text = "Good"
        ElseIf M419.Value = 6 Then
            Mat419.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M419.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M419.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M419.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M419.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M419.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M419.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M419.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(18, 0) = a
        RMAT4(18, 1) = b
        RMAT4(18, 2) = c
        RMAT4(18, 3) = d
    End Sub

    Private Sub Mat219_Click(sender As Object, e As EventArgs) Handles Mat219.Click

    End Sub

    Private Sub M120_Scroll(sender As Object, e As EventArgs) Handles M120.Scroll
        If M120.Value = 0 Then
            Mat120.Text = "Very Bad"
        ElseIf M120.Value = 1 Then
            Mat120.Text = "Bad"
        ElseIf M120.Value = 2 Then
            Mat120.Text = "Fairly Bad"
        ElseIf M120.Value = 3 Then
            Mat120.Text = "Fair"
        ElseIf M120.Value = 4 Then
            Mat120.Text = "Fairly Good"
        ElseIf M120.Value = 5 Then
            Mat120.Text = "Good"
        ElseIf M120.Value = 6 Then
            Mat120.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M120.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M120.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M120.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M120.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M120.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M120.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M120.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT1(19, 0) = a
        RMAT1(19, 1) = b
        RMAT1(19, 2) = c
        RMAT1(19, 3) = d

    End Sub

    Private Sub M320_Scroll(sender As Object, e As EventArgs) Handles M320.Scroll
        If M320.Value = 0 Then
            Mat320.Text = "Very Bad"
        ElseIf M320.Value = 1 Then
            Mat320.Text = "Bad"
        ElseIf M320.Value = 2 Then
            Mat320.Text = "Fairly Bad"
        ElseIf M320.Value = 3 Then
            Mat320.Text = "Fair"
        ElseIf M320.Value = 4 Then
            Mat320.Text = "Fairly Good"
        ElseIf M320.Value = 5 Then
            Mat320.Text = "Good"
        ElseIf M320.Value = 6 Then
            Mat320.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M320.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M320.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M320.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M320.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M320.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M320.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M320.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT3(19, 0) = a
        RMAT3(19, 1) = b
        RMAT3(19, 2) = c
        RMAT3(19, 3) = d
    End Sub

    Private Sub M420_Scroll(sender As Object, e As EventArgs) Handles M420.Scroll
        If M420.Value = 0 Then
            Mat420.Text = "Very Bad"
        ElseIf M420.Value = 1 Then
            Mat420.Text = "Bad"
        ElseIf M420.Value = 2 Then
            Mat420.Text = "Fairly Bad"
        ElseIf M420.Value = 3 Then
            Mat420.Text = "Fair"
        ElseIf M420.Value = 4 Then
            Mat420.Text = "Fairly Good"
        ElseIf M420.Value = 5 Then
            Mat420.Text = "Good"
        ElseIf M420.Value = 6 Then
            Mat420.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M420.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M420.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M420.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M420.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M420.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M420.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M420.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT4(19, 0) = a
        RMAT4(19, 1) = b
        RMAT4(19, 2) = c
        RMAT4(19, 3) = d
    End Sub

    Private Sub M520_Scroll(sender As Object, e As EventArgs) Handles M520.Scroll
        If M520.Value = 0 Then
            Mat520.Text = "Very Bad"
        ElseIf M520.Value = 1 Then
            Mat520.Text = "Bad"
        ElseIf M520.Value = 2 Then
            Mat520.Text = "Fairly Bad"
        ElseIf M520.Value = 3 Then
            Mat520.Text = "Fair"
        ElseIf M520.Value = 4 Then
            Mat520.Text = "Fairly Good"
        ElseIf M520.Value = 5 Then
            Mat520.Text = "Good"
        ElseIf M520.Value = 6 Then
            Mat520.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M520.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M520.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M520.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M520.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M520.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M520.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M520.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT5(19, 0) = a
        RMAT5(19, 1) = b
        RMAT5(19, 2) = c
        RMAT5(19, 3) = d
    End Sub

    Private Sub Label25_Click(sender As Object, e As EventArgs) Handles Label25.Click

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If MaterialSelection.CheckBox4.Enabled = True Then
            Dim ExcelObj As Object
            Dim ExcelBook As Object
            Dim ExcelSheet As Object
            Dim n As Integer

            ExcelObj = CreateObject("Excel.Application")
            ExcelBook = ExcelObj.WorkBooks.Add
            ExcelSheet = ExcelBook.WorkSheets(1)

            With ExcelSheet
                For n = 0 To 19
                    .cells(n + 1, 1) = IMP(n, 0)
                    .cells(n + 1, 2) = IMP(n, 1)
                    .cells(n + 1, 3) = IMP(n, 2)
                    .cells(n + 1, 4) = IMP(n, 3)
                    .cells(n + 1, 5) = RMAT1(n, 0)
                    .cells(n + 1, 6) = RMAT1(n, 1)
                    .cells(n + 1, 7) = RMAT1(n, 2)
                    .cells(n + 1, 8) = RMAT1(n, 3)
                    .cells(n + 1, 9) = RMAT2(n, 0)
                    .cells(n + 1, 10) = RMAT2(n, 1)
                    .cells(n + 1, 11) = RMAT2(n, 2)
                    .cells(n + 1, 12) = RMAT2(n, 3)
                    .cells(n + 1, 13) = RMAT3(n, 0)
                    .cells(n + 1, 14) = RMAT3(n, 1)
                    .cells(n + 1, 15) = RMAT3(n, 2)
                    .cells(n + 1, 16) = RMAT3(n, 3)
                    .cells(n + 1, 17) = RMAT4(n, 0)
                    .cells(n + 1, 18) = RMAT4(n, 1)
                    .cells(n + 1, 19) = RMAT4(n, 2)
                    .cells(n + 1, 20) = RMAT4(n, 3)
                    .cells(n + 1, 21) = RMAT5(n, 0)
                    .cells(n + 1, 22) = RMAT5(n, 1)
                    .cells(n + 1, 23) = RMAT5(n, 2)
                    .cells(n + 1, 24) = RMAT5(n, 3)
                    .cells(n + 1, 25) = RateM1(n, 0)
                    .cells(n + 1, 26) = RateM1(n, 1)
                    .cells(n + 1, 27) = RateM1(n, 2)
                    .cells(n + 1, 28) = RateM1(n, 3)
                    .cells(n + 1, 29) = RateM2(n, 0)
                    .cells(n + 1, 30) = RateM2(n, 1)
                    .cells(n + 1, 31) = RateM2(n, 2)
                    .cells(n + 1, 32) = RateM2(n, 3)
                    .cells(n + 1, 33) = RateM3(n, 0)
                    .cells(n + 1, 34) = RateM3(n, 1)
                    .cells(n + 1, 35) = RateM3(n, 2)
                    .cells(n + 1, 36) = RateM3(n, 3)
                    .cells(n + 1, 37) = RateM4(n, 0)
                    .cells(n + 1, 38) = RateM4(n, 1)
                    .cells(n + 1, 39) = RateM4(n, 2)
                    .cells(n + 1, 40) = RateM4(n, 3)
                    .cells(n + 1, 41) = RateM5(n, 0)
                    .cells(n + 1, 42) = RateM5(n, 1)
                    .cells(n + 1, 43) = RateM5(n, 2)
                    .cells(n + 1, 44) = RateM5(n, 3)

                Next n


                .cells(1, 45) = (sumwiriM1(0))
                .cells(1, 46) = (sumwiriM1(1))
                .cells(1, 47) = (sumwiriM1(2))
                .cells(1, 48) = (sumwiriM1(3))

                .cells(1, 49) = (sumwiriM2(0))
                .cells(1, 50) = (sumwiriM2(1))
                .cells(1, 51) = (sumwiriM2(2))
                .cells(1, 52) = (sumwiriM2(3))

                .cells(1, 53) = (sumwiriM3(0))
                .cells(1, 54) = (sumwiriM3(1))
                .cells(1, 55) = (sumwiriM3(2))
                .cells(1, 56) = (sumwiriM3(3))

                .cells(1, 57) = (sumwiriM4(0))
                .cells(1, 58) = (sumwiriM4(1))
                .cells(1, 59) = (sumwiriM4(2))
                .cells(1, 60) = (sumwiriM4(3))

                .cells(1, 61) = (sumwiriM5(0))
                .cells(1, 62) = (sumwiriM5(1))
                .cells(1, 63) = (sumwiriM5(2))
                .cells(1, 64) = (sumwiriM5(3))


                .cells(1, 65) = (sumwsub(0))
                .cells(1, 66) = (sumwsub(1))
                .cells(1, 67) = (sumwsub(2))
                .cells(1, 68) = (sumwsub(3))


                .cells(1, 69) = (sumwiridivsumwM1(0))
                .cells(1, 70) = (sumwiridivsumwM1(1))
                .cells(1, 71) = (sumwiridivsumwM1(2))
                .cells(1, 72) = (sumwiridivsumwM1(3))

                .cells(1, 73) = (sumwiridivsumwM2(0))
                .cells(1, 74) = (sumwiridivsumwM2(1))
                .cells(1, 75) = (sumwiridivsumwM2(2))
                .cells(1, 76) = (sumwiridivsumwM2(3))


                .cells(1, 77) = (sumwiridivsumwM3(0))
                .cells(1, 78) = (sumwiridivsumwM3(1))
                .cells(1, 79) = (sumwiridivsumwM3(2))
                .cells(1, 80) = (sumwiridivsumwM3(3))

                .cells(1, 81) = (sumwiridivsumwM4(0))
                .cells(1, 82) = (sumwiridivsumwM4(1))
                .cells(1, 83) = (sumwiridivsumwM4(2))
                .cells(1, 84) = (sumwiridivsumwM4(3))

                .cells(1, 85) = (sumwiridivsumwM5(0))
                .cells(1, 86) = (sumwiridivsumwM5(1))
                .cells(1, 87) = (sumwiridivsumwM5(2))
                .cells(1, 88) = (sumwiridivsumwM5(3))

                .cells(1, 89) = EQ1
                .cells(1, 90) = EQ2
                .cells(1, 91) = EQ3
                .cells(1, 92) = EQ4
                .cells(1, 93) = EQ5

            End With

            ExcelObj.Visible = True
            ExcelSheet = Nothing
            ExcelBook = Nothing
            ExcelObj = Nothing
        End If
        If MaterialSelection.CheckBox3.Enabled = True Then
            Dim ExcelObj As Object
            Dim ExcelBook As Object
            Dim ExcelSheet As Object
            Dim v As Integer

            ExcelObj = CreateObject("Excel.Application")
            ExcelBook = ExcelObj.WorkBooks.Add
            ExcelSheet = ExcelBook.WorkSheets(1)

            With ExcelSheet
                For v = 0 To 19
                    .cells(v + 1, 1) = (IMP(v, 0))
                    .cells(v + 1, 2) = (IMP(v, 1))
                    .cells(v + 1, 3) = (IMP(v, 2))
                    .cells(v + 1, 4) = (IMP(v, 3))
                    .cells(v + 1, 5) = (RMAT1(v, 0))
                    .cells(v + 1, 6) = (RMAT1(v, 1))
                    .cells(v + 1, 7) = (RMAT1(v, 2))
                    .cells(v + 1, 8) = (RMAT1(v, 3))
                    .cells(v + 1, 9) = (RMAT2(v, 0))
                    .cells(v + 1, 10) = (RMAT2(v, 1))
                    .cells(v + 1, 11) = (RMAT2(v, 2))
                    .cells(v + 1, 12) = (RMAT2(v, 3))
                    .cells(v + 1, 13) = (RMAT3(v, 0))
                    .cells(v + 1, 14) = (RMAT3(v, 1))
                    .cells(v + 1, 15) = (RMAT3(v, 2))
                    .cells(v + 1, 16) = (RMAT3(v, 3))
                    .cells(v + 1, 17) = (RMAT4(v, 0))
                    .cells(v + 1, 18) = (RMAT4(v, 1))
                    .cells(v + 1, 19) = (RMAT4(v, 2))
                    .cells(v + 1, 20) = (RMAT4(v, 3))
                    .cells(v + 1, 21) = (RateM1(v, 0))
                    .cells(v + 1, 22) = (RateM1(v, 1))
                    .cells(v + 1, 23) = (RateM1(v, 2))
                    .cells(v + 1, 24) = (RateM1(v, 3))
                    .cells(v + 1, 25) = (RateM2(v, 0))
                    .cells(v + 1, 26) = (RateM2(v, 1))
                    .cells(v + 1, 27) = (RateM2(v, 2))
                    .cells(v + 1, 28) = (RateM2(v, 3))
                    .cells(v + 1, 29) = (RateM3(v, 0))
                    .cells(v + 1, 30) = (RateM3(v, 1))
                    .cells(v + 1, 31) = (RateM3(v, 2))
                    .cells(v + 1, 32) = (RateM3(v, 3))
                    .cells(v + 1, 33) = (RateM4(v, 0))
                    .cells(v + 1, 34) = (RateM4(v, 1))
                    .cells(v + 1, 35) = (RateM4(v, 2))
                    .cells(v + 1, 36) = (RateM4(v, 3))

                Next v
                .cells(1, 37) = (sumwiriM1(0))
                .cells(1, 38) = (sumwiriM1(1))
                .cells(1, 39) = (sumwiriM1(2))
                .cells(1, 40) = (sumwiriM1(3))

                .cells(1, 41) = (sumwiriM2(0))
                .cells(1, 42) = (sumwiriM2(1))
                .cells(1, 43) = (sumwiriM2(2))
                .cells(1, 44) = (sumwiriM2(3))

                .cells(1, 45) = (sumwiriM3(0))
                .cells(1, 46) = (sumwiriM3(1))
                .cells(1, 47) = (sumwiriM3(2))
                .cells(1, 48) = (sumwiriM3(3))

                .cells(1, 49) = (sumwiriM4(0))
                .cells(1, 50) = (sumwiriM4(1))
                .cells(1, 51) = (sumwiriM4(2))
                .cells(1, 52) = (sumwiriM4(3))



                .cells(1, 53) = (sumwsub(0))
                .cells(1, 54) = (sumwsub(1))
                .cells(1, 55) = (sumwsub(2))
                .cells(1, 56) = (sumwsub(3))


                .cells(1, 57) = (sumwiridivsumwM1(0))
                .cells(1, 58) = (sumwiridivsumwM1(1))
                .cells(1, 59) = (sumwiridivsumwM1(2))
                .cells(1, 60) = (sumwiridivsumwM1(3))

                .cells(1, 61) = (sumwiridivsumwM2(0))
                .cells(1, 62) = (sumwiridivsumwM2(1))
                .cells(1, 63) = (sumwiridivsumwM2(2))
                .cells(1, 64) = (sumwiridivsumwM2(3))


                .cells(1, 65) = (sumwiridivsumwM3(0))
                .cells(1, 66) = (sumwiridivsumwM3(1))
                .cells(1, 67) = (sumwiridivsumwM3(2))
                .cells(1, 68) = (sumwiridivsumwM3(3))

                .cells(1, 69) = (sumwiridivsumwM4(0))
                .cells(1, 70) = (sumwiridivsumwM4(1))
                .cells(1, 71) = (sumwiridivsumwM4(2))
                .cells(1, 72) = (sumwiridivsumwM4(3))

                .cells(1, 73) = EQ1
                .cells(1, 74) = EQ2
                .cells(1, 75) = EQ3
                .cells(1, 76) = EQ4

            End With

            ExcelObj.Visible = True
            ExcelSheet = Nothing
            ExcelBook = Nothing
            ExcelObj = Nothing

        End If
        If MaterialSelection.CheckBox2.Enabled = True Then
            Dim ExcelObj As Object
            Dim ExcelBook As Object
            Dim ExcelSheet As Object
            Dim s As Integer

            ExcelObj = CreateObject("Excel.Application")
            ExcelBook = ExcelObj.WorkBooks.Add
            ExcelSheet = ExcelBook.WorkSheets(1)

            With ExcelSheet
                For s = 0 To 19
                    .cells(s + 1, 1) = (IMP(s, 0))
                    .cells(s + 1, 2) = (IMP(s, 1))
                    .cells(s + 1, 3) = (IMP(s, 2))
                    .cells(s + 1, 4) = (IMP(s, 3))
                    .cells(s + 1, 5) = (RMAT1(s, 0))
                    .cells(s + 1, 6) = (RMAT1(s, 1))
                    .cells(s + 1, 7) = (RMAT1(s, 2))
                    .cells(s + 1, 8) = (RMAT1(s, 3))
                    .cells(s + 1, 9) = (RMAT2(s, 0))
                    .cells(s + 1, 10) = (RMAT2(s, 1))
                    .cells(s + 1, 11) = (RMAT2(s, 2))
                    .cells(s + 1, 12) = (RMAT2(s, 3))
                    .cells(s + 1, 13) = (RMAT3(s, 0))
                    .cells(s + 1, 14) = (RMAT3(s, 1))
                    .cells(s + 1, 15) = (RMAT3(s, 2))
                    .cells(s + 1, 16) = (RMAT3(s, 3))
                    .cells(s + 1, 17) = (RateM1(s, 0))
                    .cells(s + 1, 18) = (RateM1(s, 1))
                    .cells(s + 1, 19) = (RateM1(s, 2))
                    .cells(s + 1, 20) = (RateM1(s, 3))
                    .cells(s + 1, 21) = (RateM2(s, 0))
                    .cells(s + 1, 22) = (RateM2(s, 1))
                    .cells(s + 1, 23) = (RateM2(s, 2))
                    .cells(s + 1, 24) = (RateM2(s, 3))
                    .cells(s + 1, 25) = (RateM3(s, 0))
                    .cells(s + 1, 26) = (RateM3(s, 1))
                    .cells(s + 1, 27) = (RateM3(s, 2))
                    .cells(s + 1, 28) = (RateM3(s, 3))

                Next s
                .cells(1, 29) = (sumwiriM1(0))
                .cells(1, 30) = (sumwiriM1(1))
                .cells(1, 31) = (sumwiriM1(2))
                .cells(1, 32) = (sumwiriM1(3))

                .cells(1, 33) = (sumwiriM2(0))
                .cells(1, 34) = (sumwiriM2(1))
                .cells(1, 35) = (sumwiriM2(2))
                .cells(1, 36) = (sumwiriM2(3))

                .cells(1, 37) = (sumwiriM3(0))
                .cells(1, 38) = (sumwiriM3(1))
                .cells(1, 39) = (sumwiriM3(2))
                .cells(1, 40) = (sumwiriM3(3))


                .cells(1, 41) = (sumwsub(0))
                .cells(1, 42) = (sumwsub(1))
                .cells(1, 43) = (sumwsub(2))
                .cells(1, 44) = (sumwsub(3))


                .cells(1, 45) = (sumwiridivsumwM1(0))
                .cells(1, 46) = (sumwiridivsumwM1(1))
                .cells(1, 47) = (sumwiridivsumwM1(2))
                .cells(1, 48) = (sumwiridivsumwM1(3))

                .cells(1, 49) = (sumwiridivsumwM2(0))
                .cells(1, 50) = (sumwiridivsumwM2(1))
                .cells(1, 51) = (sumwiridivsumwM2(2))
                .cells(1, 52) = (sumwiridivsumwM2(3))


                .cells(1, 53) = (sumwiridivsumwM3(0))
                .cells(1, 54) = (sumwiridivsumwM3(1))
                .cells(1, 55) = (sumwiridivsumwM3(2))
                .cells(1, 56) = (sumwiridivsumwM3(3))

                .cells(1, 57) = EQ1
                .cells(1, 58) = EQ2
                .cells(1, 59) = EQ3


            End With
            ExcelObj.Visible = True
            ExcelSheet = Nothing
            ExcelBook = Nothing
            ExcelObj = Nothing

        End If

        If MaterialSelection.CheckBox1.Enabled = True Then
            Dim ExcelObj As Object
            Dim ExcelBook As Object
            Dim ExcelSheet As Object
            Dim k As Integer

            ExcelObj = CreateObject("Excel.Application")
            ExcelBook = ExcelObj.WorkBooks.Add
            ExcelSheet = ExcelBook.WorkSheets(1)

            With ExcelSheet
                For k = 0 To 19


                    .cells(k + 1, 1) = (IMP(k, 0))
                    .cells(k + 1, 2) = (IMP(k, 1))
                    .cells(k + 1, 3) = (IMP(k, 2))
                    .cells(k + 1, 4) = (IMP(k, 3))
                    .cells(k + 1, 5) = (RMAT1(k, 0))
                    .cells(k + 1, 6) = (RMAT1(k, 1))
                    .cells(k + 1, 7) = (RMAT1(k, 2))
                    .cells(k + 1, 8) = (RMAT1(k, 3))
                    .cells(k + 1, 9) = (RMAT2(k, 0))
                    .cells(k + 1, 10) = (RMAT2(k, 1))
                    .cells(k + 1, 11) = (RMAT2(k, 2))
                    .cells(k + 1, 12) = (RMAT2(k, 3))
                    .cells(k + 1, 13) = (RateM1(k, 0))
                    .cells(k + 1, 14) = (RateM1(k, 1))
                    .cells(k + 1, 15) = (RateM1(k, 2))
                    .cells(k + 1, 16) = (RateM1(k, 3))
                    .cells(k + 1, 17) = (RateM2(k, 0))
                    .cells(k + 1, 18) = (RateM2(k, 1))
                    .cells(k + 1, 19) = (RateM2(k, 2))
                    .cells(k + 1, 20) = (RateM2(k, 3))

                Next k
                .cells(1, 21) = (sumwiriM1(0))
                .cells(1, 22) = (sumwiriM1(1))
                .cells(1, 23) = (sumwiriM1(2))
                .cells(1, 24) = (sumwiriM1(3))

                .cells(1, 25) = (sumwiriM2(0))
                .cells(1, 26) = (sumwiriM2(1))
                .cells(1, 27) = (sumwiriM2(2))
                .cells(1, 28) = (sumwiriM2(3))


                .cells(1, 29) = (sumwsub(0))
                .cells(1, 30) = (sumwsub(1))
                .cells(1, 31) = (sumwsub(2))
                .cells(1, 32) = (sumwsub(3))


                .cells(1, 33) = (sumwiridivsumwM1(0))
                .cells(1, 34) = (sumwiridivsumwM1(1))
                .cells(1, 35) = (sumwiridivsumwM1(2))
                .cells(1, 36) = (sumwiridivsumwM1(3))

                .cells(1, 37) = (sumwiridivsumwM2(0))
                .cells(1, 38) = (sumwiridivsumwM2(1))
                .cells(1, 39) = (sumwiridivsumwM2(2))
                .cells(1, 40) = (sumwiridivsumwM2(3))

                .cells(1, 41) = (EQ1)
                .cells(1, 42) = (EQ2)


            End With
            ExcelObj.Visible = True
            ExcelSheet = Nothing
            ExcelBook = Nothing
            ExcelObj = Nothing

        End If

    End Sub

    Private Sub M219_Scroll(sender As Object, e As EventArgs) Handles M219.Scroll
        If M219.Value = 0 Then
            Mat219.Text = "Very Bad"
        ElseIf M219.Value = 1 Then
            Mat219.Text = "Bad"
        ElseIf M219.Value = 2 Then
            Mat219.Text = "Fairly Bad"
        ElseIf M219.Value = 3 Then
            Mat219.Text = "Fair"
        ElseIf M219.Value = 4 Then
            Mat219.Text = "Fairly Good"
        ElseIf M219.Value = 5 Then
            Mat219.Text = "Good"
        ElseIf M219.Value = 6 Then
            Mat219.Text = "Very Good"
        End If
        Dim a, b, c, d As Double
        If M219.Value = 0 Then
            a = 0
            b = (1 / 15)
            c = (2 / 15)
            d = (3 / 15)
        End If
        If M219.Value = 1 Then
            a = (2 / 15)
            b = (3 / 15)
            c = (4 / 15)
            d = (5 / 15)
        End If
        If M219.Value = 2 Then
            a = (4 / 15)
            b = (5 / 15)
            c = (6 / 15)
            d = (7 / 15)
        End If
        If M219.Value = 3 Then
            a = (6 / 15)
            b = (7 / 15)
            c = (8 / 15)
            d = (9 / 15)
        End If
        If M219.Value = 4 Then
            a = (8 / 15)
            b = (9 / 15)
            c = (10 / 15)
            d = (11 / 15)
        End If
        If M219.Value = 5 Then
            a = (10 / 15)
            b = (11 / 15)
            c = (12 / 15)
            d = (13 / 15)
        End If
        If M219.Value = 6 Then
            a = (12 / 15)
            b = (13 / 15)
            c = (14 / 15)
            d = 1
        End If
        RMAT2(18, 0) = a
        RMAT2(18, 1) = b
        RMAT2(18, 2) = c
        RMAT2(18, 3) = d
    End Sub
End Class