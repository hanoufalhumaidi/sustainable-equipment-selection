﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Importance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TrackBar3 = New System.Windows.Forms.TrackBar()
        Me.TrackBar4 = New System.Windows.Forms.TrackBar()
        Me.TrackBar5 = New System.Windows.Forms.TrackBar()
        Me.TrackBar7 = New System.Windows.Forms.TrackBar()
        Me.TrackBar8 = New System.Windows.Forms.TrackBar()
        Me.TrackBar9 = New System.Windows.Forms.TrackBar()
        Me.TrackBar11 = New System.Windows.Forms.TrackBar()
        Me.TrackBar12 = New System.Windows.Forms.TrackBar()
        Me.TrackBar13 = New System.Windows.Forms.TrackBar()
        Me.TrackBar15 = New System.Windows.Forms.TrackBar()
        Me.TrackBar16 = New System.Windows.Forms.TrackBar()
        Me.TrackBar17 = New System.Windows.Forms.TrackBar()
        Me.TrackBar18 = New System.Windows.Forms.TrackBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TrackBar2 = New System.Windows.Forms.TrackBar()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TrackBar3
        '
        Me.TrackBar3.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar3.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar3.Location = New System.Drawing.Point(2209, 172)
        Me.TrackBar3.Maximum = 3
        Me.TrackBar3.Name = "TrackBar3"
        Me.TrackBar3.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar3.TabIndex = 2
        '
        'TrackBar4
        '
        Me.TrackBar4.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar4.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar4.Location = New System.Drawing.Point(2209, 250)
        Me.TrackBar4.Maximum = 3
        Me.TrackBar4.Name = "TrackBar4"
        Me.TrackBar4.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar4.TabIndex = 3
        '
        'TrackBar5
        '
        Me.TrackBar5.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar5.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar5.Location = New System.Drawing.Point(2209, 328)
        Me.TrackBar5.Maximum = 3
        Me.TrackBar5.Name = "TrackBar5"
        Me.TrackBar5.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar5.TabIndex = 4
        '
        'TrackBar7
        '
        Me.TrackBar7.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar7.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar7.Location = New System.Drawing.Point(2209, 484)
        Me.TrackBar7.Maximum = 3
        Me.TrackBar7.Name = "TrackBar7"
        Me.TrackBar7.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar7.TabIndex = 6
        '
        'TrackBar8
        '
        Me.TrackBar8.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar8.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar8.Location = New System.Drawing.Point(2209, 562)
        Me.TrackBar8.Maximum = 3
        Me.TrackBar8.Name = "TrackBar8"
        Me.TrackBar8.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar8.TabIndex = 7
        '
        'TrackBar9
        '
        Me.TrackBar9.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar9.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar9.Location = New System.Drawing.Point(2209, 640)
        Me.TrackBar9.Maximum = 3
        Me.TrackBar9.Name = "TrackBar9"
        Me.TrackBar9.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar9.TabIndex = 8
        '
        'TrackBar11
        '
        Me.TrackBar11.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar11.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar11.Location = New System.Drawing.Point(2209, 796)
        Me.TrackBar11.Maximum = 3
        Me.TrackBar11.Name = "TrackBar11"
        Me.TrackBar11.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar11.TabIndex = 10
        '
        'TrackBar12
        '
        Me.TrackBar12.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar12.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar12.Location = New System.Drawing.Point(2209, 874)
        Me.TrackBar12.Maximum = 3
        Me.TrackBar12.Name = "TrackBar12"
        Me.TrackBar12.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar12.TabIndex = 11
        '
        'TrackBar13
        '
        Me.TrackBar13.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar13.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar13.Location = New System.Drawing.Point(2209, 952)
        Me.TrackBar13.Maximum = 3
        Me.TrackBar13.Name = "TrackBar13"
        Me.TrackBar13.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar13.TabIndex = 12
        '
        'TrackBar15
        '
        Me.TrackBar15.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar15.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar15.Location = New System.Drawing.Point(2209, 1108)
        Me.TrackBar15.Maximum = 3
        Me.TrackBar15.Name = "TrackBar15"
        Me.TrackBar15.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar15.TabIndex = 14
        '
        'TrackBar16
        '
        Me.TrackBar16.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar16.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar16.Location = New System.Drawing.Point(2209, 1186)
        Me.TrackBar16.Maximum = 3
        Me.TrackBar16.Name = "TrackBar16"
        Me.TrackBar16.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar16.TabIndex = 15
        '
        'TrackBar17
        '
        Me.TrackBar17.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar17.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar17.Location = New System.Drawing.Point(2209, 1264)
        Me.TrackBar17.Maximum = 3
        Me.TrackBar17.Name = "TrackBar17"
        Me.TrackBar17.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar17.TabIndex = 16
        '
        'TrackBar18
        '
        Me.TrackBar18.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar18.Location = New System.Drawing.Point(2209, 1342)
        Me.TrackBar18.Maximum = 3
        Me.TrackBar18.Name = "TrackBar18"
        Me.TrackBar18.Size = New System.Drawing.Size(622, 69)
        Me.TrackBar18.TabIndex = 17
        Me.TrackBar18.Tag = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(2912, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(259, 45)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Not Important"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(2912, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(259, 45)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Not Important"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(2912, 247)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(259, 45)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Not Important"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(2912, 325)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(259, 45)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Not Important"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(2912, 481)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(259, 45)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Not Important"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(2912, 559)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(259, 45)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Not Important"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(2912, 637)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(259, 45)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Not Important"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(2912, 793)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(259, 45)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Not Important"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(2912, 871)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(259, 45)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "Not Important"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(2912, 949)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(259, 45)
        Me.Label13.TabIndex = 32
        Me.Label13.Text = "Not Important"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(2912, 1105)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(259, 45)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "Not Important"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(2912, 1183)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(259, 45)
        Me.Label16.TabIndex = 35
        Me.Label16.Text = "Not Important"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(2912, 1261)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(259, 45)
        Me.Label17.TabIndex = 36
        Me.Label17.Text = "Not Important"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(2912, 1339)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(259, 45)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "Not Important"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(6, 793)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(1534, 45)
        Me.Label31.TabIndex = 50
        Me.Label31.Text = "Rate the Importance of Quality and Life Expectancy on Your Decision to Select Mat" &
    "erial"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Arial", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(6, 3)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(714, 56)
        Me.Label21.TabIndex = 51
        Me.Label21.Text = "Extraction and Manufacturing "
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(6, 86)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(1454, 45)
        Me.Label22.TabIndex = 52
        Me.Label22.Text = "Rate the Importance of Material Selection (Local and Non Toxic Material Selection" &
    ")"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(6, 169)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(1127, 45)
        Me.Label23.TabIndex = 53
        Me.Label23.Text = "Rate the Importance of Extraction and Manufacturing Air Impact"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(6, 247)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(1146, 45)
        Me.Label24.TabIndex = 54
        Me.Label24.Text = "Rate the Importance of Extraction and Manufacturing Soil Impact"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(6, 325)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(1188, 45)
        Me.Label25.TabIndex = 55
        Me.Label25.Text = "Rate the Importance of Extraction and Manufacturing Water Impact"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Arial", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(6, 403)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(131, 56)
        Me.Label26.TabIndex = 56
        Me.Label26.Text = "Cost"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(6, 481)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(1230, 45)
        Me.Label27.TabIndex = 57
        Me.Label27.Text = "Rate the Importance of Initial Cost on Your Decision to Select Material"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(6, 559)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(1365, 45)
        Me.Label28.TabIndex = 58
        Me.Label28.Text = "Rate the Importance of Maintenance Cost on Your Decision to Select Material"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(6, 637)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(1327, 45)
        Me.Label29.TabIndex = 59
        Me.Label29.Text = "Rate the Importance of Demolition Cost on Your Decision to Select Material"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Arial", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(6, 715)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(452, 56)
        Me.Label30.TabIndex = 60
        Me.Label30.Text = "Technical Aspects "
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(6, 871)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(2054, 45)
        Me.Label32.TabIndex = 61
        Me.Label32.Text = "Rate the Importance of Availability of Resources in terms of Labor and Equipment " &
    "on Your Decision to Select Material"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(6, 949)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(1528, 45)
        Me.Label33.TabIndex = 62
        Me.Label33.Text = "Rate the Importance of Labor and End-User Safety on Your Decision to Select Mater" &
    "ial"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Arial", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(6, 1027)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(792, 56)
        Me.Label34.TabIndex = 63
        Me.Label34.Text = "Environmental Impact of Material "
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(6, 1105)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(1651, 45)
        Me.Label35.TabIndex = 64
        Me.Label35.Text = "Rate the Importance of Air Impact of Material Upon Usage on Your Decision to Sele" &
    "ct Material"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(6, 1183)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(1712, 45)
        Me.Label36.TabIndex = 65
        Me.Label36.Text = "Rate the Importance of Water Impact of Material Upon Usage on Your Decision to Se" &
    "lect Material"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(6, 1261)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(1670, 45)
        Me.Label37.TabIndex = 66
        Me.Label37.Text = "Rate the Importance of Soil Impact of Material Upon Usage on Your Decision to Sel" &
    "ect Material"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(6, 1339)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(1718, 45)
        Me.Label38.TabIndex = 67
        Me.Label38.Text = "Rate the Importance of Waste of Material Upon Usage Impact on Your Decision to Se" &
    "lect Material"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(2932, 1583)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(370, 99)
        Me.Button2.TabIndex = 75
        Me.Button2.Text = "Next"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 2200.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 700.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 605.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label30, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label29, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar3, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar4, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar5, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar7, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar8, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar9, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar11, 1, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar12, 1, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar13, 1, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar15, 1, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar16, 1, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar17, 1, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 2, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 2, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 2, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 2, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 2, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 2, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 2, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label31, 0, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Label32, 0, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.Label33, 0, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label34, 0, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.Label35, 0, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.Label36, 0, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label37, 0, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.Label38, 0, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar18, 1, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar2, 1, 1)
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(12, 12)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 19
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(3290, 1537)
        Me.TableLayoutPanel1.TabIndex = 76
        '
        'TrackBar2
        '
        Me.TrackBar2.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar2.Cursor = System.Windows.Forms.Cursors.Default
        Me.TrackBar2.Location = New System.Drawing.Point(2209, 89)
        Me.TrackBar2.Maximum = 3
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Size = New System.Drawing.Size(622, 74)
        Me.TrackBar2.TabIndex = 68
        '
        'Importance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(19.0!, 37.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(3554, 1985)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "Importance"
        Me.Text = "Assessment of Criteria Importance"
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TrackBar3 As TrackBar
    Friend WithEvents TrackBar4 As TrackBar
    Friend WithEvents TrackBar5 As TrackBar
    Friend WithEvents TrackBar7 As TrackBar
    Friend WithEvents TrackBar8 As TrackBar
    Friend WithEvents TrackBar9 As TrackBar
    Friend WithEvents TrackBar11 As TrackBar
    Friend WithEvents TrackBar12 As TrackBar
    Friend WithEvents TrackBar13 As TrackBar
    Friend WithEvents TrackBar15 As TrackBar
    Friend WithEvents TrackBar16 As TrackBar
    Friend WithEvents TrackBar17 As TrackBar
    Friend WithEvents TrackBar18 As TrackBar
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TrackBar2 As TrackBar
End Class
